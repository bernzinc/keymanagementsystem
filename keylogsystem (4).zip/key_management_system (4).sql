-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2025 at 08:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `key_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('Admin') DEFAULT 'Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_code` varchar(6) DEFAULT NULL,
  `reset_expiry` datetime DEFAULT NULL,
  `reset_attempts` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `Lname`, `Fname`, `Email`, `Password`, `Role`, `created_at`, `updated_at`, `reset_code`, `reset_expiry`, `reset_attempts`) VALUES
(1, 'Orbillo', 'Bernz', 'bernz@gmail.com', '$2y$10$lqWyM0in6sNzL.cR9ONUceqvqoFSA8A4qdZOsYEJSegc3V.DfSqty', 'Admin', '2025-10-10 04:16:49', '2025-10-10 05:13:47', NULL, NULL, 0),
(2, 'Daylo', 'Kyle', 'kyle@gmail.com', '$2y$10$QmyAAU94kwo7YAZqxFLv8eTj18sXfUD3f9rnZOJUoHZqqL976Rf2q', 'Admin', '2025-10-10 04:16:49', '2025-10-10 05:17:50', NULL, NULL, 0),
(3, 'Empillo', 'Jay', 'jay@gmail.com', '$2y$10$tOA.3l1PLDCXPScN32SH1.9vn527egEia1Vy2l6eYON/EZs3UZyAG', 'Admin', '2025-10-10 04:16:49', '2025-10-12 11:49:11', NULL, NULL, 0),
(4, '', '', '', '$2y$10$zLH6B5gyGskU75H0pRghKOIUmuWfRRyX8NIhc0qaA6sKIlH09pjwa', 'Admin', '2025-12-06 05:46:17', '2025-12-06 05:46:17', NULL, NULL, 0),
(5, 'Orbillo', 'Bernadette', 'bernadetteorbillo8@gmail.com', '$2y$10$bIfwEXUdOw/vdd7PKrJG9e1Hkig4jwPGdlSOcHBPD9ec3KRvzLD2K', 'Admin', '2025-12-06 05:51:39', '2025-12-09 10:02:06', '$2y$10', '2025-12-09 11:17:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DeptID` int(11) NOT NULL,
  `DeptName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DeptID`, `DeptName`) VALUES
(1, 'Phoenix'),
(2, 'Warriors'),
(3, 'Nightingale'),
(4, 'Tycoons');

-- --------------------------------------------------------

--
-- Table structure for table `keys_m`
--

CREATE TABLE `keys_m` (
  `KeyID` int(11) NOT NULL,
  `Room_ID` varchar(50) NOT NULL,
  `Key_Code` varchar(50) NOT NULL,
  `QRCode` varchar(255) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Status` enum('Available','Replaced','Lost') DEFAULT 'Available',
  `Date_Added` date DEFAULT curdate(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keys_m`
--

INSERT INTO `keys_m` (`KeyID`, `Room_ID`, `Key_Code`, `QRCode`, `Location`, `Status`, `Date_Added`, `created_at`, `updated_at`) VALUES
(1, 'LAB1', 'K-LAB1', 'K-LAB1', 'Laboratory 1', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-11-29 03:33:05'),
(2, 'LAB2', 'K-LAB2', 'K-LAB2', 'Laboratory 2', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-11-29 03:42:19'),
(3, 'LAB3', 'K-LAB3', 'K-LAB3', 'Laboratory 3', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-12 07:53:21'),
(4, 'R206', 'K-R206', 'K-R206', 'Room 206', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-28 10:51:58'),
(6, 'R201', 'K-R201', 'K-R201', 'Room 201', 'Replaced', '2025-10-29', '2025-10-29 11:56:59', '2025-12-09 08:32:12'),
(8, 'LAB1', 'K-001', 'K-001', 'Laboratory 1', 'Replaced', '2025-12-03', '2025-12-03 08:18:06', '2025-12-10 06:26:26'),
(10, 'R301', 'K-R301', 'K-R301', 'Room 301', 'Available', '2025-12-06', '2025-12-06 06:56:09', '2025-12-06 06:56:09'),
(16, 'R303', 'K-R303', 'K-R303', 'Room 303', 'Available', '2025-12-10', '2025-12-10 06:22:50', '2025-12-10 06:22:50');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `LogID` int(11) NOT NULL,
  `KeyID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Location` varchar(150) NOT NULL,
  `Date` date NOT NULL,
  `TimeBorrowed` time DEFAULT NULL,
  `TimeReturned` time DEFAULT NULL,
  `DueDate` datetime DEFAULT NULL,
  `Status` enum('Borrowed','Returned','Overdue','Lost') DEFAULT 'Borrowed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`LogID`, `KeyID`, `UserID`, `Location`, `Date`, `TimeBorrowed`, `TimeReturned`, `DueDate`, `Status`, `created_at`, `updated_at`) VALUES
(74, 1, 19, 'Laboratory 1', '2025-12-03', '16:45:24', '16:45:39', '2025-12-03 22:00:00', 'Returned', '2025-12-03 08:45:24', '2025-12-03 08:45:39'),
(75, 2, 19, 'Laboratory 2', '2025-12-03', '17:10:35', '17:10:58', '2025-12-03 22:00:00', 'Returned', '2025-12-03 09:10:35', '2025-12-03 09:10:58'),
(76, 1, 14, 'Laboratory 1', '2025-12-03', '17:12:24', '17:12:47', '2025-12-03 22:00:00', 'Returned', '2025-12-03 09:12:24', '2025-12-03 09:12:47'),
(77, 4, 14, 'Room 206', '2025-12-03', '17:15:51', '17:16:05', '2025-12-03 22:00:00', 'Returned', '2025-12-03 09:15:51', '2025-12-03 09:16:05'),
(79, 1, 8, 'Laboratory 1', '2025-12-06', '14:34:14', '21:47:38', '2025-12-06 22:00:00', 'Returned', '2025-12-06 06:34:14', '2025-12-07 13:47:38'),
(80, 8, 8, 'Laboratory 1', '2025-12-07', '21:47:48', '16:31:03', '2025-12-07 22:00:00', 'Returned', '2025-12-07 13:47:48', '2025-12-09 08:31:03'),
(81, 1, 10, 'Laboratory 1', '2025-12-09', '16:21:01', '17:25:05', '2025-12-09 22:00:00', 'Returned', '2025-12-09 08:21:01', '2025-12-09 09:25:05'),
(82, 4, 9, 'Room 206', '2025-12-09', '17:24:33', '10:57:03', '2025-12-09 22:00:00', 'Returned', '2025-12-09 09:24:33', '2025-12-10 02:57:03'),
(83, 10, 11, 'Room 301', '2025-12-09', '17:24:53', NULL, '2025-12-09 22:00:00', 'Overdue', '2025-12-09 09:24:53', '2025-12-09 14:12:23'),
(84, 1, 10, 'Laboratory 1', '2025-12-09', '17:25:15', '10:45:02', '2025-12-09 22:00:00', 'Returned', '2025-12-09 09:25:15', '2025-12-10 02:45:02'),
(85, 6, 8, 'Room 201', '2025-12-09', '18:42:32', NULL, '2025-12-09 22:00:00', 'Overdue', '2025-12-09 10:42:32', '2025-12-09 14:12:23'),
(86, 1, 19, 'Laboratory 1', '2025-12-10', '14:21:23', '14:28:45', '2025-12-10 22:00:00', 'Returned', '2025-12-10 06:21:23', '2025-12-10 06:28:45'),
(87, 16, 20, 'Room 303', '2025-12-10', '15:10:23', NULL, '2025-12-10 22:00:00', 'Borrowed', '2025-12-10 07:10:23', '2025-12-10 07:10:23'),
(88, 1, 19, 'Laboratory 1', '2025-12-10', '15:16:12', '15:16:45', '2025-12-10 22:00:00', 'Returned', '2025-12-10 07:16:12', '2025-12-10 07:16:45');

-- --------------------------------------------------------

--
-- Table structure for table `lost_keys`
--

CREATE TABLE `lost_keys` (
  `LostID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Fname` varchar(100) DEFAULT NULL,
  `Lname` varchar(100) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `Key_Code` varchar(100) NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Date_Reported` datetime DEFAULT current_timestamp(),
  `Remarks` text DEFAULT NULL,
  `Status` enum('REPORTED','FOUND','REPLACED') DEFAULT 'REPORTED',
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lost_keys`
--

INSERT INTO `lost_keys` (`LostID`, `UserID`, `Fname`, `Lname`, `Email`, `Key_Code`, `Location`, `Date_Reported`, `Remarks`, `Status`, `updated_at`) VALUES
(8, 11, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'K-R201', 'Room 201', '2025-11-29 00:00:00', '', 'REPLACED', '2025-12-09 08:32:12'),
(9, 20, 'Bernz', 'Orbillo', 'hello@gmail.com', 'K-001', 'R001', '2025-12-10 00:00:00', '', 'REPLACED', '2025-12-10 06:26:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `NotifID` int(11) NOT NULL,
  `Fname` varchar(100) DEFAULT NULL,
  `Lname` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Message` text NOT NULL,
  `Status` enum('Unread','Read') DEFAULT 'Unread',
  `is_read` tinyint(1) DEFAULT 0,
  `Date_Sent` datetime DEFAULT current_timestamp(),
  `Date_Read` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`NotifID`, `Fname`, `Lname`, `Email`, `Message`, `Status`, `is_read`, `Date_Sent`, `Date_Read`) VALUES
(5, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', 0, '2025-10-28 12:04:16', NULL),
(6, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', 0, '2025-10-28 12:05:43', NULL),
(7, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', 0, '2025-10-28 12:07:07', NULL),
(8, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', 0, '2025-10-28 12:07:11', NULL),
(9, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', 0, '2025-10-28 12:07:27', NULL),
(10, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', 0, '2025-10-28 13:23:52', NULL),
(11, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', 0, '2025-10-28 13:24:14', NULL),
(12, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', 0, '2025-10-28 13:24:23', NULL),
(13, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', 0, '2025-10-28 13:24:48', NULL),
(14, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', 0, '2025-10-28 14:00:36', NULL),
(15, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', 0, '2025-10-28 14:00:44', NULL),
(16, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', 0, '2025-10-28 14:05:59', NULL),
(17, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', 0, '2025-10-28 14:06:28', NULL),
(18, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', 0, '2025-10-28 14:19:50', NULL),
(19, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', 0, '2025-10-28 15:11:55', NULL),
(20, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', 0, '2025-10-28 15:13:20', NULL),
(21, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', 0, '2025-10-28 15:13:26', NULL),
(22, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 03:20 PM.', '', 0, '2025-10-28 15:20:51', NULL),
(23, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:22', NULL),
(24, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:27', NULL),
(25, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:33', NULL),
(26, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:38', NULL),
(27, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:43', NULL),
(28, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:47', NULL),
(29, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:52', NULL),
(30, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 28, 2025 10:00 PM.', '', 0, '2025-10-28 22:00:58', NULL),
(31, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:04:36', NULL),
(32, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:04:39', NULL),
(33, 'Kydro', 'Auxley', 'jonggonzales13@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:19:55', NULL),
(34, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:19:59', NULL),
(35, 'Kydro', 'Auxley', 'jonggonzales13@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:59:20', NULL),
(36, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', 0, '2025-10-29 22:59:24', NULL),
(37, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', 0, '2025-10-31 11:25:58', NULL),
(38, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', 0, '2025-10-31 11:26:34', NULL),
(39, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', 0, '2025-10-31 11:26:59', NULL),
(40, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 11:35 AM.', '', 0, '2025-10-31 11:37:52', NULL),
(41, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 31, 2025 11:50 AM.', '', 0, '2025-10-31 11:53:32', NULL),
(42, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 31, 2025 11:50 AM.', '', 0, '2025-10-31 11:54:40', NULL),
(43, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 31, 2025 12:02 PM.', '', 0, '2025-10-31 12:06:22', NULL),
(44, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 31, 2025 12:02 PM.', '', 0, '2025-10-31 12:07:13', NULL),
(45, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 12:43 PM.', '', 0, '2025-10-31 12:44:20', NULL),
(46, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', 0, '2025-10-31 21:00:14', NULL),
(47, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', 0, '2025-10-31 21:01:48', NULL),
(48, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 09:04 PM.', '', 0, '2025-10-31 21:04:18', NULL),
(49, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', 0, '2025-10-31 21:04:23', NULL),
(50, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Nov 29, 2025 11:30 AM.', '', 0, '2025-11-29 11:31:52', NULL),
(51, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Nov 29, 2025 11:30 AM.', '', 0, '2025-11-29 11:33:10', NULL),
(52, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Nov 29, 2025 11:41 AM.', '', 0, '2025-11-29 11:43:02', NULL),
(53, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Nov 29, 2025 11:41 AM.', '', 0, '2025-11-29 11:43:17', NULL),
(54, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Nov 29, 2025 11:41 AM.', '', 0, '2025-11-29 11:45:05', NULL),
(55, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Nov 29, 2025 11:41 AM.', '', 0, '2025-11-29 11:46:19', NULL),
(56, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Nov 29, 2025 11:49 AM.', '', 0, '2025-11-29 11:49:13', NULL),
(57, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-05 21:44:48', NULL),
(58, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-05 21:44:53', NULL),
(59, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:23:13', NULL),
(60, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:23:18', NULL),
(61, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:25:13', NULL),
(62, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:25:42', NULL),
(63, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:36:15', NULL),
(64, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 12:48:42', NULL),
(65, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 14:33:10', NULL),
(66, 'Kyle', 'Daylo', 'bernz@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Dec 03, 2025 10:00 PM.', '', 0, '2025-12-06 14:33:23', NULL),
(67, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:30:52', NULL),
(68, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:30:57', NULL),
(69, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:31:01', NULL),
(70, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:31:22', NULL),
(71, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:31:26', NULL),
(72, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-06 23:31:49', NULL),
(73, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Dec 06, 2025 10:00 PM.', '', 0, '2025-12-07 20:57:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `Role` enum('Instructor','Staff') DEFAULT 'Instructor',
  `Email` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DeptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Lname`, `Fname`, `Department`, `Role`, `Email`, `created_at`, `updated_at`, `DeptID`) VALUES
(8, 'Auxley', 'Klyxion', 'Warriors', 'Instructor', 'klyxion19@gmail.com', '2025-10-28 12:52:20', '2025-10-28 12:54:01', NULL),
(9, 'Auxley', 'Kydro', 'Tycoons', 'Instructor', 'jonggonzales13@gmail.com', '2025-10-28 12:53:08', '2025-10-29 14:09:08', NULL),
(10, 'Garcia', 'Faith', 'Phoenix', 'Instructor', 'faith081201@gmail.com', '2025-10-28 12:55:14', '2025-10-28 12:55:14', NULL),
(11, 'Tolentino', 'Rizalyn', 'Warriors', 'Staff', 'rizalyntolentino218@gmail.com', '2025-10-28 13:07:21', '2025-10-28 13:07:21', NULL),
(14, 'Daylo', 'Kyle', 'IT', 'Instructor', 'bernz@gmail.com', '2025-12-03 08:19:08', '2025-12-03 08:19:08', NULL),
(19, 'Rivas', 'Francisco', 'IT', 'Instructor', 'francisco@gmail.com', '2025-12-03 08:44:00', '2025-12-03 08:44:00', NULL),
(20, 'Orbillo', 'Bernz', 'IT', 'Instructor', 'hello@gmail.com', '2025-12-10 06:23:56', '2025-12-10 06:23:56', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DeptID`);

--
-- Indexes for table `keys_m`
--
ALTER TABLE `keys_m`
  ADD PRIMARY KEY (`KeyID`),
  ADD UNIQUE KEY `QRCode` (`QRCode`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `fk_logs_key` (`KeyID`),
  ADD KEY `fk_logs_user` (`UserID`);

--
-- Indexes for table `lost_keys`
--
ALTER TABLE `lost_keys`
  ADD PRIMARY KEY (`LostID`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`NotifID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `fk_users_department` (`DeptID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `DeptID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `keys_m`
--
ALTER TABLE `keys_m`
  MODIFY `KeyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `lost_keys`
--
ALTER TABLE `lost_keys`
  MODIFY `LostID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `NotifID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `fk_logs_key` FOREIGN KEY (`KeyID`) REFERENCES `keys_m` (`KeyID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_logs_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_department` FOREIGN KEY (`DeptID`) REFERENCES `departments` (`DeptID`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
