document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const toggle = document.getElementById('toggle-switch');
    const theme = localStorage.getItem('theme');

    // Apply saved theme
    if (theme === 'dark') {
        body.classList.add('dark');
        if (toggle) toggle.classList.add('active');
    }

    // Enable toggling if toggle button exists
    if (toggle) {
        toggle.addEventListener('click', () => {
            body.classList.toggle('dark');
            toggle.classList.toggle('active');
            localStorage.setItem('theme', body.classList.contains('dark') ? 'dark' : 'light');
        });
    }
});
