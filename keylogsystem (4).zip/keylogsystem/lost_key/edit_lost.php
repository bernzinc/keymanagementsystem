<?php
require_once '../includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

$id = (int) $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM lost_keys WHERE LostID = :id");
$stmt->execute([':id' => $id]);
$lost = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$lost) {
    die("Record not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE lost_keys 
                           SET Fname = :fname, Lname = :lname, Email = :email,
                               Key_Code = :key_code, Location = :location, Remarks = :remarks, 
                               Status = :status, updated_at = NOW()
                           WHERE LostID = :id");
    $stmt->execute([
        ':fname' => $_POST['fname'],
        ':lname' => $_POST['lname'],
        ':email' => $_POST['email'],
        ':key_code' => $_POST['key_code'],
        ':location' => $_POST['location'],
        ':remarks' => $_POST['remarks'],
        ':status' => $_POST['status'],
        ':id' => $id
    ]);
    header("Location: lost_key.php?edited=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Lost Key Record</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --primary-light: #dbeafe;
            --success: #10b981;
            --success-light: #d1fae5;
            --warning: #f59e0b;
            --danger: #ef4444;
            --danger-light: #fee2e2;
            --bg: #f1f5f9;
            --text: #1e293b;
            --text-secondary: #64748b;
            --text-tertiary: #94a3b8;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --input-bg: #f8fafc;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        body.dark {
            --bg: #0f172a;
            --text: #f1f5f9;
            --text-secondary: #cbd5e1;
            --text-tertiary: #94a3b8;
            --card-bg: #1e293b;
            --border: #334155;
            --input-bg: #0f172a;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 24px;
            transition: background-color 0.3s, color 0.3s;
            min-height: 100vh;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        /* Header Section */
        .header {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }

        .header-title {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .header-title h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .header-title svg {
            color: var(--primary);
        }

        /* Form Card */
        .form-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 32px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }

        .form-section {
            margin-bottom: 32px;
        }

        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title svg {
            color: var(--primary);
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 600;
            font-size: 14px;
            color: var(--text);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .required {
            color: var(--danger);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
            background: var(--input-bg);
            color: var(--text);
            transition: all 0.2s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--card-bg);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
            font-family: inherit;
        }

        .form-group select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 20px;
            padding-right: 40px;
            cursor: pointer;
        }

        /* Status Badge Preview */
        .status-preview {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }

        .status-preview.lost {
            background: var(--danger-light);
            color: var(--danger);
        }

        .status-preview.found {
            background: var(--success-light);
            color: var(--success);
        }

        .status-preview.replaced {
            background: var(--primary-light);
            color: var(--primary);
        }

        /* Action Buttons */
        .form-actions {
            display: flex;
            gap: 12px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
            margin-top: 32px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            justify-content: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            flex: 1;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: var(--card-bg);
            color: var(--text-secondary);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: var(--border);
            color: var(--text);
        }

        /* Info Box */
        .info-box {
            background: var(--primary-light);
            border-left: 4px solid var(--primary);
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            display: flex;
            align-items: start;
            gap: 12px;
        }

        body.dark .info-box {
            background: rgba(59, 130, 246, 0.1);
        }

        .info-box svg {
            color: var(--primary);
            flex-shrink: 0;
            margin-top: 2px;
        }

        .info-box-content p {
            font-size: 14px;
            color: var(--text);
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .form-card {
                padding: 24px 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-title">
                <h1>
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    Edit Lost Key Record
                </h1>
            </div>
        </div>

        <!-- Form Card -->
        <div class="form-card">
            <div class="info-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="16" x2="12" y2="12"/>
                    <line x1="12" y1="8" x2="12.01" y2="8"/>
                </svg>
                <div class="info-box-content">
                    <p><strong>Note:</strong> Updating the status here will automatically sync with the main keys inventory system.</p>
                </div>
            </div>

            <form method="POST">
                <!-- Personal Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        Personal Information
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name <span class="required">*</span></label>
                            <input type="text" name="fname" value="<?= htmlspecialchars($lost['Fname']) ?>" required placeholder="Enter first name">
                        </div>
                        <div class="form-group">
                            <label>Last Name <span class="required">*</span></label>
                            <input type="text" name="lname" value="<?= htmlspecialchars($lost['Lname']) ?>" required placeholder="Enter last name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email Address <span class="required">*</span></label>
                        <input type="email" name="email" value="<?= htmlspecialchars($lost['Email']) ?>" required placeholder="example@email.com">
                    </div>
                </div>

                <!-- Key Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
                        </svg>
                        Key Details
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Key Code <span class="required">*</span></label>
                            <input type="text" name="key_code" value="<?= htmlspecialchars($lost['Key_Code']) ?>" required placeholder="e.g., KEY-001">
                        </div>
                        <div class="form-group">
                            <label>Last Known Location <span class="required">*</span></label>
                            <input type="text" name="location" value="<?= htmlspecialchars($lost['Location']) ?>" required placeholder="e.g., Room 101, Building A">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Status <span class="required">*</span></label>
                        <select name="status" id="statusSelect" required>
                            <option value="LOST" <?= $lost['Status'] == 'LOST' ? 'selected' : '' ?>>Lost</option>
                            <option value="FOUND" <?= $lost['Status'] == 'FOUND' ? 'selected' : '' ?>>Found</option>
                            <option value="REPLACED" <?= $lost['Status'] == 'REPLACED' ? 'selected' : '' ?>>Replaced</option>
                        </select>
                        <div id="statusPreview" class="status-preview"></div>
                    </div>

                    <div class="form-group">
                        <label>Additional Remarks</label>
                        <textarea name="remarks" placeholder="Enter any additional information about the lost key..."><?= htmlspecialchars($lost['Remarks']) ?></textarea>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                            <polyline points="17 21 17 13 7 13 7 21"/>
                            <polyline points="7 3 7 8 15 8"/>
                        </svg>
                        Update Record
                    </button>
                    <a href="lost_key.php" class="btn btn-secondary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Sync with dashboard theme on page load
        document.addEventListener('DOMContentLoaded', () => {
            const theme = localStorage.getItem('theme');
            if (theme === 'dark') {
                document.body.classList.add('dark');
            }
        });

        // Status Preview
        const statusSelect = document.getElementById('statusSelect');
        const statusPreview = document.getElementById('statusPreview');

        function updateStatusPreview() {
            const status = statusSelect.value.toLowerCase();
            const icons = {
                lost: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
                found: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
                replaced: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>'
            };
            
            statusPreview.className = `status-preview ${status}`;
            statusPreview.innerHTML = icons[status] + ' ' + statusSelect.options[statusSelect.selectedIndex].text;
        }

        statusSelect.addEventListener('change', updateStatusPreview);
        updateStatusPreview();
    </script>
</body>
</html>