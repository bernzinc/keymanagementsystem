<?php
require_once '../includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

$msg = null;
$msg_type = 'info';

$keys = $pdo->query("SELECT KeyID, Key_Code, Status FROM keys_m ORDER BY Key_Code ASC")->fetchAll(PDO::FETCH_ASSOC);
$users = $pdo->query("SELECT UserID, CONCAT(Fname, ' ', Lname) AS FullName FROM users ORDER BY Lname ASC")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keyID    = $_POST['KeyID'] ?? '';
    $userID   = $_POST['UserID'] ?? '';
    $location = trim($_POST['Location'] ?? '');
    $remarks  = trim($_POST['Remarks'] ?? '');
    $date     = date('Y-m-d');

    if ($keyID !== '' && $userID !== '' && $location !== '') {
        $pdo->beginTransaction(); 
        
        try {
            $u = $pdo->prepare("SELECT Fname, Lname, Email FROM users WHERE UserID = :uid LIMIT 1");
            $u->execute([':uid' => $userID]);
            $user = $u->fetch(PDO::FETCH_ASSOC);

            $k = $pdo->prepare("SELECT Key_Code FROM keys_m WHERE KeyID = :kid LIMIT 1");
            $k->execute([':kid' => $keyID]);
            $key = $k->fetch(PDO::FETCH_ASSOC);

            if (!$user || !$key) {
                $pdo->rollBack();
                $msg = "Selected user or key not found.";
                $msg_type = 'error';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO lost_keys (
                        UserID, Fname, Lname, Email, Key_Code, Location,
                        Date_Reported, Remarks, Status, updated_at
                    ) VALUES (
                        :userID, :fname, :lname, :email, :keycode, :location,
                        :date_reported, :remarks, 'LOST', NOW()
                    )
                ");
                $stmt->execute([
                    ':userID'       => $userID,
                    ':fname'        => $user['Fname'],
                    ':lname'        => $user['Lname'],
                    ':email'        => $user['Email'],
                    ':keycode'      => $key['Key_Code'],
                    ':location'     => $location,
                    ':date_reported'=> $date,
                    ':remarks'      => $remarks
                ]);

                $upd = $pdo->prepare("UPDATE keys_m SET Status = 'LOST', updated_at = NOW() WHERE KeyID = :kid");
                $upd->execute([':kid' => $keyID]);

                $pdo->commit(); 

                header("Location: lost_key.php?added=1");
                exit;
            }
        } catch (Exception $e) {
            $pdo->rollBack(); 
            $msg = "An unexpected database error occurred. The key was not reported lost.";
            $msg_type = 'error';
        }
    } else {
        $msg = "Please fill in all required fields.";
        $msg_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Lost Key</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --primary-light: #dbeafe;
            --success: #10b981;
            --success-light: #d1fae5;
            --warning: #f59e0b;
            --danger: #ef4444;
            --danger-light: #fee2e2;
            --bg: #f1f5f9;
            --text: #1e293b;
            --text-secondary: #64748b;
            --text-tertiary: #94a3b8;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --input-bg: #f8fafc;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        body.dark {
            --bg: #0f172a;
            --text: #f1f5f9;
            --text-secondary: #cbd5e1;
            --text-tertiary: #94a3b8;
            --card-bg: #1e293b;
            --border: #334155;
            --input-bg: #0f172a;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            transition: background-color 0.3s, color 0.3s;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 24px;
        }

        .container {
            width: 100%;
            max-width: 600px;
        }

        /* Header */
        .header {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            text-align: center;
        }

        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .header h1 svg {
            color: var(--primary);
        }

        .header p {
            color: var(--text-secondary);
            font-size: 14px;
            margin-top: 8px;
        }

        /* Form Card */
        .form-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 32px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }

        /* Alert */
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            font-weight: 500;
        }

        .alert svg {
            flex-shrink: 0;
        }

        .alert-error {
            background: var(--danger-light);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }

        body.dark .alert-error {
            background: rgba(239, 68, 68, 0.1);
        }

        /* Form Groups */
        .form-section {
            margin-bottom: 32px;
        }

        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title svg {
            color: var(--primary);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: 600;
            font-size: 14px;
            color: var(--text);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .required {
            color: var(--danger);
        }

        .optional-badge {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-tertiary);
            background: var(--input-bg);
            padding: 2px 8px;
            border-radius: 12px;
            margin-left: auto;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
            background: var(--input-bg);
            color: var(--text);
            transition: all 0.2s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--card-bg);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
            font-family: inherit;
        }

        .form-group select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 20px;
            padding-right: 40px;
            cursor: pointer;
        }

        /* Info Box */
        .info-box {
            background: var(--primary-light);
            border-left: 4px solid var(--primary);
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            display: flex;
            align-items: start;
            gap: 12px;
        }

        body.dark .info-box {
            background: rgba(59, 130, 246, 0.1);
        }

        .info-box svg {
            color: var(--primary);
            flex-shrink: 0;
            margin-top: 2px;
        }

        .info-box-content p {
            font-size: 14px;
            color: var(--text);
            margin: 0;
        }

        /* Action Buttons */
        .form-actions {
            display: flex;
            gap: 12px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
            margin-top: 32px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            justify-content: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            flex: 1;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: var(--card-bg);
            color: var(--text-secondary);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: var(--border);
            color: var(--text);
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .header {
                padding: 20px;
            }

            .header h1 {
                font-size: 20px;
            }

            .form-card {
                padding: 24px 20px;
            }

            .form-actions {
                flex-direction: column-reverse;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                Report Lost Key
            </h1>
            <p>Document a lost or missing key in the system</p>
        </div>

        <!-- Form Card -->
        <div class="form-card">
            <?php if ($msg): ?>
                <div class="alert alert-<?= $msg_type ?>">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                        <line x1="12" y1="9" x2="12" y2="13"/>
                        <line x1="12" y1="17" x2="12.01" y2="17"/>
                    </svg>
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endif; ?>

            <div class="info-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="16" x2="12" y2="12"/>
                    <line x1="12" y1="8" x2="12.01" y2="8"/>
                </svg>
                <div class="info-box-content">
                    <p><strong>Important:</strong> Reporting a key as lost will automatically update its status to "LOST" in the main inventory system.</p>
                </div>
            </div>

            <form method="POST">
                <!-- Key Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>
                        </svg>
                        Key Information
                    </div>

                    <div class="form-group">
                        <label>Key Code <span class="required">*</span></label>
                        <select name="KeyID" id="KeyID" required>
                            <option value="">Select Key Code...</option>
                            <?php foreach ($keys as $key): ?>
                                <option value="<?= htmlspecialchars($key['KeyID']) ?>">
                                    <?= htmlspecialchars($key['Key_Code']) ?> (Status: <?= htmlspecialchars($key['Status']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Last Seen Location <span class="required">*</span></label>
                        <input type="text" name="Location" id="Location" placeholder="e.g., Main Office Lobby, Desk 4B" required>
                    </div>
                </div>

                <!-- User Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        Associated User
                    </div>

                    <div class="form-group">
                        <label>User <span class="required">*</span></label>
                        <select name="UserID" id="UserID" required>
                            <option value="">Select User...</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?= htmlspecialchars($user['UserID']) ?>">
                                    <?= htmlspecialchars($user['FullName']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Additional Details Section -->
                <div class="form-section">
                    <div class="section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <polyline points="14 2 14 8 20 8"/>
                            <line x1="16" y1="13" x2="8" y2="13"/>
                            <line x1="16" y1="17" x2="8" y2="17"/>
                            <polyline points="10 9 9 9 8 9"/>
                        </svg>
                        Additional Details
                    </div>

                    <div class="form-group">
                        <label style="display: flex; align-items: center;">
                            Remarks/Details
                            <span class="optional-badge">Optional</span>
                        </label>
                        <textarea name="Remarks" id="Remarks" placeholder="Any details that can help locate the key (e.g., color of lanyard, time lost, etc.)."></textarea>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="form-actions">
                    <a href="lost_key.php" class="btn btn-secondary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                        Cancel
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
                            <polyline points="17 21 17 13 7 13 7 21"/>
                            <polyline points="7 3 7 8 15 8"/>
                        </svg>
                        Save Lost Key
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Sync with dashboard theme on page load
        document.addEventListener('DOMContentLoaded', () => {
            const theme = localStorage.getItem('theme');
            if (theme === 'dark') {
                document.body.classList.add('dark');
            }
        });
    </script>
</body>
</html>