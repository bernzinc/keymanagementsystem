<?php
require_once '../includes/functions.php';
requireAdmin();

// Set default timezone for NOW() function consistency
date_default_timezone_set('Asia/Manila');

// Global status mapping for badges
$statusBadgeMap = [
    'REPORTED' => ['text' => 'Reported', 'class' => 'badge-reported', 'icon' => 'fa-triangle-exclamation'],
    'FOUND' => ['text' => 'Found', 'class' => 'badge-found', 'icon' => 'fa-circle-check'],
    'REPLACED' => ['text' => 'Replaced', 'class' => 'badge-replaced', 'icon' => 'fa-rotate'],
    'LOST' => ['text' => 'Lost', 'class' => 'badge-lost', 'icon' => 'fa-circle-xmark']
];

// Helper function to render table rows (used by both main page and AJAX)
function renderTableRows($lostKeys, $statusBadgeMap) {
    ob_start(); // Start output buffering

    if (empty($lostKeys)) {
        echo "<tr><td colspan='7' class='no-data'><i class='fa-solid fa-inbox'></i><br>No lost key records found. Try searching for a different term.</td></tr>";
        return ob_get_clean();
    }

    foreach ($lostKeys as $row):
        $status = strtoupper($row['Status']);
        $badge = $statusBadgeMap[$status] ?? ['text' => $status, 'class' => 'badge-default', 'icon' => 'fa-circle-info'];
        // Ensure Fname exists before taking initial
        $initial = !empty($row['Fname']) ? strtoupper(substr($row['Fname'], 0, 1)) : '?';
    ?>
    <tr data-id="<?= $row['LostID'] ?>">
        <td>
            <div class="user-cell">
                <div class="user-avatar"><?= $initial ?></div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($row['Fname'] . ' ' . $row['Lname']) ?></div>
                    <div class="user-email"><?= htmlspecialchars($row['Email']) ?></div>
                </div>
            </div>
        </td>
        <td><span class="key-code"><i class="fa-solid fa-key"></i> <?= htmlspecialchars($row['Key_Code']) ?></span></td>
        <td><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($row['Location']) ?></td>
        <td><div class="remarks-cell" title="<?= htmlspecialchars($row['Remarks']) ?>"><?= htmlspecialchars($row['Remarks']) ?></div></td>
        <td>
            <span class="badge <?= $badge['class'] ?>">
                <i class="fa-solid <?= $badge['icon'] ?>"></i> <?= $badge['text'] ?>
            </span>
        </td>
        <td><i class="fa-regular fa-calendar"></i> <?= date('M d, Y', strtotime($row['Date_Reported'])) ?></td>
        <td class='actions'>
            <button class="btn-action btn-edit" onclick="location.href='edit_lost.php?id=<?= $row['LostID'] ?>'" title="Edit Record">
                <i class="fa-solid fa-pen-to-square"></i>
            </button>
            
            <?php if ($status !== 'FOUND' && $status !== 'REPLACED'): ?>
            <button class="btn-action btn-found" onclick="confirmUpdate(<?= $row['LostID'] ?>, 'FOUND', 'Mark as Found', 'Confirm the key was physically found. This will update the key status to AVAILABLE in the system.', 'success')" title="Mark as Found">
                <i class="fa-solid fa-circle-check"></i>
            </button>
            <?php endif; ?>

            <?php if ($status !== 'REPLACED'): ?>
            <button class="btn-action btn-replace" onclick="confirmUpdate(<?= $row['LostID'] ?>, 'REPLACED', 'Mark as Replaced', 'Confirm a new key was issued. The old key will be permanently marked as REPLACED.', 'info')" title="Mark as Replaced">
                <i class="fa-solid fa-rotate"></i>
            </button>
            <?php endif; ?>

            <button class="btn-action btn-delete delete" data-id="<?= $row['LostID'] ?>" title="Delete Record">
                <i class="fa-solid fa-trash"></i>
            </button>
        </td>
    </tr>
    <?php endforeach; 

    return ob_get_clean(); // Return the buffered output
}

// 1. Handle DELETE action
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM lost_keys WHERE LostID = :id");
    $stmt->execute([':id' => $id]);
    header("Location: lost_key.php?deleted=1");
    exit;
}

// 2. Handle UPDATE status action (and sync keys_m)
if (isset($_GET['update']) && isset($_GET['status'])) {
    $id = (int)$_GET['update'];
    $status = strtoupper($_GET['status']); 

    try {
        $pdo->beginTransaction();

        // Fetch the related key code 
        $stmt = $pdo->prepare("SELECT Key_Code FROM lost_keys WHERE LostID = ?");
        $stmt->execute([$id]);
        $keyCode = $stmt->fetchColumn();

        // Update lost_keys table
        $stmt = $pdo->prepare("UPDATE lost_keys SET Status = :status, updated_at = NOW() WHERE LostID = :id");
        $stmt->execute([':status' => $status, ':id' => $id]);

        // Map lost_keys status → keys_m status
        $map = [
            'FOUND'     => 'AVAILABLE',
            'REPLACED'  => 'REPLACED',
            'LOST'      => 'LOST',
            'REPORTED'  => 'LOST' 
        ];

        if ($keyCode && isset($map[$status])) {
            $newKeyStatus = $map[$status];
            $upd = $pdo->prepare("UPDATE keys_m SET Status = :s WHERE Key_Code = :code");
            $upd->execute([':s' => $newKeyStatus, ':code' => $keyCode]);
        }

        $pdo->commit();
        header("Location: lost_key.php?updated=1");
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error updating status: " . $e->getMessage());
        header("Location: lost_key.php?error=1");
        exit;
    }
}

// 3. Handle AJAX live search
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $search = $_GET['search'] ?? '';
    $stmt = $pdo->prepare("
        SELECT 
            * FROM lost_keys 
        WHERE 
            Fname LIKE :s OR Lname LIKE :s OR Email LIKE :s OR Key_Code LIKE :s OR Status LIKE :s
        ORDER BY LostID DESC
    ");
    $stmt->execute([':s' => "%$search%"]);
    $lostKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo renderTableRows($lostKeys, $statusBadgeMap);
    exit;
}

// 4. Fetch all records for initial page load
$stmt = $pdo->query("SELECT * FROM lost_keys ORDER BY LostID DESC");
$lostKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lost Key Management - ADFC</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    :root {
        --primary: #3b82f6;
        --primary-dark: #2563eb;
        --primary-light: #93c5fd;
        --success: #10b981;
        --success-light: #d1fae5;
        --warning: #f59e0b;
        --warning-light: #fef3c7;
        --danger: #ef4444;
        --danger-light: #fee2e2;
        --info: #06b6d4;
        --info-light: #cffafe;
        --purple: #8b5cf6;
        --bg: #f1f5f9;
        --text: #1e293b;
        --text-secondary: #64748b;
        --text-tertiary: #94a3b8;
        --card-bg: #ffffff;
        --border: #e2e8f0;
        --shadow: rgba(0, 0, 0, 0.05);
        --shadow-md: rgba(0, 0, 0, 0.1);
        --input-bg: #f8fafc;
    }

    body.dark {
        --bg: #0f172a;
        --text: #f1f5f9;
        --text-secondary: #cbd5e1;
        --text-tertiary: #94a3b8;
        --card-bg: #1e293b;
        --border: #334155;
        --shadow: rgba(0, 0, 0, 0.3);
        --shadow-md: rgba(0, 0, 0, 0.4);
        --input-bg: #0f172a;
    }
    
    /* Global Resets */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.6;
        padding: 24px;
        transition: all 0.3s ease;
    }

    /* Container */
    .container { 
        max-width: 1400px; 
        margin: 0 auto;
        animation: fadeIn 0.5s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Header */
    .header {
        background: linear-gradient(135deg, var(--primary), var(--purple));
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;
        box-shadow: 0 4px 20px var(--shadow-md);
        position: relative;
        overflow: hidden;
    }

    .header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        opacity: 0.5;
    }

    .header-content {
        position: relative;
        z-index: 1;
    }

    .header h1 {
        font-size: 32px;
        font-weight: 700;
        color: white;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 8px;
    }

    .header-subtitle {
        color: rgba(255, 255, 255, 0.9);
        font-size: 15px;
        font-weight: 500;
    }

    /* Controls */
    .controls {
        background: var(--card-bg);
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: 0 1px 3px var(--shadow);
        border: 1px solid var(--border);
    }

    .controls-grid {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 16px;
        align-items: center;
    }

    /* Search */
    .search-wrapper { 
        position: relative;
    }
    
    .search-icon { 
        position: absolute; 
        left: 16px; 
        top: 50%; 
        transform: translateY(-50%); 
        color: var(--text-tertiary);
        font-size: 18px;
    }
    
    .search-input {
        width: 100%;
        padding: 14px 16px 14px 48px;
        border: 2px solid var(--border);
        border-radius: 12px;
        font-size: 15px;
        background: var(--input-bg);
        color: var(--text);
        transition: all 0.3s ease;
        font-family: inherit;
    }
    
    .search-input:focus { 
        outline: none; 
        border-color: var(--primary); 
        background: var(--card-bg); 
        box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    }

    /* Buttons */
    .btn-group { display: flex; gap: 12px; }
    
    .btn {
        padding: 14px 24px;
        border: none;
        border-radius: 12px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        white-space: nowrap;
        font-family: inherit;
    }
    
    .btn-primary { 
        background: var(--primary); 
        color: white;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
    }
    
    .btn-primary:hover { 
        background: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
    }

    /* Card & Table */
    .card {
        background: var(--card-bg);
        border-radius: 16px;
        box-shadow: 0 1px 3px var(--shadow);
        overflow: hidden;
        border: 1px solid var(--border);
    }

    .table-wrapper { 
        overflow-x: auto;
    }
    
    table { 
        width: 100%; 
        border-collapse: collapse;
    }
    
    thead { 
        background: var(--bg);
        position: sticky; 
        top: 0; 
        z-index: 10;
    }
    
    th { 
        padding: 16px; 
        text-align: left; 
        font-weight: 600; 
        font-size: 12px; 
        text-transform: uppercase; 
        letter-spacing: 0.5px; 
        color: var(--text-secondary); 
        white-space: nowrap;
        border-bottom: 2px solid var(--border);
    }
    
    td { 
        padding: 16px; 
        border-bottom: 1px solid var(--border); 
        font-size: 14px; 
        vertical-align: middle;
    }
    
    tbody tr {
        transition: all 0.2s ease;
    }
    
    tbody tr:hover { 
        background: var(--bg);
        transform: scale(1.001);
    }
    
    /* User Cell */
    .user-cell { 
        display: flex; 
        align-items: center; 
        gap: 12px;
    }
    
    .user-avatar { 
        width: 40px; 
        height: 40px; 
        border-radius: 50%; 
        background: linear-gradient(135deg, var(--primary), var(--purple));
        color: white; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        font-weight: 600; 
        font-size: 16px; 
        flex-shrink: 0;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.2);
    }
    
    .user-name { 
        font-weight: 600; 
        color: var(--text);
    }
    
    .user-email { 
        font-size: 13px; 
        color: var(--text-tertiary);
    }
    
    /* Key Code */
    .key-code { 
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px; 
        background: var(--primary-light);
        border-radius: 8px; 
        font-family: 'Courier New', monospace; 
        font-weight: 600; 
        font-size: 13px; 
        color: var(--primary);
    }

    /* Remarks */
    .remarks-cell { 
        max-width: 200px; 
        overflow: hidden; 
        text-overflow: ellipsis; 
        white-space: nowrap; 
        color: var(--text-secondary);
    }

    /* Status Badges */
    .badge { 
        padding: 6px 12px; 
        border-radius: 20px; 
        font-size: 11px; 
        font-weight: 700; 
        text-transform: uppercase; 
        letter-spacing: 0.5px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        white-space: nowrap;
    }
    
    .badge-reported, .badge-lost { 
        background: var(--danger-light); 
        color: var(--danger);
    }
    
    .badge-found { 
        background: var(--success-light); 
        color: var(--success);
    }
    
    .badge-replaced { 
        background: var(--info-light); 
        color: var(--info);
    }

    /* Actions */
    .actions { 
        display: flex; 
        gap: 8px; 
        justify-content: center;
    }
    
    .btn-action { 
        width: 36px; 
        height: 36px; 
        border: none;
        border-radius: 8px; 
        cursor: pointer; 
        display: inline-flex; 
        align-items: center; 
        justify-content: center; 
        transition: all 0.2s ease; 
        background: var(--bg);
        color: var(--text-secondary);
        font-size: 14px;
    }
    
    .btn-action:hover { 
        transform: translateY(-2px); 
        box-shadow: 0 4px 12px var(--shadow-md);
    }
    
    .btn-edit { background: var(--warning-light); color: var(--warning); }
    .btn-edit:hover { background: var(--warning); color: white; }
    
    .btn-found { background: var(--success-light); color: var(--success); }
    .btn-found:hover { background: var(--success); color: white; }
    
    .btn-replace { background: var(--info-light); color: var(--info); }
    .btn-replace:hover { background: var(--info); color: white; }
    
    .btn-delete { background: var(--danger-light); color: var(--danger); }
    .btn-delete:hover { background: var(--danger); color: white; }
    
    /* Alerts */
    .alert { 
        padding: 16px 20px; 
        border-radius: 12px; 
        margin-bottom: 24px; 
        display: flex; 
        align-items: center; 
        gap: 12px; 
        font-weight: 500;
        animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }
    
    .alert-success { 
        background: var(--success-light); 
        color: var(--success); 
        border-left: 4px solid var(--success);
    }
    
    .alert-error { 
        background: var(--danger-light); 
        color: var(--danger); 
        border-left: 4px solid var(--danger);
    }

    .no-data { 
        text-align: center; 
        padding: 60px 20px !important; 
        color: var(--text-tertiary); 
        font-size: 15px;
    }

    .no-data i {
        font-size: 48px;
        margin-bottom: 12px;
        display: block;
        opacity: 0.5;
    }

    /* Responsive */
    @media screen and (max-width: 1024px) {
        .controls-grid { grid-template-columns: 1fr; }
        .btn-group { width: 100%; }
        .btn { flex: 1; justify-content: center; }
    }
    
    @media screen and (max-width: 768px) {
        body { padding: 16px; }
        .header { padding: 24px; }
        .header h1 { font-size: 24px; }
        .table-wrapper { overflow-x: scroll; } 
        table { min-width: 900px; }
        td, th { padding: 12px 8px; }
    }

    @media screen and (max-width: 480px) {
        .header h1 { font-size: 20px; }
        .header { padding: 20px; }
    }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="header-content">
            <h1><i class="fa-solid fa-key"></i> Lost Keys Management</h1>
        </div>
    </div>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success" id="autoDismissAlert">
            <i class="fa-solid fa-circle-check"></i>
            Record deleted successfully.
        </div>
    <?php elseif (isset($_GET['updated'])): ?>
        <div class="alert alert-success" id="autoDismissAlert">
            <i class="fa-solid fa-circle-check"></i>
            Status updated successfully. The corresponding key record has also been updated.
        </div>
    <?php elseif (isset($_GET['added'])): ?>
        <div class="alert alert-success" id="autoDismissAlert">
            <i class="fa-solid fa-circle-check"></i>
            Lost key record added successfully.
        </div>
    <?php elseif (isset($_GET['edited'])): ?>
        <div class="alert alert-success" id="autoDismissAlert">
            <i class="fa-solid fa-circle-check"></i>
            Record details updated successfully.
        </div>
    <?php elseif (isset($_GET['error'])): ?>
        <div class="alert alert-error" id="autoDismissAlert">
            <i class="fa-solid fa-circle-exclamation"></i>
            An error occurred while processing your request. Please check server logs.
        </div>
    <?php endif; ?>

    <div class="controls">
        <div class="controls-grid">
            <div class="search-wrapper">
                <i class="search-icon fa-solid fa-magnifying-glass"></i>
                <input type="text" id="searchInput" class="search-input" placeholder="Search by user, key code, location, or status...">
            </div>
            <div class="btn-group">
                <a href="add_lost.php" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i>
                    Add Lost Key
                </a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Reported By</th>
                        <th>Key Code</th>
                        <th>Last Location</th>
                        <th>Remarks</th>
                        <th>Status</th>
                        <th>Date Reported</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <?= renderTableRows($lostKeys, $statusBadgeMap); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// --- Live Search Logic ---
let typingTimer;
const searchInput = document.getElementById('searchInput');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const search = searchInput.value;
        fetch(`lost_key.php?ajax=1&search=${encodeURIComponent(search)}`)
            .then(res => res.text())
            .then(data => {
                tableBody.innerHTML = data;
                attachDeleteHandlers();
            });
    }, 300);
});

// --- Delete and Status Update Handlers ---

// 1. Status Update Confirmation
function confirmUpdate(id, newStatus, title, text, icon) {
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        showCancelButton: true,
        confirmButtonColor: icon === 'success' ? '#10b981' : '#06b6d4',
        cancelButtonColor: '#94a3b8',
        confirmButtonText: 'Yes, Confirm',
        cancelButtonText: 'Cancel',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `lost_key.php?update=${id}&status=${newStatus}`;
        }
    });
}

// 2. Delete Confirmation
function attachDeleteHandlers() {
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const id = this.dataset.id;

            Swal.fire({
                title: 'Delete Lost Key Record?',
                text: 'This removes the report history, but does NOT change the physical key status if it was already marked LOST/FOUND/REPLACED.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'Yes, Delete Record',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'lost_key.php?delete=' + id;
                }
            });
        });
    });
}

// 3. Auto-dismiss alerts and initial setup
document.addEventListener('DOMContentLoaded', () => {
    const alert = document.getElementById('autoDismissAlert');
    if (alert) {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s ease';
            setTimeout(() => {
                alert.remove();
            }, 500);
        }, 5000);
    }
    attachDeleteHandlers();
});

// Load theme
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
        document.body.classList.add('dark');
    }
});

// Expose confirmUpdate globally
window.confirmUpdate = confirmUpdate; 
</script>
</body>
</html>