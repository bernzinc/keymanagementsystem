<?php
require_once '../includes/functions.php';
// Assuming $pdo is available after requiring functions.php
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: keys.php');
    exit;
}

// 1. Fetch key data
$stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE KeyID = :id");
$stmt->execute([':id' => $id]);
$key = $stmt->fetch();

if (!$key) {
    // Better user feedback for not found key
    echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Key Not Found</title><link rel='stylesheet' href='../assets/theme.css'></head><body><div style='text-align:center; padding: 50px;'><h1>404</h1><p>Key with ID **" . htmlspecialchars($id) . "** not found.</p><a href='keys.php' style='text-decoration:none; color: var(--primary); font-weight: 600;'>← Back to Keys List</a></div></body></html>";
    exit;
}

$msg = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic form validation
    if (empty($_POST['Room_ID']) || empty($_POST['Key_Code']) || empty($_POST['Location']) || empty($_POST['Status'])) {
        $error = "All fields are required and must be filled.";
    } else {
        try {
            $room = trim($_POST['Room_ID']);
            $code = trim($_POST['Key_Code']);
            $location = trim($_POST['Location']);
            $status = $_POST['Status'];

            // 2. Update record
            $stmt = $pdo->prepare("UPDATE `keys_m` 
                                 SET Room_ID=:r, Location=:l, Key_Code=:k, QRCode=:q, Status=:s 
                                 WHERE KeyID=:id");
            $stmt->execute([
                ':r' => $room,
                ':k' => $code,
                ':q' => $code,
                ':l' => $location,
                ':s' => $status,
                ':id' => $id
            ]);

            $msg = "Key **" . htmlspecialchars($code) . "** updated successfully!";

            // 3. Reload updated record to display newest data
            $stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE KeyID = :id");
            $stmt->execute([':id' => $id]);
            $key = $stmt->fetch();
        } catch (PDOException $e) {
            $error = "Database error: Failed to update key. Check key code uniqueness.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Key - ID <?= htmlspecialchars($key['KeyID']) ?></title>
<link rel="stylesheet" href="../assets/theme.css">

<style>
    /* Re-defining core variables for standalone testing/reference */
    :root {
        --primary: #3b82f6;
        --primary-dark: #2563eb;
        --success: #10b981;
        --danger: #ef4444;
        --warning: #f59e0b;
        --bg: #f1f5f9;
        --text: #1e293b;
        --card-bg: #ffffff;
        --border: #e2e8f0;
        --shadow: rgba(0, 0, 0, 0.1);
        --input-bg: #f8fafc;
    }

    body.dark {
        --bg: #0f172a;
        --text: #f1f5f9;
        --card-bg: #1e293b;
        --border: #334155;
        --shadow: rgba(0, 0, 0, 0.3);
        --input-bg: #0f172a;
    }

    /* --- Layout & Card Styling (Consistent with Add Key) --- */
    body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        padding: 24px;
        transition: all 0.3s ease;
    }

    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 48px);
    }

    .form-card {
        background: var(--card-bg);
        color: var(--text);
        padding: 32px;
        max-width: 500px;
        width: 100%;
        border-radius: 16px;
        box-shadow: 0 4px 12px var(--shadow);
        border: 1px solid var(--border);
        animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    h2 {
        text-align: center;
        margin-bottom: 24px;
        font-size: 24px;
        font-weight: 700;
        color: var(--primary-dark);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }

    .key-id-tag {
        font-size: 14px;
        font-weight: 600;
        background: var(--bg);
        padding: 4px 10px;
        border-radius: 8px;
        color: var(--text);
    }
    
    /* --- Form Elements --- */
    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--text);
        font-size: 14px;
    }

    .input-field {
        width: 100%;
        padding: 12px 16px;
        border: 2px solid var(--border);
        border-radius: 10px;
        font-size: 15px;
        background: var(--input-bg);
        color: var(--text);
        transition: all 0.3s ease;
        box-sizing: border-box;
        height: 48px;
    }

    .input-field:focus {
        outline: none;
        border-color: var(--primary);
        background: var(--card-bg);
        box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    }

    select.input-field {
        /* Custom appearance for select */
        appearance: none;
        background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%2364748b' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 16px center;
        background-size: 10px 6px;
        padding-right: 40px;
    }

    /* Status specific styling for select */
    select.input-field.status-available { color: var(--success); }
    select.input-field.status-borrowed { color: var(--warning); }
    select.input-field.status-lost { color: var(--danger); }
    select.input-field.status-replaced { color: #8472E8; }

    /* --- Buttons --- */
    .actions-group {
        text-align: center;
        margin-top: 30px;
        display: flex;
        gap: 12px;
        justify-content: center;
    }

    .btn {
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
    }

    .btn-secondary {
        background: var(--input-bg);
        color: var(--text);
        border: 2px solid var(--border);
    }

    .btn-secondary:hover {
        background: var(--border);
    }

    /* --- Alerts and QR Preview --- */
    .alert {
        padding: 14px 18px;
        border-radius: 10px;
        margin-bottom: 20px;
        text-align: center;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
        justify-content: center;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border-left: 4px solid var(--success);
    }

    .qr-preview {
        text-align: center;
        margin-top: 20px;
        padding: 15px;
        background: var(--bg);
        border-radius: 10px;
        border: 1px solid var(--border);
    }

    .qr-image {
        width: 100px;
        height: 100px;
        border-radius: 6px;
        box-shadow: 0 2px 4px var(--shadow);
        transition: transform 0.3s ease;
    }

    /* Mobile Adjustments */
    @media (max-width: 600px) {
        .form-card {
            padding: 20px;
        }
        .actions-group {
            flex-direction: column;
        }
        .btn {
            width: 100%;
        }
    }
</style>
</head>
<body>

<div class="container">
    <div class="form-card">
        <h2>
            <span class="key-id-tag">ID: <?= htmlspecialchars($key['KeyID']) ?></span>
            <span>Edit Key</span>
        </h2>

        <?php if ($msg): ?>
            <div class="alert alert-success">
                <span>✅</span>
                <?= $msg ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="room_id">Room ID:</label>
                <input type="text" name="Room_ID" id="room_id" class="input-field" 
                    value="<?= htmlspecialchars($key['Room_ID']) ?>" required>
            </div>

            <div class="form-group">
                <label for="key_code">Key Code:</label>
                <input type="text" name="Key_Code" id="key_code" class="input-field" 
                    value="<?= htmlspecialchars($key['Key_Code']) ?>" required oninput="updateQR()">
            </div>

            <div class="form-group">
                <label for="location">Location (Building/Area):</label>
                <input type="text" name="Location" id="location" class="input-field" 
                    value="<?= htmlspecialchars($key['Location']) ?>" required 
                    placeholder="e.g., Main Building - 3rd Floor">
            </div>

            <div class="form-group">
                <label for="status">Status:</label>
                <?php 
                    $current_status = htmlspecialchars($key['Status']); 
                    $status_class = strtolower($current_status);
                ?>
                <select name="Status" id="status" class="input-field status-<?= $status_class ?>" onchange="this.className = 'input-field status-' + this.value.toLowerCase()">
                    <option value="Available" <?= $current_status=='Available'?'selected':'' ?>>Available</option>
                    <option value="Borrowed" <?= $current_status=='Borrowed'?'selected':'' ?>>Borrowed</option>
                    <option value="Replaced" <?= $current_status=='Replaced'?'selected':'' ?>>Replaced</option>
                    <option value="Lost" <?= $current_status=='Lost'?'selected':'' ?>>Lost</option>
                </select>
            </div>

            <div class="qr-preview" id="qrPreview">
                <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($key['Key_Code']) ?>&size=100x100" class="qr-image" alt="QR Code">
            </div>

            <div class="actions-group">
                <button type="submit" class="btn btn-primary">
                    💾 Save Changes
                </button>
                <button type="button" class="btn btn-secondary" onclick="window.location.href='keys.php'">
                    ← Back to Keys List
                </button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/theme.js"></script>
<script>
// Function to update the QR code image dynamically
function updateQR() {
    const code = document.getElementById('key_code').value.trim();
    const qrDiv = document.getElementById('qrPreview');
    
    if (code) {
        // Use a smaller size (100x100) for better fit in the card
        qrDiv.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(code)}&size=100x100" class='qr-image' alt='QR Code for key: ${code}'>`;
    } else {
        // Fallback or placeholder if code is cleared
        qrDiv.innerHTML = '<p style="color: #94a3b8; font-style: italic;">Enter Key Code to generate QR Preview.</p>';
    }
}

// Function to update the select box class based on its value
document.addEventListener('DOMContentLoaded', () => {
    const statusSelect = document.getElementById('status');
    // Initialize class on load
    statusSelect.className = 'input-field status-' + statusSelect.value.toLowerCase();
});

// The onchange handler is already set in the HTML for real-time class update
</script>
</body>
</html>