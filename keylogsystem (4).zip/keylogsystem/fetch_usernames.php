<?php
require_once 'includes/functions.php';
requireAdmin();
header('Content-Type: application/json');

$stmt = $pdo->query("SELECT CONCAT(Fname, ' ', Lname) AS FullName FROM users ORDER BY Fname ASC");
$usernames = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode($usernames);
