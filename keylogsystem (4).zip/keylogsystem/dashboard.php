<?php
require_once 'includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

// --- AUTO CHECK OVERDUE KEYS ---
$today = date('Y-m-d H:i:s');
$sql = "
    SELECT l.LogID, l.UserID, u.Email, u.Lname, u.Fname, k.Key_Code, k.Room_ID, l.DueDate
    FROM logs l
    JOIN users u ON l.UserID = u.UserID
    JOIN keys_m k ON l.KeyID = k.KeyID
    WHERE l.Status != 'Returned'
      AND l.DueDate IS NOT NULL
      AND l.DueDate < ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$today]);
$overdueLogs = $stmt->fetchAll();

foreach ($overdueLogs as $log) {
    $update = $pdo->prepare("UPDATE logs SET Status = 'Overdue' WHERE LogID = ?");
    $update->execute([$log['LogID']]);
}

// --- FETCH TOTALS ---
$total_keys = $pdo->query("SELECT COUNT(*) FROM keys_m")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_logs = $pdo->query("SELECT COUNT(*) FROM logs")->fetchColumn();
$total_overdue = $pdo->query("SELECT COUNT(*) FROM logs WHERE Status='Overdue'")->fetchColumn();
$total_lost = $pdo->query("SELECT COUNT(*) FROM lost_keys")->fetchColumn();
$borrowed_today = $pdo->query("SELECT COUNT(*) FROM logs WHERE Date = CURDATE() AND Status='Borrowed'")->fetchColumn();

// --- FETCH UNREAD NOTIFICATIONS ---
$unread_notifications = $pdo->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0")->fetchColumn();

// --- FETCH RECENT LOGS ---
$logs = $pdo->query("
    SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) AS FullName, k.Location,
           l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
    FROM logs l
    JOIN users u ON l.UserID = u.UserID
    JOIN keys_m k ON l.KeyID = k.KeyID
    ORDER BY l.LogID DESC
    LIMIT 10
")->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Dashboard - ADFC Key Management</title>
<style>
:root {
    --primary: #3b82f6;
    --primary-dark: #2563eb;
    --primary-light: #93c5fd;
    --secondary: #8b5cf6;
    --success: #10b981;
    --warning: #f59e0b;
    --danger: #ef4444;
    --info: #06b6d4;
    --bg: #f8fafc;
    --text: #1e293b;
    --card-bg: #ffffff;
    --sidebar-bg: #1e293b;
    --sidebar-hover: #334155;
    --border: #e2e8f0;
    --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
}

body.dark {
    --bg: #0f172a;
    --text: #f1f5f9;
    --card-bg: #1e293b;
    --sidebar-bg: #020617;
    --sidebar-hover: #1e293b;
    --border: #334155;
    --shadow: 0 1px 3px rgba(0, 0, 0, 0.5);
    --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.5);
    --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.5);
}

* { 
    box-sizing: border-box; 
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    min-height: 100vh;
    transition: all 0.3s ease;
}

/* Sidebar Styles */
.sidebar {
    width: 280px;
    background: var(--sidebar-bg);
    padding: 24px 16px;
    display: flex;
    flex-direction: column;
    box-shadow: 4px 0 16px var(--shadow);
    position: fixed;
    height: 100vh;
    overflow-y: auto;
    z-index: 1000;
    transition: transform 0.3s ease;
}

.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-thumb {
    background: var(--sidebar-hover);
    border-radius: 3px;
}

.sidebar-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 12px;
    margin-bottom: 24px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 12px;
}

.logo {
    width: 48px;
    height: 48px;
    background: white;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.sidebar-title {
    color: white;
    font-size: 16px;
    font-weight: 700;
    line-height: 1.3;
}

.nav-section {
    margin-bottom: 24px;
}

.nav-label {
    color: #94a3b8;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 0 16px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.nav-label::before {
    content: '';
    flex: 1;
    height: 1px;
    background: #334155;
}

.nav-item {
    width: 100%;
    padding: 12px 16px;
    margin-bottom: 4px;
    border: none;
    border-radius: 12px;
    background: transparent;
    color: #cbd5e1;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.2s ease;
    text-align: left;
    position: relative;
}

.nav-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 3px;
    height: 0;
    background: var(--primary);
    border-radius: 0 3px 3px 0;
    transition: height 0.2s ease;
}

.nav-item:hover {
    background: var(--sidebar-hover);
    color: white;
    transform: translateX(4px);
}

.nav-item:hover::before {
    height: 70%;
}

.nav-item.active {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.nav-item.active::before {
    height: 100%;
}

.nav-icon {
    font-size: 20px;
    width: 24px;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
}

.nav-icon svg {
    stroke: currentColor;
    transition: transform 0.2s;
}

.nav-item:hover .nav-icon svg {
    transform: scale(1.1);
}

.logout-btn {
    margin-top: auto;
    background: var(--danger) !important;
    color: white !important;
}

.logout-btn:hover {
    background: #dc2626 !important;
    transform: translateX(0) !important;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4) !important;
}

/* Main Content */
.main-content {
    flex: 1;
    margin-left: 280px;
    transition: margin-left 0.3s ease;
}

.topbar {
    background: var(--card-bg);
    padding: 20px 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px var(--shadow);
    position: sticky;
    top: 0;
    z-index: 100;
    border-bottom: 1px solid var(--border);
}

.topbar-left h1 {
    font-size: 26px;
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 4px;
}

.topbar-left p {
    font-size: 13px;
    color: #64748b;
    font-weight: 500;
}

.topbar-right {
    display: flex;
    align-items: center;
    gap: 16px;
}

/* Notification Bell */
.notification-bell {
    position: relative;
    width: 44px;
    height: 44px;
    background: var(--bg);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    border: 2px solid var(--border);
}

.notification-bell:hover {
    background: var(--border);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.notification-bell svg {
    width: 22px;
    height: 22px;
    stroke: var(--text);
}

.notification-badge {
    position: absolute;
    top: -6px;
    right: -6px;
    background: linear-gradient(135deg, var(--danger), #dc2626);
    color: white;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 7px;
    border-radius: 12px;
    min-width: 20px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(239, 68, 68, 0.4);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

.theme-toggle {
    width: 64px;
    height: 32px;
    background: #cbd5e1;
    border-radius: 32px;
    cursor: pointer;
    position: relative;
    transition: background 0.3s;
    border: 2px solid var(--border);
}

.theme-toggle::after {
    content: '☀️';
    position: absolute;
    width: 28px;
    height: 28px;
    background: white;
    border-radius: 50%;
    top: 0px;
    left: 2px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    transition: transform 0.3s;
    box-shadow: 0 2px 8px var(--shadow);
}

.theme-toggle.active {
    background: var(--primary);
}

.theme-toggle.active::after {
    content: '🌙';
    transform: translateX(32px);
}

.admin-badge {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    padding: 10px 20px;
    border-radius: 24px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Content Area */
.content {
    padding: 32px;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Content Sections */
.content-section {
    display: none;
}

.content-section.active {
    display: block;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 24px;
    margin-bottom: 32px;
}

.stat-card {
    background: var(--card-bg);
    border-radius: 20px;
    padding: 28px;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
}

.stat-card:hover {
    transform: translateY(-6px);
    box-shadow: var(--shadow-lg);
}

.stat-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.stat-title {
    font-size: 13px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    margin-bottom: 12px;
}

.stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    background: var(--bg);
    box-shadow: 0 4px 8px var(--shadow);
}

.stat-value {
    font-size: 40px;
    font-weight: 800;
    color: var(--text);
    margin-bottom: 8px;
    line-height: 1;
}

.stat-change {
    font-size: 13px;
    color: var(--success);
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 4px;
}

/* QR Scanner Card */
.scanner-card {
    grid-column: span 2;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
}

.scanner-card::before {
    display: none;
}

.scanner-card .stat-title {
    color: rgba(255, 255, 255, 0.95);
}

.scanner-card .stat-icon {
    background: rgba(255, 255, 255, 0.2);
    color: white;
}

#qr-reader {
    width: 100%;
    max-width: 320px;
    margin: 20px auto;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
}

#scan-result {
    margin-top: 16px;
    font-size: 14px;
    color: rgba(255, 255, 255, 0.95);
    font-weight: 600;
    text-align: center;
}

/* Logs Table */
.logs-section {
    background: var(--card-bg);
    border-radius: 20px;
    padding: 28px;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 2px solid var(--border);
}

.section-title {
    font-size: 22px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
}

.section-title::before {
    content: '';
    width: 4px;
    height: 28px;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    border-radius: 4px;
}

.table-wrapper {
    overflow-x: auto;
    border-radius: 12px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead th {
    background: var(--bg);
    padding: 16px;
    text-align: left;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
    border-bottom: 2px solid var(--border);
    white-space: nowrap;
}

tbody td {
    padding: 18px 16px;
    border-bottom: 1px solid var(--border);
    font-size: 14px;
}

tbody tr {
    transition: all 0.2s;
}

tbody tr:hover {
    background: var(--bg);
    transform: scale(1.01);
}

tbody tr:last-child td {
    border-bottom: none;
}

.key-code-cell {
    font-family: 'Courier New', monospace;
    font-weight: 700;
    color: var(--primary);
    font-size: 15px;
}

.status-badge {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    display: inline-block;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-returned {
    background: #d1fae5;
    color: #065f46;
}

.status-borrowed {
    background: #dbeafe;
    color: #1e40af;
}

.status-overdue {
    background: #fee2e2;
    color: #991b1b;
}

/* Iframe Section */
.iframe-section {
    background: var(--card-bg);
    border-radius: 20px;
    padding: 28px;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
}

.iframe-section iframe {
    width: 100%;
    min-height: 80vh;
    border: none;
    border-radius: 16px;
    box-shadow: inset 0 2px 8px var(--shadow);
}

/* Hamburger Menu */
.hamburger {
    display: none;
    flex-direction: column;
    gap: 5px;
    cursor: pointer;
    padding: 10px;
    border-radius: 8px;
    transition: all 0.2s;
}

.hamburger:hover {
    background: var(--bg);
}

.hamburger span {
    width: 26px;
    height: 3px;
    background: var(--text);
    border-radius: 3px;
    transition: all 0.3s;
}

.sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 999;
}

/* Mobile Responsive */
@media (max-width: 1280px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .scanner-card {
        grid-column: span 1;
    }
}

@media (max-width: 768px) {
    .hamburger {
        display: flex;
    }

    .sidebar {
        transform: translateX(-100%);
    }

    .sidebar.active {
        transform: translateX(0);
    }

    .sidebar-overlay.active {
        display: block;
    }

    .main-content {
        margin-left: 0;
    }

    .topbar {
        padding: 16px 20px;
    }

    .topbar-left h1 {
        font-size: 20px;
    }

    .topbar-right {
        gap: 12px;
    }

    .admin-badge {
        display: none;
    }

    .content {
        padding: 20px 16px;
    }

    .stats-grid {
        grid-template-columns: 1fr;
        gap: 16px;
    }

    .stat-card {
        padding: 20px;
    }

    .stat-value {
        font-size: 32px;
    }

    .table-wrapper {
        margin: 0 -28px;
        padding: 0 28px;
    }

    thead th,
    tbody td {
        padding: 14px 10px;
        font-size: 13px;
    }

    table {
        min-width: 900px;
    }
}

/* Animations */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card {
    animation: slideIn 0.5s ease forwards;
    opacity: 0;
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }
.stat-card:nth-child(5) { animation-delay: 0.5s; }
.stat-card:nth-child(6) { animation-delay: 0.6s; }

@keyframes bellShake {
    0%, 100% { transform: rotate(0deg); }
    10%, 30%, 50%, 70%, 90% { transform: rotate(-12deg); }
    20%, 40%, 60%, 80% { transform: rotate(12deg); }
}

.notification-bell:hover svg {
    animation: bellShake 0.6s;
}
</style>
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="images/logoo.png" alt="ADFC Logo">
        </div>
        <div class="sidebar-title">KEY LOG<br>SYSTEM</div>
    </div>

    <nav>
        <div class="nav-section">
            <div class="nav-label">Main</div>
            <button class="nav-item active" data-section="dashboard">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                </span>
                Dashboard
            </button>
            <button class="nav-item" data-page="scanner/scanner.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
                </span>
                Manual Scanning
            </button>
        </div>

        <div class="nav-section">
            <div class="nav-label">Management</div>
            <button class="nav-item" data-page="key_management/keys.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>
                </span>
                Keys
            </button>
            <button class="nav-item" data-page="user_management/users.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                </span>
                Key Users
            </button>
            <button class="nav-item" data-page="keylogs_management/logs.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                </span>
                Key Logs
            </button>
        </div>

        <div class="nav-section">
            <div class="nav-label">Reports</div>
            <button class="nav-item" data-page="scanner/update_overdue.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                </span>
                Overdue Logs
            </button>
            <button class="nav-item" data-page="lost_key/lost_key.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg>
                </span>
                Lost Keys
            </button>
            <button class="nav-item" data-page="report_generation/reports.php">
                <span class="nav-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="12" y1="9" x2="8" y2="9"></line></svg>
                </span>
                Reports
            </button>
        </div>
    </nav>

    <button class="nav-item logout-btn" id="logoutBtn">
        <span class="nav-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
        </span>
        Logout
    </button>
</aside>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Bar -->
    <header class="topbar">
        <div style="display: flex; align-items: center; gap: 20px;">
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="topbar-left">
                <h1 id="pageTitle">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                    Dashboard
                </h1>
                <p><?= date('l, F j, Y') ?></p>
            </div>
        </div>
        <div class="topbar-right">
            <div class="theme-toggle" id="themeToggle"></div>
            <div class="admin-badge">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                ADMIN
            </div>
        </div>
    </header>

    <!-- Content -->
    <main class="content">
        <!-- Dashboard Section -->
        <div id="dashboard-section" class="content-section active">
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Total Keys</div>
                            <div class="stat-value"><?= $total_keys ?></div>
                            <div class="stat-change">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"></polyline></svg>
                                Active
                            </div>
                        </div>
                        <div class="stat-icon" style="background: #dbeafe; color: #1e40af;">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Total Users</div>
                            <div class="stat-value"><?= $total_users ?></div>
                            <div class="stat-change">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"></polyline></svg>
                                Registered
                            </div>
                        </div>
                        <div class="stat-icon" style="background: #f3e8ff; color: #7c3aed;">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Total Logs</div>
                            <div class="stat-value"><?= $total_logs ?></div>
                            <div class="stat-change">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="18 15 12 9 6 15"></polyline></svg>
                                Records
                            </div>
                        </div>
                        <div class="stat-icon" style="background: #d1fae5; color: #065f46;">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Overdue Keys</div>
                            <div class="stat-value"><?= $total_overdue ?></div>
                            <div class="stat-change" style="color: var(--danger);">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                                Attention
                            </div>
                        </div>
                        <div class="stat-icon" style="background: #fee2e2; color: #991b1b;">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                        </div>
                    </div>
                </div>

                <div class="stat-card scanner-card">
                    <div class="stat-header">
                        <div style="width: 100%;">
                            <div class="stat-title">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line><line x1="2" y1="7" x2="7" y2="7"></line><line x1="2" y1="17" x2="7" y2="17"></line><line x1="17" y1="17" x2="22" y2="17"></line><line x1="17" y1="7" x2="22" y2="7"></line></svg>
                                QR Key Scanner
                            </div>
                            <div id="qr-reader"></div>
                            <p id="scan-result">Ready to scan...</p>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Lost Keys</div>
                            <div class="stat-value"><?= $total_lost ?></div>
                            <div class="stat-change" style="color: var(--warning);">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg>
                                Track
                            </div>
                        </div>
                        <div class="stat-icon" style="background: #fef3c7; color: #92400e;">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Logs Table -->
            <section class="logs-section">
                <div class="section-header">
                    <h2 class="section-title">Recent Key Logs</h2>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Key Code</th>
                                <th>User</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Time Borrowed</th>
                                <th>Time Returned</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="key-code-cell"><?= htmlspecialchars($log['Key_Code']) ?></td>
                                <td><strong><?= htmlspecialchars($log['FullName']) ?></strong></td>
                                <td><?= htmlspecialchars($log['Location']) ?></td>
                                <td><?= htmlspecialchars($log['Date']) ?></td>
                                <td><?= htmlspecialchars($log['TimeBorrowed']) ?></td>
                                <td><?= htmlspecialchars($log['TimeReturned'] ?? '—') ?></td>
                                <td>
                                    <span class="status-badge status-<?= strtolower($log['Status']) ?>">
                                        <?= htmlspecialchars($log['Status']) ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>

        <!-- Iframe Section for Other Pages -->
        <div id="iframe-section" class="content-section iframe-section">
            <iframe id="contentFrame"></iframe>
        </div>
    </main>
</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/html5-qrcode"></script>
<script>
// Navigation System
const navItems = document.querySelectorAll('.nav-item');
const dashboardSection = document.getElementById('dashboard-section');
const iframeSection = document.getElementById('iframe-section');
const contentFrame = document.getElementById('contentFrame');
const pageTitle = document.getElementById('pageTitle');

function showDashboard() {
    dashboardSection.classList.add('active');
    iframeSection.classList.remove('active');
    pageTitle.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>Dashboard';
    
    // Update active state
    navItems.forEach(item => item.classList.remove('active'));
    document.querySelector('[data-section="dashboard"]').classList.add('active');
}

function showPage(url, title) {
    dashboardSection.classList.remove('active');
    iframeSection.classList.add('active');
    contentFrame.src = url;
    pageTitle.innerHTML = title;
}

// Navigation click handlers
navItems.forEach(item => {
    item.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Close mobile menu if open
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
        
        const section = this.getAttribute('data-section');
        const page = this.getAttribute('data-page');
        
        if (section === 'dashboard') {
            showDashboard();
        } else if (page) {
            const titles = {
                'scanner/scanner.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>Manual Scanning',
                'key_management/keys.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>Key Management',
                'user_management/users.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>User Management',
                'keylogs_management/logs.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>Key Logs',
                'scanner/update_overdue.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>Overdue Logs',
                'lost_key/lost_key.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg>Lost Keys',
                'report_generation/reports.php': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 8px;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>Reports'
            };
            
            showPage(page, titles[page] || 'Page');
            
            // Update active state
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        }
    });
});

// Hamburger Menu
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');

hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
});

overlay.addEventListener('click', () => {
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
});

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const body = document.body;

if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark');
    themeToggle.classList.add('active');
}

themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark');
    themeToggle.classList.toggle('active');
    localStorage.setItem('theme', body.classList.contains('dark') ? 'dark' : 'light');
});

// QR Scanner
const qrReader = new Html5Qrcode("qr-reader");

function startScanner() {
    qrReader.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: 250 },
        qrCodeMessage => {
            document.getElementById('scan-result').innerText = "✓ Scanned: " + qrCodeMessage;
            qrReader.stop();

            fetch('fetch_usernames.php')
                .then(res => res.json())
                .then(usernames => {
                    const dataList = document.createElement('datalist');
                    dataList.id = 'usernamesList';
                    usernames.forEach(name => {
                        const option = document.createElement('option');
                        option.value = name;
                        dataList.appendChild(option);
                    });
                    document.body.appendChild(dataList);

                    Swal.fire({
                        title: "🔍 Scan Result",
                        html: `
                            <div style="text-align: left; margin: 20px 0;">
                                <div style="background: #f1f5f9; padding: 16px; border-radius: 12px; margin-bottom: 20px;">
                                    <p style="font-size: 13px; color: #64748b; margin-bottom: 6px; font-weight: 600;">KEY CODE</p>
                                    <p style="font-size: 18px; font-weight: 700; color: #1e293b; font-family: monospace;">${qrCodeMessage}</p>
                                </div>
                                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #64748b; font-size: 13px;">USER NAME</label>
                                <input list="usernamesList" id="fullnameInput" class="swal2-input" placeholder="Type or select full name" style="width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 15px;">
                            </div>
                        `,
                        showCancelButton: true,
                        confirmButtonText: "Submit",
                        cancelButtonText: "Cancel",
                        confirmButtonColor: '#3b82f6',
                        cancelButtonColor: '#64748b',
                        width: '500px',
                        preConfirm: () => {
                            const fullname = document.getElementById('fullnameInput').value.trim();
                            if (!fullname) {
                                Swal.showValidationMessage("Please enter full name");
                                return false;
                            }
                            return fullname;
                        }
                    }).then(result => {
                        if (result.isConfirmed) {
                            processScan(qrCodeMessage, result.value);
                        } else {
                            startScanner();
                        }
                    });
                });
        }
    ).catch(err => {
        document.getElementById('scan-result').innerText = "Camera permission required";
        console.error('QR Scanner Error:', err);
    });
}

function processScan(keyCode, fullname) {
    fetch('scanner/borrow_return_key.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `key_code=${encodeURIComponent(keyCode)}&fullname=${encodeURIComponent(fullname)}`
    })
    .then(res => res.json())
    .then(data => {
        Swal.fire({
            icon: data.success ? "success" : "error",
            title: data.message,
            confirmButtonColor: '#3b82f6',
            timer: 3000
        }).then(() => {
            updateLogsTable();
            startScanner();
        });
    })
    .catch(() => {
        Swal.fire({
            icon: "error",
            title: "Error",
            text: "Request failed.",
            confirmButtonColor: '#ef4444'
        });
        startScanner();
    });
}

function updateLogsTable() {
    fetch('fetch_logs.php')
    .then(res => res.json())
    .then(logs => {
        const tbody = document.querySelector('tbody');
        tbody.innerHTML = '';
        logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="key-code-cell">${log.Key_Code}</td>
                <td><strong>${log.FullName}</strong></td>
                <td>${log.Location}</td>
                <td>${log.Date}</td>
                <td>${log.TimeBorrowed}</td>
                <td>${log.TimeReturned ?? '—'}</td>
                <td><span class="status-badge status-${log.Status.toLowerCase()}">${log.Status}</span></td>
            `;
            tbody.appendChild(tr);
        });
    });
}

// Start scanner on page load
startScanner();

// Logout
document.getElementById('logoutBtn').addEventListener('click', function () {
    Swal.fire({
        title: 'Logout Confirmation',
        text: "Are you sure you want to logout?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#64748b',
        confirmButtonText: '✓ Yes, Logout',
        cancelButtonText: 'Cancel',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                icon: 'success',
                title: 'Logging out...',
                text: 'See you next time!',
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                window.location.href = 'logout.php';
            });
        }
    });
});

// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
</script>
</body>
</html>