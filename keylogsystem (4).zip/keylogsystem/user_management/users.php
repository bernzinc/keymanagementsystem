<?php
require_once '../includes/functions.php';
requireAdmin();

// 🔍 Handle AJAX search
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $search = $_GET['search'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE Lname LIKE :s OR Fname LIKE :s OR Department LIKE :s OR Role LIKE :s OR Email LIKE :s ORDER BY UserID ASC");
    $stmt->execute([':s' => "%$search%"]);
    $users = $stmt->fetchAll();

    foreach ($users as $u) {
        $roleClass = strtolower($u['Role']) === 'instructor' ? 'instructor' : 'staff';
        echo "<tr>
            <td><span class='name-badge'>" . strtoupper(htmlspecialchars($u['Lname'])) . "</span></td>
            <td><span class='name-badge'>" . strtoupper(htmlspecialchars($u['Fname'])) . "</span></td>
            <td>" . strtoupper(htmlspecialchars($u['Department'])) . "</td>
            <td><span class='role-badge role-{$roleClass}'>" . strtoupper(htmlspecialchars($u['Role'])) . "</span></td>
            <td class='email'>" . htmlspecialchars($u['Email']) . "</td>
            <td class='actions'>
                <a href='view_user.php?id={$u['UserID']}' class='btn-action btn-view' title='View'><i class='fas fa-eye'></i></a>
                <a href='edit_user.php?id={$u['UserID']}' class='btn-action btn-edit' title='Edit'><i class='fas fa-user-edit'></i></a>
                <a href='#' class='btn-action btn-delete' data-id='{$u['UserID']}' title='Delete'><i class='fas fa-trash-alt'></i></a>
            </td>
        </tr>";
    }

    if (empty($users)) echo "<tr><td colspan='6' class='no-data'>No users found.</td></tr>";
    exit;
}

// 🗑 Handle delete action
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM `users` WHERE UserID = :id");
    $stmt->execute([':id' => $id]);
    header("Location: users.php?deleted=1");
    exit;
}

// 📋 Initial load
$stmt = $pdo->query("SELECT * FROM `users` ORDER BY UserID ASC");
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users Management - ADFC</title>

<!-- Font Awesome for Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
:root {
    --primary: #3b82f6;
    --primary-dark: #2563eb;
    --success: #10b981;
    --warning: #f59e0b;
    --danger: #ef4444;
    --purple: #8b5cf6;
    --bg: #f1f5f9;
    --text: #1e293b;
    --card-bg: #ffffff;
    --border: #e2e8f0;
    --shadow: rgba(0, 0, 0, 0.1);
    --input-bg: #f8fafc;
}

body.dark {
    --bg: #0f172a;
    --text: #f1f5f9;
    --card-bg: #1e293b;
    --border: #334155;
    --shadow: rgba(0, 0, 0, 0.3);
    --input-bg: #0f172a;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: var(--bg);
    color: var(--text);
    padding: 24px;
    transition: all 0.3s ease;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
    animation: fadeIn 0.4s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.header {
    background: var(--card-bg);
    padding: 24px 32px;
    border-radius: 16px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px var(--shadow);
    border: 1px solid var(--border);
}

.header-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

h1 {
    font-size: 28px;
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary), var(--purple));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    display: flex;
    align-items: center;
    gap: 12px;
}

h1 i {
    background: linear-gradient(135deg, var(--primary), var(--purple));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.header-actions {
    display: flex;
    gap: 12px;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    font-family: inherit;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn i {
    font-size: 16px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.btn-secondary {
    background: var(--input-bg);
    color: var(--text);
    border: 2px solid var(--border);
}

.btn-secondary:hover {
    background: var(--border);
}

.search-container {
    position: relative;
    max-width: 450px;
}

.search-icon {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 16px;
    color: #94a3b8;
}

.search-input {
    width: 100%;
    padding: 12px 16px 12px 48px;
    border: 2px solid var(--border);
    border-radius: 12px;
    font-size: 15px;
    background: var(--input-bg);
    color: var(--text);
    transition: all 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
    background: var(--card-bg);
    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
}

.alert {
    padding: 14px 18px;
    background: #d1fae5;
    color: #065f46;
    border-radius: 12px;
    margin-bottom: 20px;
    border-left: 4px solid var(--success);
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideIn 0.3s ease;
}

.alert i {
    font-size: 18px;
}

@keyframes slideIn {
    from { opacity: 0; transform: translateX(-20px); }
    to { opacity: 1; transform: translateX(0); }
}

.table-card {
    background: var(--card-bg);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 1px 3px var(--shadow);
    border: 1px solid var(--border);
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead th {
    background: var(--bg);
    padding: 16px;
    text-align: left;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    border-bottom: 2px solid var(--border);
    white-space: nowrap;
}

tbody td {
    padding: 16px;
    border-bottom: 1px solid var(--border);
    font-size: 14px;
}

tbody tr {
    transition: background 0.2s;
}

tbody tr:hover {
    background: var(--bg);
}

.name-badge {
    font-weight: 600;
    color: var(--text);
}

.email {
    color: #64748b;
    font-size: 13px;
}

.role-badge {
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
    text-transform: uppercase;
}

.role-instructor {
    background: #d1fae5;
    color: #065f46;
}

.role-staff {
    background: #fef3c7;
    color: #92400e;
}

.actions {
    display: flex;
    gap: 8px;
}

.btn-action {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    text-decoration: none;
    font-size: 14px;
    transition: all 0.2s ease;
}

.btn-view {
    background: #dbeafe;
    color: #1e40af;
}

.btn-view:hover {
    background: #3b82f6;
    color: white;
    transform: scale(1.1);
}

.btn-edit {
    background: #fef3c7;
    color: #92400e;
}

.btn-edit:hover {
    background: #f59e0b;
    color: white;
    transform: scale(1.1);
}

.btn-delete {
    background: #fee2e2;
    color: #991b1b;
}

.btn-delete:hover {
    background: #ef4444;
    color: white;
    transform: scale(1.1);
}

.no-data {
    text-align: center;
    padding: 40px !important;
    color: #64748b;
    font-style: italic;
}

/* Stats Section */
.stats-bar {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-item {
    background: var(--card-bg);
    padding: 20px;
    border-radius: 12px;
    border: 1px solid var(--border);
    box-shadow: 0 1px 3px var(--shadow);
}

.stat-label {
    font-size: 12px;
    color: #64748b;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
}

.stat-value {
    font-size: 32px;
    font-weight: 700;
    color: var(--text);
}

/* Mobile Responsive */
@media (max-width: 768px) {
    body {
        padding: 16px;
    }

    .header {
        padding: 20px;
    }

    .header-top {
        flex-direction: column;
        align-items: stretch;
        gap: 16px;
    }

    h1 {
        font-size: 22px;
        justify-content: center;
    }

    .header-actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        justify-content: center;
    }

    .search-container {
        max-width: 100%;
    }

    .stats-bar {
        grid-template-columns: 1fr;
    }

    .table-wrapper {
        margin: 0 -20px;
        padding: 0 20px;
    }

    table {
        min-width: 800px;
    }

    thead th,
    tbody td {
        padding: 12px 8px;
        font-size: 13px;
    }

    .btn-action {
        width: 32px;
        height: 32px;
        font-size: 12px;
    }
}

@media (max-width: 480px) {
    h1 {
        font-size: 20px;
    }

    .header {
        padding: 16px;
    }

    thead th,
    tbody td {
        padding: 10px 6px;
        font-size: 12px;
    }

    .stat-value {
        font-size: 24px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="header-top">
            <h1><i class="fas fa-users"></i> Users Management</h1>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="location.href='add_user.php'">
                    <i class="fas fa-user-plus"></i> Add New User
                </button>
            </div>
        </div>

        <?php if (isset($_GET['deleted'])): ?>
            <div class="alert">
                <i class="fas fa-check-circle"></i>
                User deleted successfully!
            </div>
        <?php endif; ?>

        <div class="search-container">
            <i class="fas fa-search search-icon"></i>
            <input 
                type="text" 
                id="searchInput" 
                class="search-input"
                placeholder="Search by name, department, role, or email..."
                autocomplete="off"
            >
        </div>
    </div>

    <div class="table-card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Department</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <?php foreach ($users as $u): ?>
                    <?php $roleClass = strtolower($u['Role']) === 'instructor' ? 'instructor' : 'staff'; ?>
                    <tr>
                        <td><span class="name-badge"><?= strtoupper(htmlspecialchars($u['Lname'])) ?></span></td>
                        <td><span class="name-badge"><?= strtoupper(htmlspecialchars($u['Fname'])) ?></span></td>
                        <td><?= strtoupper(htmlspecialchars($u['Department'])) ?></td>
                        <td><span class="role-badge role-<?= $roleClass ?>"><?= strtoupper(htmlspecialchars($u['Role'])) ?></span></td>
                        <td class="email"><?= htmlspecialchars($u['Email']) ?></td>
                        <td class="actions">
                            <a href="view_user.php?id=<?= $u['UserID'] ?>" class="btn-action btn-view" title="View"><i class="fas fa-eye"></i></a>
                            <a href="edit_user.php?id=<?= $u['UserID'] ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-user-edit"></i></a>
                            <a href="#" class="btn-action btn-delete" data-id="<?= $u['UserID'] ?>" title="Delete"><i class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Load theme
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
        document.body.classList.add('dark');
    }
});

// Live search
let typingTimer;
const searchInput = document.getElementById('searchInput');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const search = searchInput.value;
        fetch(`users.php?ajax=1&search=${encodeURIComponent(search)}`)
            .then(res => res.text())
            .then(data => {
                tableBody.innerHTML = data;
                attachDeleteHandlers();
            });
    }, 300);
});

// Delete confirmation
function attachDeleteHandlers() {
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const id = this.dataset.id;

            Swal.fire({
                title: 'Delete User?',
                text: 'This action cannot be undone',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'users.php?delete=' + id;
                }
            });
        });
    });
}

attachDeleteHandlers();
</script>
</body>
</html>