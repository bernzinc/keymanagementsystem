<?php
require_once '../includes/functions.php';
// Assuming $pdo is available after requiring functions.php
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: users.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE UserID = :id");
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();

if (!$user) {
    // Consistent error page for user not found
    echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>User Not Found</title><link rel='stylesheet' href='../assets/theme.css'></head><body><div style='text-align:center; padding: 50px; font-family: sans-serif;'><h1>404</h1><p>User with ID **" . htmlspecialchars($id) . "** not found.</p><a href='users.php' style='text-decoration:none; color: #3b82f6; font-weight: 600;'>← Back to Users List</a></div></body></html>";
    exit;
}

// Convert role to lowercase for potential CSS styling
$role_class = strtolower($user['Role']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View User Details - ID <?= htmlspecialchars($user['UserID']) ?></title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
    /* Re-defining core variables for consistent styling */
    :root {
        --primary: #3b82f6;
        --primary-dark: #2563eb;
        --text: #1e293b;
        --card-bg: #ffffff;
        --bg: #f1f5f9;
        --border: #e2e8f0;
        --shadow: rgba(0, 0, 0, 0.1);
        --input-bg: #f8fafc;
    }

    body.dark {
        --text: #f1f5f9;
        --card-bg: #1e293b;
        --bg: #0f172a;
        --border: #334155;
        --shadow: rgba(0, 0, 0, 0.3);
        --input-bg: #0f172a;
    }

    /* --- Layout & Card Styling (Consistent) --- */
    body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        padding: 24px;
        transition: all 0.3s ease;
    }

    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 48px);
    }

    .user-card {
        background: var(--card-bg);
        color: var(--text);
        padding: 32px;
        max-width: 450px;
        width: 100%;
        border-radius: 16px;
        box-shadow: 0 8px 20px var(--shadow);
        border: 1px solid var(--border);
        text-align: center;
        animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    h2 {
        font-size: 28px;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 8px;
    }

    .id-badge {
        display: inline-block;
        background: var(--bg);
        padding: 4px 12px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 24px;
    }
    
    /* --- Info Grid --- */
    .info-grid {
        text-align: left;
        padding-top: 20px;
        border-top: 1px solid var(--border);
        display: grid;
        grid-template-columns: 1fr 2fr; /* Label (1 part) | Value (2 parts) */
        gap: 14px 10px;
        font-size: 16px;
    }

    .info-grid strong {
        color: #64748b; /* Lighter color for label */
        font-weight: 500;
        align-self: center;
    }

    .info-grid span {
        font-weight: 600;
        color: var(--text);
        word-break: break-word; /* Handle long emails/codes */
    }
    
    .role-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 700;
        display: inline-block;
        text-transform: uppercase;
        margin-left: 5px;
        line-height: 1.5;
    }

    /* Role Colors */
    .role-admin { background: #fef3c7; color: #92400e; }
    .role-instructor { background: #d1fae5; color: #065f46; }
    .role-staff { background: #e0f2fe; color: #0c4a6e; }

    /* --- Buttons (Consistent) --- */
    .actions-group {
        margin-top: 30px;
        display: flex;
        justify-content: center;
        gap: 12px;
    }

    .btn {
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
    }

    .btn-secondary {
        background: var(--input-bg);
        color: var(--text);
        border: 2px solid var(--border);
    }

    .btn-secondary:hover {
        background: var(--border);
    }

    /* Mobile Adjustments */
    @media (max-width: 600px) {
        .user-card {
            padding: 20px;
        }
        .actions-group {
            flex-direction: column;
        }
        .btn {
            width: 100%;
        }
    }
</style>
</head>
<body>

<div class="container">
    <div class="user-card">
        <h2>User Details</h2>
        
        <span class="id-badge">User ID: <?= htmlspecialchars($user['UserID']) ?></span>

        <div class="info-grid">
            
            <strong>Full Name:</strong>
            <span><?= htmlspecialchars($user['Fname']) . ' ' . htmlspecialchars($user['Lname']) ?></span>
            
            <strong>Role:</strong>
            <span>
                <?= htmlspecialchars($user['Role']) ?>
                </span>
            </span>

            <strong>Department:</strong>
            <span><?= htmlspecialchars($user['Department']) ?></span>
            
            <strong>Email:</strong>
            <span><?= htmlspecialchars($user['Email']) ?></span>

            <strong>Date Added:</strong>
            <span><?= htmlspecialchars(date('M d, Y', strtotime($user['created_at']))) ?></span>

            <strong>Last Updated:</strong>
            <span><?= htmlspecialchars(date('M d, Y', strtotime($user['updated_at']))) ?></span>
            
        </div>

        <div class="actions-group">
            <button class="btn btn-primary" onclick="location.href='edit_user.php?id=<?= $user['UserID'] ?>'">
                Edit User
            </button>
            <button class="btn btn-secondary" onclick="location.href='users.php'">
                ← Back to List
            </button>
        </div>
    </div>
</div>

<script src="../assets/theme.js"></script>
</body>
</html>