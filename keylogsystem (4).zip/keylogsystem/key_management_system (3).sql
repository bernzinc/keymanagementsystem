-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2025 at 03:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `key_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('Admin') DEFAULT 'Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `Lname`, `Fname`, `Email`, `Password`, `Role`, `created_at`, `updated_at`) VALUES
(1, 'Orbillo', 'Bernz', 'bernz@gmail.com', '$2y$10$lqWyM0in6sNzL.cR9ONUceqvqoFSA8A4qdZOsYEJSegc3V.DfSqty', 'Admin', '2025-10-10 04:16:49', '2025-10-10 05:13:47'),
(2, 'Daylo', 'Kyle', 'kyle@gmail.com', '$2y$10$QmyAAU94kwo7YAZqxFLv8eTj18sXfUD3f9rnZOJUoHZqqL976Rf2q', 'Admin', '2025-10-10 04:16:49', '2025-10-10 05:17:50'),
(3, 'Empillo', 'Jay', 'jay@gmail.com', '$2y$10$tOA.3l1PLDCXPScN32SH1.9vn527egEia1Vy2l6eYON/EZs3UZyAG', 'Admin', '2025-10-10 04:16:49', '2025-10-12 11:49:11');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DeptID` int(11) NOT NULL,
  `DeptName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DeptID`, `DeptName`) VALUES
(1, 'Phoenix'),
(2, 'Warriors'),
(3, 'Nightingale'),
(4, 'Tycoons');

-- --------------------------------------------------------

--
-- Table structure for table `keys_m`
--

CREATE TABLE `keys_m` (
  `KeyID` int(11) NOT NULL,
  `Room_ID` varchar(50) NOT NULL,
  `Key_Code` varchar(50) NOT NULL,
  `QRCode` varchar(255) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Status` enum('Available','Borrowed','Lost','Damaged') DEFAULT 'Available',
  `Date_Added` date DEFAULT curdate(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keys_m`
--

INSERT INTO `keys_m` (`KeyID`, `Room_ID`, `Key_Code`, `QRCode`, `Location`, `Status`, `Date_Added`, `created_at`, `updated_at`) VALUES
(1, 'LAB1', 'K-LAB1', 'K-LAB1', 'Laboratory 1', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-28 10:51:31'),
(2, 'LAB2', 'K-LAB2', 'K-LAB2', 'Laboratory 2', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-28 10:51:42'),
(3, 'LAB3', 'K-LAB3', 'K-LAB3', 'Laboratory 3', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-12 07:53:21'),
(4, 'R206', 'K-R206', 'K-R206', 'Room 206', 'Available', '2025-10-10', '2025-10-10 04:36:00', '2025-10-28 10:51:58'),
(6, 'R201', 'K-R201', 'K-R201', 'Room 201', 'Lost', '2025-10-29', '2025-10-29 11:56:59', '2025-10-29 13:58:22');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `LogID` int(11) NOT NULL,
  `KeyID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Location` varchar(150) NOT NULL,
  `Date` date NOT NULL,
  `TimeBorrowed` time DEFAULT NULL,
  `TimeReturned` time DEFAULT NULL,
  `DueDate` datetime DEFAULT NULL,
  `Status` enum('Borrowed','Returned','Overdue','Lost') DEFAULT 'Borrowed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`LogID`, `KeyID`, `UserID`, `Location`, `Date`, `TimeBorrowed`, `TimeReturned`, `DueDate`, `Status`, `created_at`, `updated_at`) VALUES
(46, 2, 10, 'Laboratory 2', '2025-10-28', '20:57:26', '19:52:29', '2025-10-28 22:00:00', 'Returned', '2025-10-28 12:57:26', '2025-10-29 11:52:29'),
(47, 1, 8, 'Laboratory 1', '2025-10-28', '20:59:01', '19:53:25', '2025-10-28 22:00:00', 'Returned', '2025-10-28 12:59:01', '2025-10-29 11:53:25'),
(59, 1, 8, 'Laboratory 1', '2025-10-31', '12:41:23', '12:46:09', '2025-10-31 12:43:00', 'Returned', '2025-10-31 04:41:23', '2025-10-31 04:46:09'),
(60, 1, 10, 'Laboratory 1', '2025-10-31', '12:46:34', '12:47:06', '2025-10-31 22:00:00', 'Returned', '2025-10-31 04:46:34', '2025-10-31 04:47:06'),
(61, 1, 9, 'Laboratory 1', '2025-10-31', '12:47:19', '12:47:36', '2025-10-31 22:00:00', 'Returned', '2025-10-31 04:47:19', '2025-10-31 04:47:36'),
(62, 1, 8, 'Laboratory 1', '2025-10-31', '13:21:06', '13:25:40', '2025-10-31 22:00:00', 'Returned', '2025-10-31 05:21:06', '2025-10-31 05:25:40'),
(63, 2, 8, 'Laboratory 2', '2025-10-31', '13:26:12', '13:26:23', '2025-10-31 22:00:00', 'Returned', '2025-10-31 05:26:12', '2025-10-31 05:26:23'),
(66, 2, 8, 'Laboratory 2', '2025-10-31', '21:02:30', '13:43:38', '2025-10-31 21:04:00', 'Returned', '2025-10-31 13:02:30', '2025-11-02 05:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `lost_keys`
--

CREATE TABLE `lost_keys` (
  `LostID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Fname` varchar(100) DEFAULT NULL,
  `Lname` varchar(100) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `Key_Code` varchar(100) NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Date_Reported` datetime DEFAULT current_timestamp(),
  `Remarks` text DEFAULT NULL,
  `Status` enum('REPORTED','FOUND','REPLACED') DEFAULT 'REPORTED',
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lost_keys`
--

INSERT INTO `lost_keys` (`LostID`, `UserID`, `Fname`, `Lname`, `Email`, `Key_Code`, `Location`, `Date_Reported`, `Remarks`, `Status`, `updated_at`) VALUES
(7, 11, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'K-R201', 'Room 201', '2025-10-29 00:00:00', 'N/A', 'FOUND', '2025-10-31 08:19:56');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `NotifID` int(11) NOT NULL,
  `Fname` varchar(100) DEFAULT NULL,
  `Lname` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Message` text NOT NULL,
  `Status` enum('Unread','Read') DEFAULT 'Unread',
  `Date_Sent` datetime DEFAULT current_timestamp(),
  `Date_Read` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`NotifID`, `Fname`, `Lname`, `Email`, `Message`, `Status`, `Date_Sent`, `Date_Read`) VALUES
(5, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', '2025-10-28 12:04:16', NULL),
(6, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', '2025-10-28 12:05:43', NULL),
(7, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', '2025-10-28 12:07:07', NULL),
(8, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', '2025-10-28 12:07:11', NULL),
(9, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) was overdue as of Oct 28, 2025 12:00 PM. Email sent to borbillo7@gmail.com.', '', '2025-10-28 12:07:27', NULL),
(10, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', '2025-10-28 13:23:52', NULL),
(11, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', '2025-10-28 13:24:14', NULL),
(12, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', '2025-10-28 13:24:23', NULL),
(13, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 01:00 PM.', '', '2025-10-28 13:24:48', NULL),
(14, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', '2025-10-28 14:00:36', NULL),
(15, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', '2025-10-28 14:00:44', NULL),
(16, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', '2025-10-28 14:05:59', NULL),
(17, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', '2025-10-28 14:06:28', NULL),
(18, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 02:00 PM.', '', '2025-10-28 14:19:50', NULL),
(19, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', '2025-10-28 15:11:55', NULL),
(20, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', '2025-10-28 15:13:20', NULL),
(21, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 03:10 PM.', '', '2025-10-28 15:13:26', NULL),
(22, 'Bernz', 'Orbillo', 'borbillo7@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 03:20 PM.', '', '2025-10-28 15:20:51', NULL),
(23, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:22', NULL),
(24, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:27', NULL),
(25, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:33', NULL),
(26, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:38', NULL),
(27, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:43', NULL),
(28, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:47', NULL),
(29, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:52', NULL),
(30, 'Rizalyn', 'Tolentino', 'rizalyntolentino218@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 28, 2025 10:00 PM.', '', '2025-10-28 22:00:58', NULL),
(31, 'Kydro', 'Auxley', 'jonggonzales@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:04:36', NULL),
(32, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:04:39', NULL),
(33, 'Kydro', 'Auxley', 'jonggonzales13@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:19:55', NULL),
(34, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:19:59', NULL),
(35, 'Kydro', 'Auxley', 'jonggonzales13@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:59:20', NULL),
(36, 'Faith', 'Garcia', 'faith081201@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 29, 2025 10:00 PM.', '', '2025-10-29 22:59:24', NULL),
(37, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', '2025-10-31 11:25:58', NULL),
(38, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', '2025-10-31 11:26:34', NULL),
(39, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 11:25 AM.', '', '2025-10-31 11:26:59', NULL),
(40, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 11:35 AM.', '', '2025-10-31 11:37:52', NULL),
(41, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 31, 2025 11:50 AM.', '', '2025-10-31 11:53:32', NULL),
(42, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB3 (Location: Laboratory 3) overdue since Oct 31, 2025 11:50 AM.', '', '2025-10-31 11:54:40', NULL),
(43, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 31, 2025 12:02 PM.', '', '2025-10-31 12:06:22', NULL),
(44, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-R206 (Location: Room 206) overdue since Oct 31, 2025 12:02 PM.', '', '2025-10-31 12:07:13', NULL),
(45, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 12:43 PM.', '', '2025-10-31 12:44:20', NULL),
(46, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', '2025-10-31 21:00:14', NULL),
(47, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', '2025-10-31 21:01:48', NULL),
(48, 'Klyxion', 'Auxley', 'klyxion19@gmail.com', 'Key K-LAB2 (Location: Laboratory 2) overdue since Oct 31, 2025 09:04 PM.', '', '2025-10-31 21:04:18', NULL),
(49, 'Glybae', 'A', 'sephrinarain@gmail.com', 'Key K-LAB1 (Location: Laboratory 1) overdue since Oct 31, 2025 09:00 PM.', '', '2025-10-31 21:04:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `Role` enum('Instructor','Staff') DEFAULT 'Instructor',
  `Email` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `DeptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Lname`, `Fname`, `Department`, `Role`, `Email`, `created_at`, `updated_at`, `DeptID`) VALUES
(8, 'Auxley', 'Klyxion', 'Warriors', 'Instructor', 'klyxion19@gmail.com', '2025-10-28 12:52:20', '2025-10-28 12:54:01', NULL),
(9, 'Auxley', 'Kydro', 'Tycoons', 'Instructor', 'jonggonzales13@gmail.com', '2025-10-28 12:53:08', '2025-10-29 14:09:08', NULL),
(10, 'Garcia', 'Faith', 'Phoenix', 'Instructor', 'faith081201@gmail.com', '2025-10-28 12:55:14', '2025-10-28 12:55:14', NULL),
(11, 'Tolentino', 'Rizalyn', 'Warriors', 'Staff', 'rizalyntolentino218@gmail.com', '2025-10-28 13:07:21', '2025-10-28 13:07:21', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DeptID`);

--
-- Indexes for table `keys_m`
--
ALTER TABLE `keys_m`
  ADD PRIMARY KEY (`KeyID`),
  ADD UNIQUE KEY `QRCode` (`QRCode`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `fk_logs_key` (`KeyID`),
  ADD KEY `fk_logs_user` (`UserID`);

--
-- Indexes for table `lost_keys`
--
ALTER TABLE `lost_keys`
  ADD PRIMARY KEY (`LostID`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`NotifID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `fk_users_department` (`DeptID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `DeptID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `keys_m`
--
ALTER TABLE `keys_m`
  MODIFY `KeyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `lost_keys`
--
ALTER TABLE `lost_keys`
  MODIFY `LostID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `NotifID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `fk_logs_key` FOREIGN KEY (`KeyID`) REFERENCES `keys_m` (`KeyID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_logs_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_department` FOREIGN KEY (`DeptID`) REFERENCES `departments` (`DeptID`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
