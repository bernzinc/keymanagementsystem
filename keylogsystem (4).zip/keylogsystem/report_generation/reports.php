<?php
require_once '../config.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

// Get date range from URL parameters
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

// Fetch logs based on date range
$stmt = $pdo->prepare("
    SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) as FullName,
           u.Email, k.Location, l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
    FROM logs l
    JOIN keys_m k ON l.KeyID = k.KeyID
    JOIN users u ON l.UserID = u.UserID
    WHERE l.Date BETWEEN :from AND :to
    ORDER BY l.Date DESC, l.TimeBorrowed DESC
");
$stmt->execute([':from' => $from, ':to' => $to]);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate statistics
$totalRecords = count($logs);
$borrowedCount = 0;
$returnedCount = 0;
$overdueCount = 0;
$lostCount = 0;

foreach ($logs as $log) {
    $status = strtoupper($log['Status']);
    if ($status === 'BORROWED') $borrowedCount++;
    if ($status === 'RETURNED' || $status === 'SUCCESSFUL') $returnedCount++;
    if ($status === 'OVERDUE') $overdueCount++;
    if ($status === 'LOST') $lostCount++;
}

$currentDate = date('F d, Y');
$currentTime = date('h:i A');
$fromFormatted = date('F d, Y', strtotime($from));
$toFormatted = date('F d, Y', strtotime($to));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Key Management Report - <?= $fromFormatted ?> to <?= $toFormatted ?></title>
<style>
    @media print {
        @page {
            size: A4 landscape;
            margin: 1.5cm;
        }
        
        body {
            margin: 0;
            padding: 0;
        }
        
        .no-print {
            display: none !important;
        }
        
        .page-break {
            page-break-after: always;
        }
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Arial', sans-serif;
        line-height: 1.6;
        color: #000;
        background: #fff;
        padding: 20px;
    }

    .container {
        max-width: 1400px;
        margin: 0 auto;
        background: white;
    }

    /* Header Section */
    .report-header {
        text-align: center;
        padding: 30px 20px;
        border-bottom: 4px solid #3b82f6;
        margin-bottom: 30px;
        position: relative;
    }

    .report-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 8px;
        background: linear-gradient(90deg, #3b82f6, #8b5cf6);
    }

    .logo-section {
        margin-bottom: 20px;
    }

    .logo-section h1 {
        font-size: 32px;
        color: #1e293b;
        margin-bottom: 5px;
        font-weight: 700;
    }

    .logo-section p {
        font-size: 14px;
        color: #64748b;
        font-weight: 500;
    }

    .report-title {
        background: #eff6ff;
        padding: 15px;
        border-left: 6px solid #3b82f6;
        margin: 20px 0;
    }

    .report-title h2 {
        font-size: 24px;
        color: #1e40af;
        margin-bottom: 5px;
    }

    .report-title .subtitle {
        font-size: 12px;
        color: #3b82f6;
    }

    .report-meta {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
        margin-top: 20px;
        font-size: 13px;
    }

    .meta-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #e5e7eb;
    }

    .meta-label {
        font-weight: 600;
        color: #475569;
    }

    .meta-value {
        color: #1e293b;
    }

    /* Statistics Cards */
    .stats-section {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 15px;
        margin-bottom: 30px;
        page-break-inside: avoid;
    }

    .stat-card {
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        padding: 15px;
        text-align: center;
        background: #f9fafb;
    }

    .stat-card.primary {
        border-color: #bfdbfe;
        background: #eff6ff;
    }

    .stat-card.warning {
        border-color: #fde68a;
        background: #fef3c7;
    }

    .stat-card.success {
        border-color: #bbf7d0;
        background: #d1fae5;
    }

    .stat-card.danger {
        border-color: #fecaca;
        background: #fef2f2;
    }

    .stat-label {
        font-size: 11px;
        text-transform: uppercase;
        color: #64748b;
        font-weight: 600;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }

    .stat-value {
        font-size: 32px;
        font-weight: 700;
        color: #1e293b;
    }

    .stat-value.primary { color: #3b82f6; }
    .stat-value.warning { color: #f59e0b; }
    .stat-value.success { color: #10b981; }
    .stat-value.danger { color: #ef4444; }

    /* Table Section */
    .table-section {
        margin-bottom: 30px;
    }

    .section-title {
        font-size: 18px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid #e5e7eb;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        font-size: 11px;
    }

    thead th {
        background: #1e293b;
        color: white;
        padding: 10px 8px;
        text-align: left;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 0.5px;
        border: 1px solid #000;
    }

    tbody td {
        padding: 8px;
        border: 1px solid #cbd5e1;
        vertical-align: top;
    }

    tbody tr:nth-child(even) {
        background: #f9fafb;
    }

    tbody tr:hover {
        background: #f1f5f9;
    }

    .key-code {
        font-family: 'Courier New', monospace;
        background: #dbeafe;
        padding: 3px 6px;
        border-radius: 4px;
        font-weight: 700;
        color: #1e40af;
        display: inline-block;
        font-size: 11px;
    }

    .user-name {
        font-weight: 600;
        color: #1e293b;
    }

    .email {
        color: #64748b;
        font-size: 10px;
    }

    .status-badge {
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        display: inline-block;
    }

    .status-borrowed {
        background: #fef3c7;
        color: #92400e;
    }

    .status-returned,
    .status-successful {
        background: #d1fae5;
        color: #065f46;
    }

    .status-overdue {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-lost {
        background: #fecaca;
        color: #7f1d1d;
    }

    /* Footer Section */
    .report-footer {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 3px solid #e5e7eb;
        text-align: center;
        font-size: 11px;
        color: #64748b;
    }

    .footer-info {
        margin-bottom: 15px;
    }

    .footer-info strong {
        color: #1e293b;
    }

    /* Print Button */
    .print-btn {
        position: fixed;
        top: 20px;
        right: 20px;
        background: #3b82f6;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 1000;
    }

    .print-btn:hover {
        background: #2563eb;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #64748b;
    }

    .empty-icon {
        font-size: 64px;
        margin-bottom: 16px;
    }

    .empty-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #1e293b;
    }

    @media print {
        .print-btn {
            display: none !important;
        }
        
        body {
            padding: 0;
        }
        
        thead {
            display: table-header-group;
        }
        
        tr {
            page-break-inside: avoid;
        }
    }
</style>
</head>
<body>
<button onclick="window.print()" class="print-btn no-print">Print / Save as PDF</button>

<div class="container">
    <!-- Header -->
    <div class="report-header">
        <div class="logo-section">
            <h1>ADFC Security Office</h1>
            <p>Asian Development Foundation College</p>
        </div>
        
        <div class="report-title">
            <h2>KEY MANAGEMENT REPORT</h2>
            <p class="subtitle">Comprehensive Borrowing & Return Activity Log</p>
        </div>
        
        <div class="report-meta">
            <div class="meta-item">
                <span class="meta-label">Report Period:</span>
                <span class="meta-value"><?= $fromFormatted ?> - <?= $toFormatted ?></span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Generated:</span>
                <span class="meta-value"><?= $currentDate ?> at <?= $currentTime ?></span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Total Records:</span>
                <span class="meta-value"><?= $totalRecords ?> Transaction(s)</span>
            </div>
        </div>
    </div>

    <!-- Statistics -->
    <div class="stats-section">
        <div class="stat-card primary">
            <div class="stat-label">Total Records</div>
            <div class="stat-value primary"><?= $totalRecords ?></div>
        </div>
        <div class="stat-card warning">
            <div class="stat-label">Borrowed</div>
            <div class="stat-value warning"><?= $borrowedCount ?></div>
        </div>
        <div class="stat-card success">
            <div class="stat-label">Returned</div>
            <div class="stat-value success"><?= $returnedCount ?></div>
        </div>
        <div class="stat-card danger">
            <div class="stat-label">Overdue</div>
            <div class="stat-value danger"><?= $overdueCount ?></div>
        </div>
        <?php if ($lostCount > 0): ?>
        <div class="stat-card danger">
            <div class="stat-label">Lost</div>
            <div class="stat-value danger"><?= $lostCount ?></div>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($totalRecords > 0): ?>
    <!-- Data Table -->
    <div class="table-section">
        <h3 class="section-title">Detailed Transaction Records</h3>
        <table>
            <thead>
                <tr>
                    <th style="width: 5%;">No.</th>
                    <th style="width: 12%;">Key Code</th>
                    <th style="width: 15%;">Location</th>
                    <th style="width: 18%;">Borrower</th>
                    <th style="width: 12%;">Date</th>
                    <th style="width: 12%;">Time Borrowed</th>
                    <th style="width: 12%;">Time Returned</th>
                    <th style="width: 14%;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $counter = 1;
                foreach ($logs as $log): 
                    $status = strtoupper($log['Status']);
                    $statusClass = '';
                    
                    switch ($status) {
                        case 'BORROWED':
                            $statusClass = 'status-borrowed';
                            break;
                        case 'RETURNED':
                        case 'SUCCESSFUL':
                            $statusClass = 'status-returned';
                            break;
                        case 'OVERDUE':
                            $statusClass = 'status-overdue';
                            break;
                        case 'LOST':
                            $statusClass = 'status-lost';
                            break;
                    }
                ?>
                <tr>
                    <td style="text-align: center; font-weight: 600;"><?= $counter++ ?></td>
                    <td><span class="key-code"><?= htmlspecialchars($log['Key_Code']) ?></span></td>
                    <td><?= htmlspecialchars($log['Location']) ?></td>
                    <td>
                        <div class="user-name"><?= htmlspecialchars($log['FullName']) ?></div>
                        <div class="email"><?= htmlspecialchars($log['Email']) ?></div>
                    </td>
                    <td><?= date('M d, Y', strtotime($log['Date'])) ?></td>
                    <td><?= htmlspecialchars($log['TimeBorrowed']) ?></td>
                    <td><?= htmlspecialchars($log['TimeReturned'] ?? '—') ?></td>
                    <td><span class="status-badge <?= $statusClass ?>"><?= htmlspecialchars($log['Status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php else: ?>
    <div class="empty-state">
        <div class="empty-icon"></div>
        <div class="empty-title">No Records Found</div>
        <p>No transactions found for the selected date range (<?= $fromFormatted ?> - <?= $toFormatted ?>).</p>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <div class="report-footer">
        <div class="footer-info">
            <strong>ADFC Security Office</strong><br>
            Asian Development Foundation College<br>
            Contact: adfcsecofficer@gmail.com | Emergency Hotline: 001-002<br>
            <em>This is a system-generated report. No signature required.</em>
        </div>
        <p style="margin-top: 15px; font-size: 10px; color: #94a3b8;">
            Report generated on <?= $currentDate ?> at <?= $currentTime ?> | 
            Period: <?= $fromFormatted ?> to <?= $toFormatted ?> | 
            Confidential - For Internal Use Only
        </p>
    </div>
</div>

<script>
// Auto-print dialog on page load (optional)
window.addEventListener('load', () => {
    // Uncomment to auto-trigger print dialog
    // setTimeout(() => window.print(), 500);
});
</script>
</body>
</html>