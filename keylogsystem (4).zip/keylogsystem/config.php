<?php
// config.php
// Edit DB credentials below
session_start();

$DB_HOST = '127.0.0.1';
$DB_NAME = 'key_management_system';   // change if needed
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// helper to check admin login
function isAdmin() {
    return !empty($_SESSION['admin_id']);
}
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: login.php');
        exit;
    }
}
