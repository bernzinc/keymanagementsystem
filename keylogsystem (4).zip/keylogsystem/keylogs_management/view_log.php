<?php
require_once '../includes/functions.php';
requireAdmin();
// Assuming $pdo is available after requiring functions.php

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: logs.php');
    exit;
}

// Fetch log details
$stmt = $pdo->prepare("SELECT 
                        l.*, 
                        k.Key_Code, 
                        CONCAT(u.Fname, ' ', u.Lname) AS FullName,
                        u.Email
                      FROM logs l
                      LEFT JOIN keys_m k ON l.KeyID = k.KeyID
                      LEFT JOIN users u ON l.UserID = u.UserID
                      WHERE l.LogID = :id");
$stmt->execute([':id' => $id]);
$log = $stmt->fetch();

if (!$log) {
    // Consistent error page for log not found
    echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Log Not Found</title><link rel='stylesheet' href='../assets/theme.css'></head><body><div style='text-align:center; padding: 50px; font-family: sans-serif;'><h1>404</h1><p>Log with ID **" . htmlspecialchars($id) . "** not found.</p><a href='logs.php' style='text-decoration:none; color: #3b82f6; font-weight: 600;'>← Back to Logs List</a></div></body></html>";
    exit;
}

$statusClass = strtolower($log['Status']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Log Details - ID <?= htmlspecialchars($log['LogID']) ?></title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
    /* Re-defining core variables for consistent styling */
    :root {
        --primary: #3b82f6;
        --primary-dark: #2563eb;
        --success: #10b981; /* Returned */
        --info: #3b82f6; /* Borrowed */
        --warning: #f59e0b; /* Overdue */
        --danger: #ef4444; /* Lost */
        --text: #1e293b;
        --card-bg: #ffffff;
        --bg: #f1f5f9;
        --border: #e2e8f0;
        --shadow: rgba(0, 0, 0, 0.1);
        --input-bg: #f8fafc;
    }

    body.dark {
        --text: #f1f5f9;
        --card-bg: #1e293b;
        --bg: #0f172a;
        --border: #334155;
        --shadow: rgba(0, 0, 0, 0.3);
        --input-bg: #0f172a;
    }

    /* --- Base Layout --- */
    body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        padding: 24px;
        transition: all 0.3s ease;
    }
    
    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: calc(100vh - 48px);
    }

    .log-card {
        background: var(--card-bg);
        color: var(--text);
        padding: 32px;
        max-width: 550px;
        width: 100%;
        border-radius: 16px;
        box-shadow: 0 8px 20px var(--shadow);
        border: 1px solid var(--border);
        text-align: center;
        animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    h2 {
        font-size: 24px;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }

    .id-tag {
        font-size: 14px;
        font-weight: 600;
        background: var(--bg);
        padding: 4px 10px;
        border-radius: 8px;
        color: var(--text);
    }

    /* --- QR Code & Key --- */
    .qr-section {
        border-bottom: 1px dashed var(--border);
        padding-bottom: 20px;
        margin-bottom: 20px;
    }
    
    .qr {
        display: block;
        margin: 0 auto 15px;
        width: 120px;
        height: 120px;
        border: 4px solid var(--border);
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .key-code {
        font-family: 'Courier New', monospace;
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        background: var(--input-bg);
        padding: 6px 12px;
        border-radius: 8px;
        display: inline-block;
    }
    
    /* --- Info Grid --- */
    .info-grid {
        text-align: left;
        display: grid;
        grid-template-columns: 1fr 2fr; /* Label (1 part) | Value (2 parts) */
        gap: 14px 10px;
        font-size: 15px;
        padding: 10px 0;
    }

    .info-grid strong {
        color: #64748b; /* Lighter color for label */
        font-weight: 500;
        align-self: center;
    }

    .info-grid span {
        font-weight: 600;
        color: var(--text);
        word-break: break-word;
    }
    
    /* --- Status Badge --- */
    .status-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 700;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .status-returned { 
        background: #d1fae5; 
        color: var(--success); 
    }
    .status-borrowed { 
        background: #dbeafe; 
        color: var(--info); 
        animation: pulse-blue 1.5s infinite;
    }
    .status-overdue { 
        background: #fef3c7; 
        color: var(--warning); 
        animation: pulse-yellow 1.5s infinite;
    }
    .status-lost { 
        background: #fee2e2; 
        color: var(--danger); 
    }

    @keyframes pulse-blue {
        0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.4); }
        70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
        100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
    }
    
    .pending {
        color: #94a3b8;
        font-style: italic;
    }

    /* --- Buttons (Consistent) --- */
    .actions-group {
        margin-top: 30px;
        display: flex;
        justify-content: center;
        gap: 12px;
    }

    .btn-secondary {
        padding: 12px 24px;
        border: 2px solid var(--border);
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        background: var(--input-bg);
        color: var(--text);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-secondary:hover {
        background: var(--border);
    }
    
    /* Mobile Adjustments */
    @media (max-width: 600px) {
        .log-card {
            padding: 20px;
        }
        .info-grid {
            grid-template-columns: 1fr;
            text-align: center;
        }
        .info-grid strong {
            text-align: center;
            border-bottom: 1px dotted var(--border);
            padding-bottom: 5px;
        }
        .actions-group {
            flex-direction: column;
        }
        .btn-secondary {
            width: 100%;
            justify-content: center;
        }
    }
</style>
</head>
<body>

<div class="container">
    <div class="log-card">
        <h2>
            <span class="id-tag">Log ID: <?= htmlspecialchars($log['LogID']) ?></span>
            Key Log Details
        </h2>

        <div class="qr-section">
            <img 
                src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($log['Key_Code']) ?>&size=120x120" 
                class="qr" 
                alt="QR Code for <?= htmlspecialchars($log['Key_Code']) ?>"
            >
            <span class="key-code"><?= htmlspecialchars($log['Key_Code']) ?></span>
        </div>

        <div class="info-grid">
            
            <strong>Status:</strong>
            <span>
                
                    <?= htmlspecialchars($log['Status']) ?>
                </span>
            </span>

            <strong>Borrower:</strong>
            <span><?= htmlspecialchars($log['FullName']) ?></span>

            <strong>Borrower Email:</strong>
            <span><?= htmlspecialchars($log['Email'] ?? 'N/A') ?></span>
            
            <strong>Location:</strong>
            <span><?= htmlspecialchars($log['Location']) ?></span>
            
            <strong>Date:</strong>
            <span><?= htmlspecialchars(date('M d, Y', strtotime($log['Date']))) ?></span>

            <strong>Time Borrowed:</strong>
            <span><?= htmlspecialchars(date('h:i A', strtotime($log['TimeBorrowed']))) ?></span>
            
            <strong>Time Returned:</strong>
            <span>
                <?php if ($log['TimeReturned']): ?>
                    <?= htmlspecialchars(date('h:i A', strtotime($log['TimeReturned']))) ?>
                <?php else: ?>
                    <span class="pending">Not yet returned</span>
                <?php endif; ?>
            </span>
            
        </div>

        <div class="actions-group">
            <a href="logs.php" class="btn-secondary">
                ← Back to Logs List
            </a>
            </div>
    </div>
</div>

<script src="../assets/theme.js"></script> 
</body>
</html>