<?php
require_once __DIR__ . '/includes/functions.php';
if (isAdmin()) {
    header('Location: dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE Email = :e LIMIT 1");
    $stmt->execute([':e' => $email]);
    $admin = $stmt->fetch();

    if ($admin) {
        $valid = false;
        if (password_verify($password, $admin['Password'])) {
            $valid = true;
        } elseif ($admin['Password'] === $password) {
            $valid = true;
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE admins SET Password = :p WHERE AdminID = :id")
                ->execute([':p' => $hash, ':id' => $admin['AdminID']]);
        }

        if ($valid) {
            $_SESSION['admin_id'] = $admin['AdminID'];
            $_SESSION['admin_name'] = $admin['Fname'] . ' ' . $admin['Lname'];
            header('Location: dashboard.php');
            exit;
        }
    }
    $error = "Invalid username or password.";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADFC - Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: url('images/bg.jpg');
            background-size: cover;
            background-position: center;
            opacity: 0.15;
            z-index: 0;
        }

        .animated-bg {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }

        .shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.5;
            animation: float 20s infinite ease-in-out;
        }

        .shape-1 {
            width: 500px;
            height: 500px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            top: -250px;
            left: -250px;
            animation-delay: 0s;
        }

        .shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            bottom: -200px;
            right: -200px;
            animation-delay: 5s;
        }

        .shape-3 {
            width: 300px;
            height: 300px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            top: 50%;
            left: 50%;
            animation-delay: 10s;
        }

        @keyframes float {

            0%,
            100% {
                transform: translate(0, 0) scale(1);
            }

            33% {
                transform: translate(50px, -50px) scale(1.1);
            }

            66% {
                transform: translate(-50px, 50px) scale(0.9);
            }
        }

        .login-wrapper {
            display: flex;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 30px;
            box-shadow: 0 30px 90px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            max-width: 1000px;
            width: 100%;
            min-height: 600px;
            position: relative;
            z-index: 1;
            animation: slideUp 0.8s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .left-section {
            flex: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .left-section::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            top: -150px;
            right: -150px;
            animation: pulse 8s ease-in-out infinite;
        }

        .left-section::after {
            content: '';
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            bottom: -100px;
            left: -100px;
            animation: pulse 8s ease-in-out infinite 4s;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
                opacity: 0.1;
            }

            50% {
                transform: scale(1.3);
                opacity: 0.2;
            }
        }

        .logo-container {
            position: relative;
            z-index: 1;
            margin-bottom: 30px;
            animation: fadeInScale 1s ease-out 0.2s both;
        }

        @keyframes fadeInScale {
            from {
                opacity: 0;
                transform: scale(0.8);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .logo {
            width: 160px;
            height: 160px;
            background: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            transition: transform 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.05) rotate(5deg);
        }

        .logo::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transform: translateX(-100%);
            animation: shine 3s infinite;
        }

        @keyframes shine {
            to {
                transform: translateX(100%);
            }
        }

        .logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .school-info {
            position: relative;
            z-index: 1;
            text-align: center;
            animation: fadeInUp 1s ease-out 0.4s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .school-info h1 {
            font-size: 26px;
            margin-bottom: 12px;
            font-weight: 700;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            line-height: 1.3;
        }

        .school-info p {
            font-size: 14px;
            opacity: 0.95;
            line-height: 1.8;
        }

        .motto {
            margin-top: 25px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
            font-style: italic;
            font-size: 14px;
            line-height: 1.6;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .right-section {
            flex: 1;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: white;
            animation: fadeIn 1s ease-out 0.3s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .welcome-text {
            margin-bottom: 40px;
            animation: fadeInUp 1s ease-out 0.5s both;
        }

        .welcome-text h2 {
            font-size: 36px;
            color: #1e293b;
            margin-bottom: 8px;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .welcome-text p {
            color: #64748b;
            font-size: 15px;
        }

        .error {
            background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
            color: #dc2626;
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 14px;
            border-left: 4px solid #dc2626;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            25% {
                transform: translateX(-10px);
            }

            75% {
                transform: translateX(10px);
            }
        }

        .error svg {
            flex-shrink: 0;
            animation: spin 0.5s ease-in-out;
        }

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .form-group {
            margin-bottom: 24px;
            animation: fadeInUp 1s ease-out calc(0.6s + var(--delay)) both;
        }

        .form-group:nth-child(1) {
            --delay: 0s;
        }

        .form-group:nth-child(2) {
            --delay: 0.1s;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.3s ease;
        }

        .form-group input {
            width: 100%;
            padding: 16px 18px 16px 52px;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .form-group input:focus+.input-icon {
            color: #667eea;
        }

        .input-wrapper:focus-within .input-icon {
            color: #667eea;
            animation: bounce 0.5s ease;
        }

        @keyframes bounce {

            0%,
            100% {
                transform: translateY(-50%);
            }

            50% {
                transform: translateY(-60%);
            }
        }

        .form-group input::placeholder {
            color: #94a3b8;
        }

        .login-button {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 1s ease-out 0.8s both;
        }

        .login-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }

        .login-button:hover::before {
            left: 100%;
        }

        .login-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.5);
        }

        .login-button:active {
            transform: translateY(-1px);
        }

        .signup-link {
            text-align: center;
            margin-top: 28px;
            color: #64748b;
            font-size: 14px;
            animation: fadeInUp 1s ease-out 0.9s both;
        }

        .signup-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
        }

        .signup-link a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: width 0.3s ease;
        }

        .signup-link a:hover::after {
            width: 100%;
        }

        .signup-link a:hover {
            color: #764ba2;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 30px;
            animation: fadeInUp 1s ease-out 1s both;
        }

        .social-icon {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            color: #64748b;
            text-decoration: none;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .social-icon::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            transform: scale(0);
            transition: transform 0.4s ease;
        }

        .social-icon:hover::before {
            transform: scale(1);
        }

        .social-icon svg {
            width: 20px;
            height: 20px;
            position: relative;
            z-index: 1;
            transition: all 0.4s ease;
        }

        .social-icon:hover {
            transform: translateY(-5px) rotate(360deg);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .social-icon:hover svg {
            color: white;
        }

        @media screen and (max-width: 768px) {
            .login-wrapper {
                flex-direction: column;
                max-width: 100%;
                border-radius: 20px;
            }

            .left-section {
                padding: 40px 30px;
                min-height: 300px;
            }

            .logo {
                width: 120px;
                height: 120px;
            }

            .school-info h1 {
                font-size: 22px;
            }

            .right-section {
                padding: 40px 30px;
            }

            .welcome-text h2 {
                font-size: 28px;
            }
        }

        @media screen and (max-width: 420px) {
            body {
                padding: 12px;
            }

            .login-wrapper {
                border-radius: 15px;
                min-height: auto;
            }

            .left-section {
                padding: 30px 20px;
                min-height: 250px;
            }

            .logo {
                width: 100px;
                height: 100px;
            }

            .school-info h1 {
                font-size: 20px;
            }

            .school-info p {
                font-size: 13px;
            }

            .motto {
                font-size: 13px;
                padding: 12px;
            }

            .right-section {
                padding: 30px 20px;
            }

            .welcome-text h2 {
                font-size: 26px;
            }

            .form-group input {
                padding: 14px 14px 14px 48px;
                font-size: 14px;
            }

            .login-button {
                padding: 14px;
                font-size: 15px;
            }
        }
    </style>
</head>

<body>
    <div class="animated-bg">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
    </div>

    <div class="login-wrapper">
        <div class="left-section">
            <div class="logo-container">
                <div class="logo">
                    <img src="images/logoo.png" srcset="images/logoo.png 2x" alt="ADFC Logo">
                </div>
            </div>
            <div class="school-info">
                <h1>Asian Development<br>Foundation College</h1>
                <p>1984 • Tacloban City</p>
                <div class="motto">
                    "Today, I am proud of ADFC.<br>Tomorrow, ADFC will be proud of me."
                </div>
            </div>
        </div>

        <div class="right-section">
            <div class="welcome-text">
                <h2>Welcome Back</h2>
                <p>Enter your credentials to access your account</p>
            </div>

            <?php if ($error): ?>
                <div class="error">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                    </svg>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="text" name="username" placeholder="example@gmail.com" required>
                        <span class="input-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                                </path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="password" name="password" placeholder="••••••••••••••" required>
                        <span class="input-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                        </span>
                    </div>
                </div>
                <button type="submit" class="login-button">Log In</button>
            </form>

            <div class="social-links">
                <a href="https://www.facebook.com/photo/?fbid=614928597307902&set=a.614928590641236" class="social-icon"
                    title="Facebook">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                </a>
            </div>
        </div>
    </div>
</body>

</html>