<?php
require_once '../config.php'; // DB + requireAdmin
requireAdmin();

date_default_timezone_set('Asia/Manila');

// SMTP Configuration - Update these with your actual SMTP settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'adfcsecofficer@gmail.com');
define('SMTP_PASSWORD', 'bibd yyzs eenq trry'); // Use app-specific password for Gmail
define('SMTP_FROM_EMAIL', 'adfcsecofficer@gmail.com');
define('SMTP_FROM_NAME', 'ADFC Key Management System');

/**
 * Send email via SMTP using PHPMailer
 */
function sendOverdueEmail($toEmail, $toName, $keyCode, $location, $dueDate, $daysOverdue) {
    // Check if vendor/autoload.php exists
    if (!file_exists('../vendor/autoload.php')) {
        error_log("PHPMailer not installed. Run: composer require phpmailer/phpmailer");
        return false;
    }
    
    require_once '../vendor/autoload.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        // Enable verbose debug output (comment out in production)
        // $mail->SMTPDebug = PHPMailer\PHPMailer\SMTP::DEBUG_SERVER;
        
        // Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = SMTP_PORT;
        
        // Disable SSL certificate verification (for testing only - remove in production)
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        
        // Content
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = "⚠️ OVERDUE: Key Return Reminder - $keyCode";
        
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #ef4444, #f59e0b); color: white; padding: 30px; border-radius: 10px 10px 0 0; text-align: center; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .alert-box { background: #fee2e2; border-left: 4px solid #ef4444; padding: 15px; margin: 20px 0; border-radius: 5px; }
                .key-info { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .key-info table { width: 100%; }
                .key-info td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
                .key-info td:first-child { font-weight: bold; color: #64748b; width: 40%; }
                .key-code { font-family: monospace; background: #f1f5f9; padding: 5px 10px; border-radius: 5px; color: #ef4444; font-weight: bold; font-size: 16px; }
                .footer { text-align: center; color: #64748b; font-size: 12px; margin-top: 30px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 28px;'> KEY OVERDUE NOTICE</h1>
                </div>
                <div class='content'>
                    <p>Dear <strong>$toName</strong>,</p>
                    
                    <div class='alert-box'>
                        <strong> URGENT:</strong> You have an overdue key that must be returned immediately.
                    </div>
                    
                    <div class='key-info'>
                        <table>
                            <tr>
                                <td>Key Code:</td>
                                <td><span class='key-code'>$keyCode</span></td>
                            </tr>
                            <tr>
                                <td>Location:</td>
                                <td><strong>$location</strong></td>
                            </tr>
                            <tr>
                                <td>Due Date:</td>
                                <td>" . date('F d, Y h:i A', strtotime($dueDate)) . "</td>
                            </tr>
                            <tr>
                                <td>Days Overdue:</td>
                                <td><strong style='color: #ef4444;'>$daysOverdue day(s)</strong></td>
                            </tr>
                        </table>
                    </div>
                    
                    <p><strong>Action Required:</strong></p>
                    <ul>
                        <li>Please return the key to the designated location immediately</li>
                        <li>Contact the admin if you're unable to return it</li>
                        <li>Late returns may result in penalties or restrictions</li>
                    </ul>
                    
                    <p style='margin-top: 30px;'>If you have already returned this key, please disregard this notice.</p>
                    
                    <div class='footer'>
                        <p>This is an automated notification from the ADFC Key Management System</p>
                        <p>Please do not reply to this email</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = "Dear $toName,\n\nYou have an OVERDUE key that needs to be returned:\n\nKey Code: $keyCode\nLocation: $location\nDue Date: " . date('F d, Y h:i A', strtotime($dueDate)) . "\nDays Overdue: $daysOverdue day(s)\n\nPlease return the key immediately.\n\nThank you,\nADFC Key Management System";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

/**
 * Log notification to database
 */
function logNotification($pdo, $userID, $keyID, $message, $status) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (UserID, KeyID, Message, Status, Date_Sent)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$userID, $keyID, $message, $status]);
    } catch (PDOException $e) {
        error_log("Failed to log notification: " . $e->getMessage());
    }
}

// Initialize counters
$newlyMarked = 0;
$emailsSent = 0;
$emailsFailed = 0;

try {
    // --- STEP 1: Mark overdue keys ---
    $stmt = $pdo->prepare("
        UPDATE logs 
        SET Status = 'OVERDUE', updated_at = NOW() 
        WHERE Status = 'BORROWED' AND DueDate < NOW()
    ");
    $stmt->execute();
    $newlyMarked = $stmt->rowCount();

    // --- STEP 2: Fetch overdue logs ---
    $stmt = $pdo->query("
        SELECT l.*, u.Fname, u.Lname, u.Email, k.Key_Code, k.Location
        FROM logs l
        LEFT JOIN users u ON l.UserID = u.UserID
        LEFT JOIN keys_m k ON l.KeyID = k.KeyID
        WHERE l.Status = 'OVERDUE'
        ORDER BY l.DueDate ASC
    ");
    $overdues = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- STEP 3: Send notifications (only if not sent in last 24 hours) ---
    foreach ($overdues as $o) {
        // Skip if user has no email
        if (empty($o['Email'])) {
            continue;
        }
        
        // Check if notification was already sent in the last 24 hours
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count
            FROM notifications
            WHERE UserID = ? AND KeyID = ? 
            AND Message LIKE '%Overdue:%'
            AND Date_Sent > DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->execute([$o['UserID'], $o['KeyID']]);
        $recentNotif = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($recentNotif['count'] == 0) {
            // Calculate days overdue
            $dueDate = new DateTime($o['DueDate']);
            $now = new DateTime();
            $daysOverdue = $now->diff($dueDate)->days;
            
            // Send email
            $success = sendOverdueEmail(
                $o['Email'],
                trim("{$o['Fname']} {$o['Lname']}"),
                $o['Key_Code'],
                $o['Location'],
                $o['DueDate'],
                $daysOverdue
            );
            
            if ($success) {
                $emailsSent++;
                logNotification(
                    $pdo,
                    $o['UserID'],
                    $o['KeyID'],
                    "Overdue: {$o['Key_Code']} - {$daysOverdue} day(s) overdue",
                    'sent'
                );
            } else {
                $emailsFailed++;
                logNotification(
                    $pdo,
                    $o['UserID'],
                    $o['KeyID'],
                    "Overdue: {$o['Key_Code']} - Failed to send",
                    'failed'
                );
            }
            
            // Add small delay to avoid rate limiting
            usleep(500000); // 0.5 seconds
        }
    }

    // --- Get recent notifications stats ---
    $stmt = $pdo->query("
        SELECT COUNT(*) as count, MAX(Date_Sent) as last_sent
        FROM notifications
        WHERE Message LIKE '%Overdue:%'
        AND Date_Sent > DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ");
    $notifStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $overdues = [];
    $notifStats = ['count' => 0, 'last_sent' => null];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Overdue Logs - ADFC</title>
<style>
    :root {
        --primary: #3b82f6;
        --primary-dark: #2563eb;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --bg: #f1f5f9;
        --text: #1e293b;
        --card-bg: #ffffff;
        --border: #e2e8f0;
        --shadow: rgba(0, 0, 0, 0.1);
        --input-bg: #f8fafc;
    }

    body.dark {
        --bg: #0f172a;
        --text: #f1f5f9;
        --card-bg: #1e293b;
        --border: #334155;
        --shadow: rgba(0, 0, 0, 0.3);
        --input-bg: #0f172a;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        padding: 24px;
        transition: all 0.3s ease;
    }

    .container {
        max-width: 1400px;
        margin: 0 auto;
        animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .header {
        background: var(--card-bg);
        padding: 24px 32px;
        border-radius: 16px;
        margin-bottom: 24px;
        box-shadow: 0 1px 3px var(--shadow);
        border: 1px solid var(--border);
    }

    .header-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    h1 {
        font-size: 28px;
        font-weight: 700;
        background: linear-gradient(135deg, var(--danger), var(--warning));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .alert {
        padding: 14px 18px;
        border-radius: 12px;
        margin-bottom: 20px;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }

    .alert-info {
        background: #dbeafe;
        color: #1e40af;
        border-left: 4px solid var(--primary);
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border-left: 4px solid var(--success);
    }

    .alert-warning {
        background: #fef3c7;
        color: #92400e;
        border-left: 4px solid var(--warning);
    }

    .alert-danger {
        background: #fee2e2;
        color: #991b1b;
        border-left: 4px solid var(--danger);
    }

    .stats-bar {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    .stat-card {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 12px;
        border: 1px solid var(--border);
        box-shadow: 0 1px 3px var(--shadow);
    }

    .stat-label {
        font-size: 12px;
        color: #64748b;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
    }

    .stat-value {
        font-size: 32px;
        font-weight: 700;
        color: var(--danger);
    }

    .stat-value.success {
        color: var(--success);
    }

    .stat-value.warning {
        color: var(--warning);
    }

    .table-card {
        background: var(--card-bg);
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 1px 3px var(--shadow);
        border: 1px solid var(--border);
    }

    .table-wrapper {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    thead th {
        background: var(--bg);
        padding: 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #64748b;
        border-bottom: 2px solid var(--border);
        white-space: nowrap;
    }

    tbody td {
        padding: 16px;
        border-bottom: 1px solid var(--border);
        font-size: 14px;
    }

    tbody tr {
        transition: background 0.2s;
    }

    tbody tr:hover {
        background: var(--bg);
    }

    .key-code {
        font-family: 'Courier New', monospace;
        background: var(--bg);
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 600;
        color: var(--danger);
    }

    .status-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        background: #fee2e2;
        color: #991b1b;
    }

    .email {
        color: #64748b;
        font-size: 13px;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #64748b;
    }

    .empty-icon {
        font-size: 64px;
        margin-bottom: 16px;
    }

    .empty-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--text);
    }

    .empty-text {
        font-size: 14px;
    }

    .time-info {
        font-size: 12px;
        color: #64748b;
        margin-top: 8px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        background: var(--primary);
        color: white;
        text-decoration: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        border: none;
        cursor: pointer;
        transition: background 0.2s;
    }

    .btn:hover {
        background: var(--primary-dark);
    }

    .btn-danger {
        background: var(--danger);
    }

    .btn-danger:hover {
        background: #dc2626;
    }

    /* Mobile Responsive */
    @media (max-width: 768px) {
        body {
            padding: 16px;
        }

        .header {
            padding: 20px;
        }

        .header-top {
            flex-direction: column;
            align-items: stretch;
            gap: 16px;
        }

        h1 {
            font-size: 22px;
            justify-content: center;
        }

        .stats-bar {
            grid-template-columns: 1fr;
        }

        .table-wrapper {
            margin: 0 -20px;
            padding: 0 20px;
        }

        table {
            min-width: 800px;
        }

        thead th,
        tbody td {
            padding: 12px 8px;
            font-size: 13px;
        }
    }
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="header-top">
            <h1>Overdue Logs Management</h1>
        
        </div>

        <?php if ($newlyMarked > 0): ?>
            <div class="alert alert-warning">
                <span></span>
                <?= $newlyMarked ?> key(s) just marked as OVERDUE.
            </div>
        <?php endif; ?>

        <?php if ($emailsSent > 0): ?>
            <div class="alert alert-success">
                <span></span>
                Successfully sent <?= $emailsSent ?> overdue notification email(s).
            </div>
        <?php endif; ?>

        <?php if ($emailsFailed > 0): ?>
            <div class="alert alert-danger">
                <span>❌</span>
                Failed to send <?= $emailsFailed ?> email(s). Check SMTP configuration and logs.
            </div>
        <?php endif; ?>

        <?php if ($notifStats['count'] > 0): ?>
            <div class="time-info">
                <strong>Recent Activity:</strong> <?= $notifStats['count'] ?> notification(s) sent in the last 24 hours.
                <?php if ($notifStats['last_sent']): ?>
                    Last sent: <?= date('M d, Y h:i A', strtotime($notifStats['last_sent'])) ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if (count($overdues) > 0): ?>
        <div class="stats-bar">
            <div class="stat-card">
                <div class="stat-label">Total Overdue Keys</div>
                <div class="stat-value"><?= count($overdues) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Unique Users</div>
                <div class="stat-value"><?= count(array_unique(array_column($overdues, 'Email'))) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Emails Sent Today</div>
                <div class="stat-value success"><?= $emailsSent ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Failed Emails</div>
                <div class="stat-value warning"><?= $emailsFailed ?></div>
            </div>
        </div>

        <div class="table-card">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Key Code</th>
                            <th>Location</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Due Date</th>
                            <th>Days Overdue</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($overdues as $o): 
                            $dueDate = new DateTime($o['DueDate']);
                            $now = new DateTime();
                            $daysOverdue = $now->diff($dueDate)->days;
                        ?>
                        <tr>
                            <td><span class="key-code"><?= htmlspecialchars($o['Key_Code']) ?></span></td>
                            <td><?= htmlspecialchars($o['Location']) ?></td>
                            <td><strong><?= htmlspecialchars(trim("{$o['Fname']} {$o['Lname']}")) ?></strong></td>
                            <td class="email"><?= htmlspecialchars($o['Email'] ?: 'No email') ?></td>
                            <td><?= date('M d, Y h:i A', strtotime($o['DueDate'])) ?></td>
                            <td><strong style="color: var(--danger);"><?= $daysOverdue ?> day(s)</strong></td>
                            <td><span class="status-badge"><?= htmlspecialchars($o['Status']) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="table-card">
            <div class="empty-state">
                <div class="empty-icon"></div>
                <div class="empty-title">No Overdue Keys</div>
                <div class="empty-text">All keys are currently returned on time!</div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
        document.body.classList.add('dark');
    }
    
    // Auto-refresh every 5 minutes to check for new overdues and send notifications
    setTimeout(() => {
        location.reload();
    }, 300000); // 5 minutes
});
</script>
</body>
</html>