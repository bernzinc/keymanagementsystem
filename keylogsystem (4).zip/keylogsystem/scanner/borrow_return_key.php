<?php

require_once '../includes/functions.php';
requireAdmin(); // ensure only authorized users

header('Content-Type: application/json');
date_default_timezone_set('Asia/Manila');

try {
    $fullname = strtoupper(trim($_POST['fullname'] ?? ''));
    $keycode  = strtoupper(trim($_POST['key_code'] ?? ''));

    if (empty($fullname) || empty($keycode)) {
        echo json_encode(["success" => false, "message" => "Please scan a valid key and enter full name."]);
        exit;
    }

    // Split full name into fname + lname
    $nameParts = explode(' ', $fullname, 2);
    $fname = $nameParts[0];
    $lname = isset($nameParts[1]) ? $nameParts[1] : '';

    // --- Check if user exists ---
    $stmt = $pdo->prepare("SELECT * FROM users WHERE UPPER(Fname) = :f AND UPPER(Lname) = :l");
    $stmt->execute([':f' => $fname, ':l' => $lname]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(["success" => false, "message" => "User not found in the system."]);
        exit;
    }
    $user_id = $user['UserID'];

    // --- Get key info ---
    $stmt = $pdo->prepare("SELECT * FROM keys_m WHERE UPPER(Key_Code) = :code");
    $stmt->execute([':code' => $keycode]);
    $key = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$key) {
        echo json_encode(["success" => false, "message" => "Key not found in the system."]);
        exit;
    }
    $key_id = $key['KeyID'];
    $location = $key['Location'];

    // --- Check existing logs ---
    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'OVERDUE' LIMIT 1");
    $stmt->execute([':uid' => $user_id]);
    $overdue = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'BORROWED' LIMIT 1");
    $stmt->execute([':uid' => $user_id]);
    $unreturned = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM logs WHERE KeyID = :keyid AND Status = 'BORROWED' LIMIT 1");
    $stmt->execute([':keyid' => $key_id]);
    $borrowed = $stmt->fetch(PDO::FETCH_ASSOC);

    // ✅ CASE 1: Key borrowed by another user
    if ($borrowed && $borrowed['UserID'] != $user_id) {
        $stmt = $pdo->prepare("SELECT Fname, Lname FROM users WHERE UserID = :id");
        $stmt->execute([':id' => $borrowed['UserID']]);
        $orig_user = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode([
            "success" => false,
            "message" => "This key is currently borrowed by {$orig_user['Fname']} {$orig_user['Lname']}."
        ]);
        exit;
    }

    // ✅ CASE 2: Key borrowed or overdue by same user — return it
    if (($borrowed && $borrowed['UserID'] == $user_id) || ($overdue && $overdue['KeyID'] == $key_id)) {
        $stmt = $pdo->prepare("
            UPDATE logs 
            SET TimeReturned = NOW(), Status = 'RETURNED', updated_at = NOW()
            WHERE UserID = :uid AND KeyID = :kid AND (Status = 'BORROWED' OR Status = 'OVERDUE')
        ");
        $stmt->execute([':uid' => $user_id, ':kid' => $key_id]);
        echo json_encode(["success" => true, "message" => "Key returned successfully by {$fullname}."]);
        exit;
    }

    // ❌ CASE 3: User has overdue key — block borrowing
    if ($overdue) {
        $stmt = $pdo->prepare("
            SELECT k.Key_Code, k.Location 
            FROM keys_m k 
            INNER JOIN logs l ON k.KeyID = l.KeyID 
            WHERE l.LogID = :logid
        ");
        $stmt->execute([':logid' => $overdue['LogID']]);
        $overKey = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode([
            "success" => false,
            "message" => "You cannot borrow a new key because you have an OVERDUE key ({$overKey['Key_Code']} - {$overKey['Location']})."
        ]);
        exit;
    }

    // ❌ CASE 4: User has unreturned key — block borrowing
    if ($unreturned) {
        $stmt = $pdo->prepare("
            SELECT k.Key_Code, k.Location 
            FROM keys_m k 
            INNER JOIN logs l ON k.KeyID = l.KeyID 
            WHERE l.LogID = :logid
        ");
        $stmt->execute([':logid' => $unreturned['LogID']]);
        $pendingKey = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode([
            "success" => false,
            "message" => "You cannot borrow another key until you return ({$pendingKey['Key_Code']} - {$pendingKey['Location']})."
        ]);
        exit;
    }

    // ✅ CASE 5: Borrow new key
    $today = date('Y-m-d');
    $duedate = date('Y-m-d H:i:s', strtotime("$today 22:00:00"));

    $stmt = $pdo->prepare("
        INSERT INTO logs (KeyID, UserID, Location, Date, TimeBorrowed, DueDate, Status, created_at)
        VALUES (:key, :user, :loc, CURDATE(), NOW(), :due, 'BORROWED', NOW())
    ");
    $stmt->execute([
        ':key' => $key_id,
        ':user' => $user_id,
        ':loc' => $location,
        ':due' => $duedate
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Key borrowed successfully by {$fullname} at {$location}. Due: " . date('M d, Y h:i A', strtotime($duedate))
    ]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
}
