<?php
require_once '../includes/functions.php';
requireAdmin(); // Only admins/guards can access

date_default_timezone_set('Asia/Manila');

$msg = $error = '';

try {
    // 🔹 Fetch all users (concat full name)
    $users = $pdo->query("
        SELECT UserID, CONCAT(Fname, ' ', Lname) AS FullName 
        FROM users 
        ORDER BY Lname ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // 🔹 Fetch all keys
    $keys = $pdo->query("
        SELECT Key_Code, Location 
        FROM keys_m 
        ORDER BY Location ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fullname = strtoupper(trim($_POST['fullname']));
        $keycode = strtoupper(trim($_POST['keycode']));

        if (empty($fullname) || empty($keycode)) {
            $error = "Please fill in all required fields.";
        } else {
            // Split full name into fname + lname
            $nameParts = explode(' ', $fullname, 2);
            $fname = $nameParts[0];
            $lname = isset($nameParts[1]) ? $nameParts[1] : '';

            // 🔹 Check if user exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE UPPER(Fname) = :f AND UPPER(Lname) = :l");
            $stmt->execute([':f' => $fname, ':l' => $lname]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $error = "User not found in the system.";
            } else {
                $user_id = $user['UserID'];

                // 🔹 Get key info
                $stmt = $pdo->prepare("SELECT * FROM keys_m WHERE UPPER(Key_Code) = :code");
                $stmt->execute([':code' => $keycode]);
                $key = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$key) {
                    $error = "Key not found in the system.";
                } else {
                    $key_id = $key['KeyID'];
                    $location = $key['Location'];

                    // 🔹 Check existing logs
                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'OVERDUE' LIMIT 1");
                    $stmt->execute([':uid' => $user_id]);
                    $overdue = $stmt->fetch(PDO::FETCH_ASSOC);

                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'BORROWED' LIMIT 1");
                    $stmt->execute([':uid' => $user_id]);
                    $unreturned = $stmt->fetch(PDO::FETCH_ASSOC);

                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE KeyID = :keyid AND Status = 'BORROWED' LIMIT 1");
                    $stmt->execute([':keyid' => $key_id]);
                    $borrowed = $stmt->fetch(PDO::FETCH_ASSOC);

                    // ✅ CASE 1: Key borrowed by another user
                    if ($borrowed && $borrowed['UserID'] != $user_id) {
                        $stmt = $pdo->prepare("SELECT Fname, Lname FROM users WHERE UserID = :id");
                        $stmt->execute([':id' => $borrowed['UserID']]);
                        $orig_user = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "This key is currently borrowed by {$orig_user['Fname']} {$orig_user['Lname']}.";
                    }
                    // ✅ CASE 2: Key borrowed or overdue by same user — return it
                    elseif (($borrowed && $borrowed['UserID'] == $user_id) || ($overdue && $overdue['KeyID'] == $key_id)) {
                        $stmt = $pdo->prepare("
                            UPDATE logs 
                            SET TimeReturned = NOW(), Status = 'RETURNED', updated_at = NOW()
                            WHERE UserID = :uid AND KeyID = :kid AND (Status = 'BORROWED' OR Status = 'OVERDUE')
                        ");
                        $stmt->execute([':uid' => $user_id, ':kid' => $key_id]);
                        $msg = "Key returned successfully by {$fullname}.";
                    }
                    // ❌ CASE 3: User has an overdue key — block borrowing
                    elseif ($overdue) {
                        $stmt = $pdo->prepare("
                            SELECT k.Key_Code, k.Location 
                            FROM keys_m k 
                            INNER JOIN logs l ON k.KeyID = l.KeyID 
                            WHERE l.LogID = :logid
                        ");
                        $stmt->execute([':logid' => $overdue['LogID']]);
                        $overKey = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "You cannot borrow a new key because you have an OVERDUE key ({$overKey['Key_Code']} - {$overKey['Location']}).";
                    }
                    // ❌ CASE 4: User has unreturned key — block borrowing
                    elseif ($unreturned) {
                        $stmt = $pdo->prepare("
                            SELECT k.Key_Code, k.Location 
                            FROM keys_m k 
                            INNER JOIN logs l ON k.KeyID = l.KeyID 
                            WHERE l.LogID = :logid
                        ");
                        $stmt->execute([':logid' => $unreturned['LogID']]);
                        $pendingKey = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "You cannot borrow another key until you return ({$pendingKey['Key_Code']} - {$pendingKey['Location']}).";
                    }
                    // ✅ CASE 5: Borrow new key
                    else {
                        $today = date('Y-m-d');
                        $duedate = date('Y-m-d H:i:s', strtotime("$today 16:35:00"));

                        $stmt = $pdo->prepare("
                            INSERT INTO logs (KeyID, UserID, Location, Date, TimeBorrowed, DueDate, Status, created_at)
                            VALUES (:key, :user, :loc, CURDATE(), NOW(), :due, 'BORROWED', NOW())
                        ");
                        $stmt->execute([
                            ':key' => $key_id,
                            ':user' => $user_id,
                            ':loc' => $location,
                            ':due' => $duedate
                        ]);

                        $msg = "Key borrowed successfully by {$fullname} at {$location}.<br>Due: " . date('M d, Y h:i A', strtotime($duedate));
                    }
                }
            }
        }
    }
} catch (PDOException $e) {
    $error = "Database error: " . htmlspecialchars($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Manual Scanner - ADFC</title>
    
    <link rel="icon" href="/favicon.ico" sizes="any">
    <link rel="icon" href="/assets/images/favicon-32x32.png" type="image/png">
    <link rel="apple-touch-icon" href="/assets/images/apple-touch-icon.png"> 
    <link rel="manifest" href="/site.webmanifest">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --bg: #f1f5f9;
            --text: #1e293b;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --shadow: rgba(0, 0, 0, 0.1);
            --input-bg: #f8fafc;
        }

        body.dark {
            --bg: #0f172a;
            --text: #f1f5f9;
            --card-bg: #1e293b;
            --border: #334155;
            --shadow: rgba(0, 0, 0, 0.3);
            --input-bg: #0f172a;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            transition: all 0.3s ease;
        }

        .container {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 550px;
            box-shadow: 0 4px 20px var(--shadow);
            border: 1px solid var(--border);
            animation: slideIn 0.4s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            text-align: center;
            margin-bottom: 32px;
        }

        .icon-container {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            color: white;
            box-shadow: 0 8px 16px rgba(59, 130, 246, 0.3);
        }

        h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            color: #64748b;
            font-size: 14px;
        }

        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: flex-start;
            gap: 10px;
            animation: slideIn 0.3s ease;
        }

        .alert-icon {
            font-size: 18px;
            flex-shrink: 0;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid var(--success);
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid var(--danger);
        }

        .form-group {
            margin-bottom: 24px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        label i {
            margin-right: 6px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            color: #94a3b8;
            pointer-events: none;
        }

        input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 15px;
            background: var(--input-bg);
            color: var(--text);
            transition: all 0.3s ease;
            font-family: inherit;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--card-bg);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        input::placeholder {
            color: #94a3b8;
        }

        .btn-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 32px;
        }

        button {
            padding: 14px 24px;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        button i {
            margin-right: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
            grid-column: span 2;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .btn-secondary {
            background: var(--input-bg);
            color: var(--text);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: var(--border);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .container {
                padding: 24px;
                border-radius: 16px;
            }

            .icon-container {
                width: 60px;
                height: 60px;
                font-size: 30px;
            }

            h2 {
                font-size: 24px;
            }

            .subtitle {
                font-size: 13px;
            }

            input {
                font-size: 16px; /* Prevents zoom on iOS */
                padding: 12px 12px 12px 44px;
            }

            button {
                padding: 12px 20px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }

            h2 {
                font-size: 20px;
            }

            .btn-group {
                grid-template-columns: 1fr;
            }

            .btn-primary {
                grid-column: span 1;
            }
        }

        /* Loading animation */
        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Focus indicator for accessibility */
        *:focus-visible {
            outline: 2px solid var(--primary);
            outline-offset: 2px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="icon-container">
                <i class="fas fa-camera"></i>
            </div>
            <h2>Manual Scanner</h2>
            <p class="subtitle">Scan keys manually by selecting user and key</p>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-success">
                <span class="alert-icon"><i class="fas fa-check-circle"></i></span>
                <div><?= $msg ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="alert alert-error">
                <span class="alert-icon"><i class="fas fa-exclamation-triangle"></i></span>
                <div><?= $error ?></div>
            </div>
        <?php endif; ?>

        <form method="POST" id="scanForm">
            <div class="form-group">

                <div class="input-wrapper">
                    <i class="fas fa-user input-icon"></i>
                    <input 
                        list="userList" 
                        name="fullname" 
                        id="fullname"
                        placeholder="Select or type full name"
                        autocomplete="off"
                        required
                    >
                </div>
                <datalist id="userList">
                    <?php foreach ($users as $user): ?>
                        <option value="<?= htmlspecialchars($user['FullName']) ?>">
                    <?php endforeach; ?>
                </datalist>
            </div>

            <div class="form-group">

                <div class="input-wrapper">
                    <i class="fas fa-key input-icon"></i>
                    <input 
                        list="keyList" 
                        name="keycode" 
                        id="keycode"
                        placeholder="Select or type key code"
                        autocomplete="off"
                        required
                    >
                </div>
                <datalist id="keyList">
                    <?php foreach ($keys as $key): ?>
                        <option 
                            value="<?= htmlspecialchars($key['Key_Code']) ?>" 
                            label="<?= htmlspecialchars($key['Location']) ?>">
                    <?php endforeach; ?>
                </datalist>
            </div>

            <div class="btn-group">
                <button type="submit" class="btn-primary" id="submitBtn">
                    <i class="fas fa-paper-plane"></i> Submit Scan
                </button>
            </div>
        </form>
    </div>

    <script>
        // Load theme from localStorage (synced with dashboard)
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark');
        }

        // Listen for theme changes from other tabs/pages
        window.addEventListener('storage', (e) => {
            if (e.key === 'theme') {
                if (e.newValue === 'dark') {
                    document.body.classList.add('dark');
                } else {
                    document.body.classList.remove('dark');
                }
            }
        });

        // Auto-focus on key code field
        window.onload = () => {
            document.getElementById('keycode').focus();
        };

        // Form submission with loading state
        const form = document.getElementById('scanForm');
        const submitBtn = document.getElementById('submitBtn');
        
        form.addEventListener('submit', () => {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            submitBtn.disabled = true;
        });

        // Enhanced input validation
        const fullnameInput = document.getElementById('fullname');
        const keycodeInput = document.getElementById('keycode');

        fullnameInput.addEventListener('input', (e) => {
            e.target.value = e.target.value.toUpperCase();
        });

        keycodeInput.addEventListener('input', (e) => {
            e.target.value = e.target.value.toUpperCase();
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Alt + B to go back
            if (e.altKey && e.key === 'b') {
                e.preventDefault();
                window.location.href = '../dashboard.php';
            }
        });
    </script>
</body>
</html>