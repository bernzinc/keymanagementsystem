<?php
require_once '../includes/functions.php';
requireAdmin();

// If AJAX request for live search
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $search = $_GET['search'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE Key_Code LIKE :s OR Room_ID LIKE :s OR Location LIKE :s ORDER BY KeyID ASC");
    $stmt->execute([':s' => "%$search%"]);
    $keys = $stmt->fetchAll();

    // Return table rows only
    foreach ($keys as $key) {
        echo "<tr>
            <td><span class='id-badge'>{$key['KeyID']}</span></td>
            <td><strong>" . htmlspecialchars($key['Room_ID']) . "</strong></td>
            <td><span class='key-code'>" . htmlspecialchars($key['Key_Code']) . "</span></td>
            <td><img src='https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($key['Key_Code']) . "&size=60x60' class='qr' alt='QR Code'></td>
            <td>" . htmlspecialchars($key['Location']) . "</td>
            <td><span class='status-badge status-" . strtolower($key['status']) . "'>" . htmlspecialchars(strtoupper($key['status'])) . "</span></td>
            <td>" . htmlspecialchars(date('M d, Y', strtotime($key['Date_Added']))) . "</td>
            <td class='actions'>
                <a href='view_key.php?id={$key['KeyID']}' class='btn-action btn-view' title='View'><i class='fas fa-eye'></i></a>
                <a href='edit_key.php?id={$key['KeyID']}' class='btn-action btn-edit' title='Edit'><i class='fas fa-edit'></i></a>
                <a href='#' class='btn-action btn-delete' data-id='{$key['KeyID']}' title='Delete'><i class='fas fa-trash-alt'></i></a>
            </td>
        </tr>";
    }

    if (empty($keys)) echo "<tr><td colspan='8' class='no-data'>No keys found.</td></tr>";
    exit;
}

// Handle delete action normally
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM `keys_m` WHERE KeyID = :id");
    $stmt->execute([':id' => $id]);
    header("Location: keys.php?deleted=1");
    exit;
}

// Initial load
$stmt = $pdo->query("SELECT * FROM `keys_m` ORDER BY KeyID ASC");
$keys = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Keys Management - ADFC</title>

<!-- Font Awesome for Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../assets/keys.css">
</head>
<body>
<div class="container">
    <div class="header">
        <div class="header-top">
            <h1><i class="fas fa-key"></i> Keys Management</h1>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="location.href='add_key.php'">
                    <i class="fas fa-plus"></i> Add New Key
                </button>
            </div>
        </div>

        <?php if (isset($_GET['deleted'])): ?>
            <div class="alert">
                <i class="fas fa-check-circle"></i>
                Key deleted successfully!
            </div>
        <?php endif; ?>

        <div class="search-container">
            <i class="fas fa-search search-icon"></i>
            <input 
                type="text" 
                id="searchInput" 
                class="search-input"
                placeholder="Search by key code, room ID, or location..."
                autocomplete="off"
            >
        </div>
    </div>

    <div class="table-card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Room ID</th>
                        <th>Key Code</th>
                        <th>QR Code</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <?php foreach ($keys as $key): ?>
                    <tr>
                        <td><span class="id-badge"><?= $key['KeyID'] ?></span></td>
                        <td><strong><?= htmlspecialchars($key['Room_ID']) ?></strong></td>
                        <td><span class="key-code"><?= htmlspecialchars($key['Key_Code']) ?></span></td>
                        <td><img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($key['Key_Code']) ?>&size=60x60" class="qr" alt="QR Code"></td>
                        <td><?= htmlspecialchars($key['Location']) ?></td>
                        <td><span class="status-badge status-<?= strtolower($key['status']) ?>"><?= htmlspecialchars(strtoupper($key['status'])) ?></span></td>
                        <td><?= htmlspecialchars(date('M d, Y', strtotime($key['Date_Added']))) ?></td>
                        <td class="actions">
                            <a href="view_key.php?id=<?= $key['KeyID'] ?>" class="btn-action btn-view" title="View"><i class="fas fa-eye"></i></a>
                            <a href="edit_key.php?id=<?= $key['KeyID'] ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="#" class="btn-action btn-delete" data-id="<?= $key['KeyID'] ?>" title="Delete"><i class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Load theme
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
        document.body.classList.add('dark');
    }
});


// Live search
let typingTimer;
const searchInput = document.getElementById('searchInput');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const search = searchInput.value;
        fetch(`keys.php?ajax=1&search=${encodeURIComponent(search)}`)
            .then(res => res.text())
            .then(data => {
                tableBody.innerHTML = data;
                attachDeleteHandlers();
            });
    }, 300);
});

// Delete confirmation
function attachDeleteHandlers() {
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const id = this.dataset.id;

            Swal.fire({
                title: 'Delete Key?',
                text: 'This action cannot be undone',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'keys.php?delete=' + id;
                }
            });
        });
    });
}

attachDeleteHandlers();
</script>
</body>
</html>