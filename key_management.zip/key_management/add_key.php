<?php
require_once '../includes/functions.php';
// Assuming $pdo is available after requiring functions.php
requireAdmin();

$msg = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Input validation (highly recommended to add here)
    if (empty($_POST['Room_ID']) || empty($_POST['Key_Code']) || empty($_POST['Location'])) {
        $error = "All fields are required.";
    } else {
        try {
            $room = trim($_POST['Room_ID']);
            $code = trim($_POST['Key_Code']);
            $location = trim($_POST['Location']);
            $status = $_POST['Status'] ?? 'Available';
            $date = date('Y-m-d H:i:s'); // Use full timestamp for better tracking

            // Insert into the database
            $stmt = $pdo->prepare("INSERT INTO `keys_m` (Room_ID, Key_Code, Location, QRCode, Status, Date_Added) 
                                 VALUES (:r, :k, :l, :q, :s, :d)");
            
            // Note: Using Key_Code for QRCode field as per your original logic
            $stmt->execute([
                ':r' => $room,
                ':k' => $code,
                ':l' => $location,
                ':q' => $code, 
                ':s' => $status,
                ':d' => $date
            ]);

            $msg = "Key " . htmlspecialchars($code) . " added successfully!";
        } catch (PDOException $e) {
            if (isset($e->errorInfo[1]) && $e->errorInfo[1] == 1062) {
                $error = "Key Code already exists. Please use a different Key Code.";
            } else {
                // Generic message for other errors; log details for debugging
                $error = "Error adding key. Please try again.";
                error_log("Add key error: " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Key - ADFC</title>
    <link rel="stylesheet" href="../assets/theme.css"> 
    <style>
        /* Re-defining core variables for standalone testing/reference */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --bg: #f1f5f9;
            --text: #1e293b;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --shadow: rgba(0, 0, 0, 0.1);
            --input-bg: #f8fafc;
        }

        body.dark {
            --bg: #0f172a;
            --text: #f1f5f9;
            --card-bg: #1e293b;
            --border: #334155;
            --shadow: rgba(0, 0, 0, 0.3);
            --input-bg: #0f172a;
        }

        /* --- Layout & Card Styling --- */
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            padding: 24px;
            transition: all 0.3s ease;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 48px); /* Adjust height for padding */
        }

        .form-card {
            background: var(--card-bg);
            color: var(--text);
            padding: 32px;
            max-width: 500px;
            width: 100%;
            border-radius: 16px;
            box-shadow: 0 4px 12px var(--shadow);
            border: 1px solid var(--border);
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            text-align: center;
            margin-bottom: 24px;
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-dark);
        }
        
        /* --- Form Elements --- */

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
            font-size: 14px;
        }

        .input-field {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            background: var(--input-bg);
            color: var(--text);
            transition: all 0.3s ease;
            box-sizing: border-box;
            height: 48px;
        }

        .input-field:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--card-bg);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        select.input-field {
            /* Custom appearance for select */
            appearance: none;
            background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%2364748b' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            background-size: 10px 6px;
            padding-right: 40px;
        }

        /* --- Buttons --- */
        .actions-group {
            text-align: center;
            margin-top: 30px;
            display: flex;
            gap: 12px;
            justify-content: center;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: var(--input-bg);
            color: var(--text);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: var(--border);
        }

        /* --- Alerts and QR Preview --- */
        .alert {
            padding: 14px 18px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            justify-content: center;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid var(--success);
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid var(--danger);
        }

        .qr-preview {
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            background: var(--bg);
            border-radius: 10px;
            border: 1px dashed var(--border);
        }

        .qr-placeholder {
            color: #94a3b8;
            font-style: italic;
            font-size: 14px;
        }

        .qr-image {
            width: 100px;
            height: 100px;
            border-radius: 6px;
            box-shadow: 0 2px 4px var(--shadow);
            transition: transform 0.3s ease;
        }

        /* Mobile Adjustments */
        @media (max-width: 600px) {
            .form-card {
                padding: 20px;
            }
            .actions-group {
                flex-direction: column;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-card">
        <h2>➕ Add New Key</h2>

        <?php if ($msg): ?>
            <div class="alert alert-success">
                <span></span>
                <?= $msg ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <span></span>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="room_id">Room ID:</label>
                <input type="text" name="Room_ID" id="room_id" class="input-field" required>
            </div>

            <div class="form-group">
                <label for="key_code">Key Code:</label>
                <input type="text" name="Key_Code" id="key_code" class="input-field" required oninput="updateQR()">
            </div>

            <div class="form-group">
                <label for="location">Location (Building/Area):</label>
                <input type="text" name="Location" id="location" class="input-field" required 
                    placeholder="e.g., Main Building - 3rd Floor">
            </div>

            <div class="form-group">
                <label for="status">Initial Status:</label>
                <select name="Status" id="status" class="input-field">
                    <option value="Available">Available</option>
                    <option value="Lost">Lost</option>
                    </select>
            </div>
            
            <div class="qr-preview" id="qrPreview">
                <p class="qr-placeholder">QR Code will appear here when Key Code is entered.</p>
            </div>

            <div class="actions-group">
                <button type="submit" class="btn btn-primary">
                    Save Key
                </button>
                <button type="button" class="btn btn-secondary" onclick="window.location.href='keys.php'">
                    ← Back to Keys List
                </button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/theme.js"></script>
<script>
function updateQR() {
    const code = document.getElementById('key_code').value.trim();
    const qrDiv = document.getElementById('qrPreview');

    if (code) {
        qrDiv.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(code)}&size=100x100" class='qr-image' alt='QR Code for key: ${code}'>`;
    } else {
        qrDiv.innerHTML = `<p class="qr-placeholder">QR Code will appear here when Key Code is entered.</p>`;
    }
}
</script>
</body>
</html>