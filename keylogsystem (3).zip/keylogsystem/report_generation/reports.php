<?php
require_once '../includes/functions.php';
requireAdmin();

// Handle AJAX request for filtering reports
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $from = $_GET['from'] ?? date('Y-m-01');
    $to = $_GET['to'] ?? date('Y-m-d');

    $stmt = $pdo->prepare("SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) as FullName, 
                           l.Location, l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
                           FROM logs l
                           JOIN keys_m k ON l.KeyID = k.KeyID
                           JOIN users u ON l.UserID = u.UserID
                           WHERE l.Date BETWEEN :from AND :to
                           ORDER BY l.Date DESC");
    $stmt->execute([':from' => $from, ':to' => $to]);
    $logs = $stmt->fetchAll();

    if ($logs) {
        foreach ($logs as $log) {
            echo "<tr>
                <td>" . htmlspecialchars($log['Key_Code']) . "</td>
                <td>" . strtoupper(htmlspecialchars($log['FullName'])) . "</td>
                <td>" . htmlspecialchars($log['Location']) . "</td>
                <td>" . htmlspecialchars(date('m-d-Y', strtotime($log['Date']))) . "</td>
                <td>" . htmlspecialchars($log['TimeBorrowed']) . "</td>
                <td>" . htmlspecialchars($log['TimeReturned'] ?? '-') . "</td>
                <td class='status " . strtolower($log['Status']) . "'>" . strtoupper($log['Status']) . "</td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='7'>No records found for this date range.</td></tr>";
    }
    exit;
}

// Default initial data
$from = date('Y-m-01');
$to = date('Y-m-d');
$stmt = $pdo->prepare("SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) as FullName,
                       l.Location, l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
                       FROM logs l
                       JOIN keys_m k ON l.KeyID = k.KeyID
                       JOIN users u ON l.UserID = u.UserID
                       WHERE l.Date BETWEEN :from AND :to
                       ORDER BY l.Date DESC");
$stmt->execute([':from' => $from, ':to' => $to]);
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Report Generation</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
:root {
  --bg: #f8f9fa;
  --text: #212529;
  --card-bg: #e9ecef;
  --table-bg: #ffffff;
  --btn-blue: #17a2b8;
  --btn-blue-dark: #138496;
  --status-success: #28a745;
  --status-overdue: #ffc107;
  --status-lost: #dc3545;
}
body.dark {
  --bg: #2b2b2b;
  --text: #f8f9fa;
  --card-bg: #3a3a3a;
  --table-bg: #2f2f2f;
}
body {
  font-family: Arial, sans-serif;
  background-color: var(--bg);
  color: var(--text);
  margin: 0;
  padding: 40px;
  transition: 0.3s;
}
.container {
  max-width: 1200px;
  margin: auto;
  background-color: var(--card-bg);
  padding: 30px;
  border-radius: 8px;
}
h1 {
  font-size: 28px;
  margin-bottom: 25px;
}
.filter-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
}
.date-range {
  font-size: 18px;
  font-weight: bold;
}
.date-range input {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 15px;
  background-color: var(--table-bg);
  color: var(--text);
}
.table-wrapper {
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  border-radius: 8px;
  background: var(--table-bg);
  margin-bottom: 20px;
}
table {
  width: 100%;
  border-collapse: collapse;
  background-color: var(--table-bg);
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 20px;
  min-width: 760px; /* keep columns readable, mobile will scroll */
}
th, td {
  text-align: center;
  padding: 12px;
  border-bottom: 1px solid #999;
}
th {
  background-color: var(--card-bg);
  font-weight: bold;
}
.status {
  font-weight: bold;
}
.status.overdue { color: var(--status-overdue); }
.status.successful { color: var(--status-success); }
.status.lost { color: var(--status-lost); }
.btn-group {
  display: flex;
  justify-content: center;
  gap: 20px;
}
.btn {
  background-color: var(--btn-blue);
  color: white;
  font-weight: bold;
  padding: 12px 30px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.3s;
}
.btn:hover {
  background-color: var(--btn-blue-dark);
}

/* -------------------------
   Responsive / Mobile View
   ------------------------- */
@media screen and (max-width: 1024px) {
  .container { padding: 22px; }
  .date-range input { font-size: 14px; padding: 7px; }
  table { min-width: 680px; }
}

@media screen and (max-width: 768px) {
  body { padding: 12px; }
  .container { padding: 16px; border-radius: 10px; }
  h1 { font-size: 20px; margin-bottom: 16px; text-align: center; }

  /* stack filters */
  .filter-section { flex-direction: column; align-items: stretch; gap: 12px; }
  .date-range { display: flex; gap: 8px; justify-content: space-between; flex-wrap: wrap; }
  .date-range input { flex: 1 1 48%; min-width: 120px; }

  /* table scroll wrapper */
  .table-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
  table { min-width: 640px; }
  th, td { text-align: left; padding: 10px; white-space: nowrap; }
  thead th { position: sticky; top: 0; z-index: 2; background: var(--card-bg); font-size: 13px; }

  /* buttons stack and full width */
  .btn-group { flex-direction: column; gap: 10px; }
  .btn { width: 100%; padding: 12px; font-size: 15px; }
}

@media screen and (max-width: 420px) {
  .date-range input { flex: 1 1 100%; font-size: 14px; padding: 10px; }
  table { min-width: 520px; }
  th, td { font-size: 13px; padding: 8px; }
}

/* Optional: stacked card layout for very narrow devices */
@media screen and (max-width: 360px) {
  table, thead, tbody, th, td, tr { display: block; }
  thead { display: none; }
  tr { margin-bottom: 12px; background: var(--table-bg); border-radius: 8px; padding: 8px; }
  td { padding: 6px 8px; border: none; text-align: left; }
  td::before { font-weight: 600; display: inline-block; width: 110px; color: #666; }
  td:nth-of-type(1)::before { content: "KEY"; }
  td:nth-of-type(2)::before { content: "USER"; }
  td:nth-of-type(3)::before { content: "LOCATION"; }
  td:nth-of-type(4)::before { content: "DATE"; }
  td:nth-of-type(5)::before { content: "TIME BORROWED"; }
  td:nth-of-type(6)::before { content: "TIME RETURNED"; }
  td:nth-of-type(7)::before { content: "STATUS"; }
}
</style>
</head>
<body>
<div class="container">
  <h1>REPORT GENERATION</h1>

  <div class="filter-section">
    <div class="date-range">
      From: <input type="date" id="from" value="<?= $from ?>"> 
      To: <input type="date" id="to" value="<?= $to ?>">
    </div>
  </div>

  <!-- Wrap table in a scrollable container for mobile -->
  <div class="table-wrapper">
  <table>
      <thead>
        <tr>
          <th>KEY_CODE</th>
          <th>USER</th>
          <th>LOCATION</th>
          <th>DATE</th>
          <th>TIMEBORROWED</th>
          <th>TIMERETURNED</th>
          <th>STATUS</th>
        </tr>
      </thead>
      <tbody id="reportBody">
        <?php if ($logs): ?>
          <?php foreach ($logs as $log): ?>
            <tr>
              <td><?= htmlspecialchars($log['Key_Code']) ?></td>
              <td><?= strtoupper(htmlspecialchars($log['FullName'])) ?></td>
              <td><?= htmlspecialchars($log['Location']) ?></td>
              <td><?= htmlspecialchars(date('m-d-Y', strtotime($log['Date']))) ?></td>
              <td><?= htmlspecialchars($log['TimeBorrowed']) ?></td>
              <td><?= htmlspecialchars($log['TimeReturned'] ?? '-') ?></td>
              <td class="status <?= strtolower($log['Status']) ?>"><?= strtoupper($log['Status']) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="7">No records found.</td></tr>
        <?php endif; ?>
      </tbody>
  </table>
  </div>

  <div class="btn-group">
    <button class="btn" id="generateBtn">GENERATE</button>
    <button class="btn" id="exportBtn">EXPORT</button>
    <button class="btn" onclick="location.href='../dashboard.php'">BACK</button>
  </div>
</div>


<script>
// Theme sync
document.addEventListener('DOMContentLoaded', () => {
  const theme = localStorage.getItem('theme');
  if (theme === 'dark') document.body.classList.add('dark');
});

// Generate report via AJAX
document.getElementById('generateBtn').addEventListener('click', () => {
  const from = document.getElementById('from').value;
  const to = document.getElementById('to').value;

  fetch(`reports.php?ajax=1&from=${from}&to=${to}`)
    .then(res => res.text())
    .then(data => {
      document.getElementById('reportBody').innerHTML = data;
    });
});
// Export to CSV
document.getElementById('exportBtn').addEventListener('click', () => {
  const rows = document.querySelectorAll('table tr');
  let csv = [];
  rows.forEach(row => {
    const cols = row.querySelectorAll('th, td');
    const data = Array.from(cols).map(td => `"${td.innerText}"`);
    csv.push(data.join(','));
  });
  const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(csvFile);
  link.download = 'report.csv';
  link.click();
});
</script>
</body>
</html>
