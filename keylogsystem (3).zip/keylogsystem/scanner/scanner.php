<?php
require_once '../includes/functions.php';
requireAdmin(); // Only admins/guards can access

date_default_timezone_set('Asia/Manila');

$msg = $error = '';

try {
    // 🔹 Fetch all users (concat full name)
    $users = $pdo->query("
        SELECT UserID, CONCAT(Fname, ' ', Lname) AS FullName 
        FROM users 
        ORDER BY Lname ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // 🔹 Fetch all keys
    $keys = $pdo->query("
        SELECT Key_Code, Location 
        FROM keys_m 
        ORDER BY Location ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fullname = strtoupper(trim($_POST['fullname']));
        $keycode = strtoupper(trim($_POST['keycode']));

        if (empty($fullname) || empty($keycode)) {
            $error = "Please fill in all required fields.";
        } else {
            // Split full name into fname + lname
            $nameParts = explode(' ', $fullname, 2);
            $fname = $nameParts[0];
            $lname = isset($nameParts[1]) ? $nameParts[1] : '';

            // 🔹 Check if user exists
            $stmt = $pdo->prepare("SELECT * FROM users WHERE UPPER(Fname) = :f AND UPPER(Lname) = :l");
            $stmt->execute([':f' => $fname, ':l' => $lname]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $error = "User not found in the system.";
            } else {
                $user_id = $user['UserID'];

                // 🔹 Get key info
                $stmt = $pdo->prepare("SELECT * FROM keys_m WHERE UPPER(Key_Code) = :code");
                $stmt->execute([':code' => $keycode]);
                $key = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$key) {
                    $error = "Key not found in the system.";
                } else {
                    $key_id = $key['KeyID'];
                    $location = $key['Location'];

                    // 🔹 Check existing logs
                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'OVERDUE' LIMIT 1");
                    $stmt->execute([':uid' => $user_id]);
                    $overdue = $stmt->fetch(PDO::FETCH_ASSOC);

                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE UserID = :uid AND Status = 'BORROWED' LIMIT 1");
                    $stmt->execute([':uid' => $user_id]);
                    $unreturned = $stmt->fetch(PDO::FETCH_ASSOC);

                    $stmt = $pdo->prepare("SELECT * FROM logs WHERE KeyID = :keyid AND Status = 'BORROWED' LIMIT 1");
                    $stmt->execute([':keyid' => $key_id]);
                    $borrowed = $stmt->fetch(PDO::FETCH_ASSOC);

                    // ✅ CASE 1: Key borrowed by another user
                    if ($borrowed && $borrowed['UserID'] != $user_id) {
                        $stmt = $pdo->prepare("SELECT Fname, Lname FROM users WHERE UserID = :id");
                        $stmt->execute([':id' => $borrowed['UserID']]);
                        $orig_user = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "This key is currently borrowed by {$orig_user['Fname']} {$orig_user['Lname']}.";
                    }
                    // ✅ CASE 2: Key borrowed or overdue by same user — return it
                    elseif (($borrowed && $borrowed['UserID'] == $user_id) || ($overdue && $overdue['KeyID'] == $key_id)) {
                        $stmt = $pdo->prepare("
                            UPDATE logs 
                            SET TimeReturned = NOW(), Status = 'RETURNED', updated_at = NOW()
                            WHERE UserID = :uid AND KeyID = :kid AND (Status = 'BORROWED' OR Status = 'OVERDUE')
                        ");
                        $stmt->execute([':uid' => $user_id, ':kid' => $key_id]);
                        $msg = "Key returned successfully by {$fullname}.";
                    }
                    // ❌ CASE 3: User has an overdue key — block borrowing
                    elseif ($overdue) {
                        $stmt = $pdo->prepare("
                            SELECT k.Key_Code, k.Location 
                            FROM keys_m k 
                            INNER JOIN logs l ON k.KeyID = l.KeyID 
                            WHERE l.LogID = :logid
                        ");
                        $stmt->execute([':logid' => $overdue['LogID']]);
                        $overKey = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "You cannot borrow a new key because you have an OVERDUE key ({$overKey['Key_Code']} - {$overKey['Location']}).";
                    }
                    // ❌ CASE 4: User has unreturned key — block borrowing
                    elseif ($unreturned) {
                        $stmt = $pdo->prepare("
                            SELECT k.Key_Code, k.Location 
                            FROM keys_m k 
                            INNER JOIN logs l ON k.KeyID = l.KeyID 
                            WHERE l.LogID = :logid
                        ");
                        $stmt->execute([':logid' => $unreturned['LogID']]);
                        $pendingKey = $stmt->fetch(PDO::FETCH_ASSOC);
                        $error = "You cannot borrow another key until you return ({$pendingKey['Key_Code']} - {$pendingKey['Location']}).";
                    }
                    // ✅ CASE 5: Borrow new key
                    else {
                        $today = date('Y-m-d');
                        $duedate = date('Y-m-d H:i:s', strtotime("$today 22:00:00"));

                        $stmt = $pdo->prepare("
                            INSERT INTO logs (KeyID, UserID, Location, Date, TimeBorrowed, DueDate, Status, created_at)
                            VALUES (:key, :user, :loc, CURDATE(), NOW(), :due, 'BORROWED', NOW())
                        ");
                        $stmt->execute([
                            ':key' => $key_id,
                            ':user' => $user_id,
                            ':loc' => $location,
                            ':due' => $duedate
                        ]);

                        $msg = "Key borrowed successfully by {$fullname} at {$location}.<br>Due: " . date('M d, Y h:i A', strtotime($duedate));
                    }
                }
            }
        }
    }
} catch (PDOException $e) {
    $error = "Database error: " . htmlspecialchars($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Key Scanner Management</title>
    <link rel="stylesheet" href="../assets/theme.css">
    <style>
        body {
            background-color: var(--bg);
            color: var(--text);
            font-family: Arial, sans-serif;
            padding: 40px;
            transition: background-color 0.3s, color 0.3s;
        }

        .container {
            max-width: 500px;
            margin: auto;
            background-color: var(--table-bg);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
            color: var(--text);
        }

        input {
            width: 100%;
            padding: 12px 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 15px;
            background-color: var(--table-bg);
            color: var(--text);
            box-sizing: border-box;
            height: 45px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #0056b3;
        }

        .msg {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }


    /* Mobile Responsive Styles */
    @media screen and (max-width: 768px) {
        body {
            padding: 15px;
        }

        .container {
            width: 100%;
            padding: 15px;
            margin: 10px auto;
        }

        h2 {
            font-size: 20px;
            margin-bottom: 15px;
        }

        input {
            font-size: 16px; /* Prevent zoom on iOS */
            padding: 10px;
            height: 40px;
            margin-bottom: 10px;
        }

        button {
            padding: 12px;
            font-size: 16px;
            margin-bottom: 10px;
            height: 45px; /* Larger touch target */
            -webkit-appearance: none; /* Fix iOS button styling */
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
        }

        .msg, .error {
            padding: 12px;
            font-size: 14px;
            margin-bottom: 15px;
        }

        /* Improve datalist dropdown */
        input[list] {
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml;utf8,<svg fill='gray' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
            background-repeat: no-repeat;
            background-position: right 8px center;
            padding-right: 30px;
        }
    }

    /* Small phones */
    @media screen and (max-width: 360px) {
        body {
            padding: 10px;
        }

        .container {
            padding: 12px;
        }

        h2 {
            font-size: 18px;
        }

        input, button {
            font-size: 14px;
        }
    }
</style>

<!-- Add viewport meta tag in head if not present -->

    </style>

    <script>
        window.onload = () => document.getElementById("keycode").focus();
        window.addEventListener("storage", (e) => {
            if (e.key === "theme") document.documentElement.setAttribute("data-theme", e.newValue);
        });
    </script>
</head>
<body>
    <div class="container">
        <h2>Manual Scanning Management</h2>

        <?php if (!empty($msg)) echo "<div class='msg'>{$msg}</div>"; ?>
        <?php if (!empty($error)) echo "<div class='error'>{$error}</div>"; ?>

        <form method="POST">
            <label>Select or type User:</label><br><br>
            <input list="userList" name="fullname" placeholder="Select or type full name" required>
            <datalist id="userList">
                <?php foreach ($users as $user): ?>
                    <option value="<?= htmlspecialchars($user['FullName']) ?>">
                <?php endforeach; ?>
            </datalist>

            <label>Select or type key:</label><br><br>
            <input list="keyList" name="keycode" id="keycode" placeholder="Select or type key..." required>
            <datalist id="keyList">
                <?php foreach ($keys as $key): ?>
                    <option value="<?= htmlspecialchars($key['Key_Code']) ?>" label="<?= htmlspecialchars($key['Location']) ?>">
                <?php endforeach; ?>
            </datalist>

            <button type="submit">Submit</button><br><br>
            <button type="button" onclick="location.href='../dashboard.php'">Back</button>
        </form>
    </div>

    <script src="../assets/theme.js"></script>
</body>
</html>
