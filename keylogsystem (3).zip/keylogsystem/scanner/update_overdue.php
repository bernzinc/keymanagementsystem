<?php
require_once '../config.php'; // DB + requireAdmin
requireAdmin();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';

date_default_timezone_set('Asia/Manila');

// --- STEP 1: Mark overdue keys ---
$stmt = $pdo->prepare("
    UPDATE logs 
    SET Status = 'OVERDUE', updated_at = NOW() 
    WHERE Status = 'BORROWED' AND DueDate < NOW()
");
$stmt->execute();

// --- STEP 2: Fetch overdue logs ---
$stmt = $pdo->query("
    SELECT l.*, u.Fname, u.Lname, u.Email, k.Key_Code, k.Location
    FROM logs l
    LEFT JOIN users u ON l.UserID = u.UserID
    LEFT JOIN keys_m k ON l.KeyID = k.KeyID
    WHERE l.Status = 'OVERDUE'
    ORDER BY l.DueDate DESC
");
$overdues = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- STEP 3: Send overdue email notifications using PHPMailer ---
if (count($overdues) > 0) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'adfcsecofficer@gmail.com';   // your Gmail
        $mail->Password   = 'bibd yyzs eenq trry';        // Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->setFrom('adfcsecofficer@gmail.com', 'Security Office');

        $sent = [];

        foreach ($overdues as $o) {
            $email = $o['Email'];
            $fullName = "{$o['Fname']} {$o['Lname']}";
            $keyCode = $o['Key_Code'];
            $location = $o['Location'];
            $due = date('M d, Y h:i A', strtotime($o['DueDate']));

            if (empty($email) || in_array($email, $sent)) continue;

            $mail->clearAddresses();
            $mail->addAddress($email, $fullName);
            $mail->isHTML(true);
            $mail->Subject = "Overdue Key Reminder";
            $mail->Body = "
                <h3>Dear {$fullName},</h3>
                <p>The key <b>{$keyCode}</b> (Location: <b>{$location}</b>) 
                was due on <b>{$due}</b> and is now marked as 
                <span style='color:red;'>OVERDUE</span>.</p>
                <p>Please return it immediately to the Security Officer.</p>
                <br>
                <p>Thank you,<br><b>Admin</b></p>
            ";
            $mail->AltBody = "Dear {$fullName}, the key '{$keyCode}' (Location: {$location}) was due on {$due} and is now OVERDUE. Please return it immediately.";

            $mail->send();

            // ✅ Record notification in DB
            $notifStmt = $pdo->prepare("
                INSERT INTO notifications (Fname, Lname, Email, Message, Status, Date_Sent)
                VALUES (:fname, :lname, :email, :msg, 'SENT', NOW())
            ");
            $notifStmt->execute([
                ':fname' => $o['Fname'],
                ':lname' => $o['Lname'],
                ':email' => $email,
                ':msg' => "Key {$keyCode} (Location: {$location}) overdue since {$due}."
            ]);

            $sent[] = $email;
        }

    } catch (Exception $e) {
        echo "❌ Email error: {$mail->ErrorInfo}";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Overdue Logs</title>
<style>
    :root {
        --bg: #f8f9fa;
        --text: #212529;
        --card-bg: #e9ecef;
        --btn-blue: #17a2b8;
        --btn-blue-dark: #138496;
        --btn-red: #dc3545;
        --table-bg: #ffffff;
        --danger: #dc3545;
    }
    body.dark {
        --bg: #2b2b2b;
        --text: #f8f9fa;
        --card-bg: #3a3a3a;
        --table-bg: #2f2f2f;
    }
    body {
        font-family: Arial, sans-serif;
        background-color: var(--bg);
        color: var(--text);
        margin: 0;
        padding: 40px;
    }
    .container {
        max-width: 1200px;
        margin: auto;
        background-color: var(--card-bg);
        padding: 30px;
        border-radius: 8px;
    }
    h1 {
        font-size: 28px;
        margin-bottom: 20px;
        text-align: center;
        color: var(--text);
    }
    .buttons {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-bottom: 20px;
    }
    .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        color: #fff;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .btn-back { background-color: var(--btn-blue); }
    .btn-back:hover { background-color: var(--btn-blue-dark); }
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: var(--table-bg);
        border-radius: 8px;
        overflow: hidden;
    }
    th, td {
        text-align: center;
        padding: 12px;
        border-bottom: 1px solid #999;
    }
    th {
        background-color: var(--card-bg);
        font-weight: bold;
    }
    .status {
        color: var(--danger);
        font-weight: bold;
    }
    .msg {
        padding: 10px;
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 15px;
    }
   
.table-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-radius: 8px;
    background: var(--table-bg);
    margin-bottom: 20px;
    position: relative;
}

/* Responsive styles */
@media screen and (max-width: 1024px) {
    .container { 
        padding: 20px;
        margin: 10px;
    }

    .buttons {
        margin-bottom: 15px;
    }
}

@media screen and (max-width: 768px) {
    body { 
        padding: 12px; 
    }
    
    .container {
        padding: 16px;
        border-radius: 10px;
    }

    h1 {
        font-size: 20px;
        margin-bottom: 15px;
    }

    /* Table adjustments */
    table {
        min-width: 720px;
    }

    th {
        position: sticky;
        top: 0;
        z-index: 2;
        font-size: 13px;
        white-space: nowrap;
        padding: 10px 8px;
        background: var(--card-bg);
    }

    td {
        font-size: 14px;
        padding: 10px 8px;
        white-space: nowrap;
    }

@media screen and (max-width: 480px) {
    body { 
        padding: 0; 
    }
    
    .container {
        border-radius: 0;
        padding: 12px;
    }

    h1 {
        font-size: 18px;
    }

    .btn {
        padding: 10px 16px;
        font-size: 14px;
    }

    th, td {
        font-size: 13px;
        padding: 8px 6px;
    }

    .msg {
        margin: 10px;
        font-size: 14px;
    }
}
</style>
</head>
<body>
<div class="container">
    <h1>OVERDUE LOGS MANAGEMENT</h1>

    <div class="buttons">
        <button class="btn btn-back" onclick="location.href='../dashboard.php'">BACK</button>
    </div>

    <?php if (count($overdues) > 0): ?>
        <div class="table-wrapper">
    <table>
        <thead>
            <tr>
                <th>KEY CODE</th>
                <th>LOCATION</th>
                <th>USER</th>
                <th>EMAIL</th>
                <th>DUE DATE</th>
                <th>STATUS</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($overdues as $o): ?>
            <tr>
                <td><?= htmlspecialchars($o['Key_Code']) ?></td>
                <td><?= htmlspecialchars($o['Location']) ?></td>
                <td><?= htmlspecialchars("{$o['Fname']} {$o['Lname']}") ?></td>
                <td><?= htmlspecialchars($o['Email']) ?></td>
                <td><?= date('M d, Y h:i A', strtotime($o['DueDate'])) ?></td>
                <td class="status"><?= htmlspecialchars($o['Status']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="msg" style="background:#f8d7da; color:#721c24; border-color:#f5c6cb;">No overdue keys found.</div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') document.body.classList.add('dark');
});
</script>
</body>
</html>
