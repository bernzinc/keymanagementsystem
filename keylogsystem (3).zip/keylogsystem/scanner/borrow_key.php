<?php
require_once '../includes/functions.php';
header('Content-Type: application/json');

$keyCode = $_POST['key_code'] ?? '';
$fullname = $_POST['fullname'] ?? '';

if (!$keyCode || !$fullname) {
    echo json_encode(['success' => false, 'message' => 'Missing data.']);
    exit;
}

$stmt = $pdo->prepare("SELECT KeyID FROM keys_m WHERE Key_Code = ?");
$stmt->execute([$keyCode]);
$key = $stmt->fetch();

if (!$key) {
    echo json_encode(['success' => false, 'message' => 'Key not found.']);
    exit;
}

$parts = explode(' ', trim($fullname));
$fname = $parts[0] ?? '';
$lname = $parts[1] ?? '(Unknown)';

$userStmt = $pdo->prepare("SELECT UserID FROM users WHERE Fname = ? AND Lname = ?");
$userStmt->execute([$fname, $lname]);
$user = $userStmt->fetch();

if (!$user) {
    $insertUser = $pdo->prepare("INSERT INTO users (Fname, Lname) VALUES (?, ?)");
    $insertUser->execute([$fname, $lname]);
    $userId = $pdo->lastInsertId();
} else {
    $userId = $user['UserID'];
}

$insertLog = $pdo->prepare("
    INSERT INTO logs (UserID, KeyID, Date, TimeBorrowed, Status)
    VALUES (?, ?, CURDATE(), CURTIME(), 'Borrowed')
");
$insertLog->execute([$userId, $key['KeyID']]);

echo json_encode(['success' => true, 'message' => 'Key borrowed successfully.']);
?>
