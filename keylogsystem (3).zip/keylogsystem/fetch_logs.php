<?php
require_once 'includes/functions.php';
requireAdmin();
header('Content-Type: application/json');

$stmt = $pdo->query("
    SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) AS FullName, l.Location,
           l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
    FROM logs l
    JOIN users u ON l.UserID = u.UserID
    JOIN keys_m k ON l.KeyID = k.KeyID
    ORDER BY l.LogID DESC
    LIMIT 10
");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>