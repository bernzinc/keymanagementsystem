<?php
require_once '../includes/functions.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: logs.php');
    exit;
}

// Fetch log details
$stmt = $pdo->prepare("SELECT l.*, k.Key_Code, u.Lname, u.Fname 
                       FROM logs l
                       LEFT JOIN keys_m k ON l.KeyID = k.KeyID
                       LEFT JOIN users u ON l.UserID = u.UserID
                       WHERE l.LogID = :id");
$stmt->execute([':id' => $id]);
$log = $stmt->fetch();

if (!$log) {
    echo "<p>Log not found.</p><a href='logs.php'>Back</a>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Log</title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
:root {
    --success: #28a745;
    --borrowed: #17a2b8;
    --overdue: #ffc107;
    --lost: #dc3545;
}
body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    padding: 40px;
    transition: background 0.3s, color 0.3s;
}
.card {
    background-color: var(--card-bg);
    color: var(--text);
    padding: 30px;
    max-width: 600px;
    margin: auto;
    border-radius: 8px;
    text-align: left;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    margin-bottom: 20px;
}
p {
    margin: 10px 0;
    font-size: 16px;
}
.status {
    font-weight: bold;
    text-transform: uppercase;
}
.status.returned { color: var(--success); }
.status.borrowed { color: var(--borrowed); }
.status.overdue { color: var(--overdue); }
.status.lost { color: var(--lost); }

button {
    background-color: var(--btn-blue);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}
button:hover { background-color: var(--btn-blue-dark); }

.qr {
    display: block;
    margin: 15px auto;
    width: 120px;
    height: 120px;
}

/* Toggle */
#toggle-switch {
    width: 45px;
    height: 22px;
    border-radius: 15px;
    background: #ccc;
    position: fixed;
    top: 20px;
    right: 20px;
    cursor: pointer;
}
#toggle-switch div {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: white;
    position: absolute;
    top: 1px;
    left: 1px;
    transition: transform 0.3s;
}
#toggle-switch.active {
    background: #17a2b8;
}
#toggle-switch.active div {
    transform: translateX(23px);
}
</style>
</head>
<body>

<div class="card">
    <h2>Log Details</h2>

    <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($log['Key_Code']) ?>&size=120x120" class="qr" alt="QR Code">

    <p><strong>Log ID:</strong> <?= $log['LogID'] ?></p>
    <p><strong>Key Code:</strong> <?= htmlspecialchars($log['Key_Code']) ?></p>
    <p><strong>User:</strong> <?= htmlspecialchars($log['Lname'] . ', ' . $log['Fname']) ?></p>
    <p><strong>Location:</strong> <?= htmlspecialchars($log['Location']) ?></p>
    <p><strong>Date:</strong> <?= htmlspecialchars(date('M d, Y', strtotime($log['Date']))) ?></p>
    <p><strong>Time Borrowed:</strong> <?= htmlspecialchars($log['TimeBorrowed']) ?></p>
    <p><strong>Time Returned:</strong> <?= htmlspecialchars($log['TimeReturned'] ?? 'Not yet returned') ?></p>
    <p><strong>Status:</strong> <span class="status <?= strtolower($log['Status']) ?>"><?= htmlspecialchars($log['Status']) ?></span></p>

    <div style="text-align:center; margin-top:20px;">
        <button onclick="location.href='logs.php'">Back</button>
    </div>
</div>

<script>
// Dark Mode Toggle
const toggle = document.getElementById('toggle-switch');
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark');
    toggle.classList.add('active');
}
toggle.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    toggle.classList.toggle('active');
    localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
</script>
</body>
</html>
