<?php
require_once '../includes/functions.php';
requireAdmin();

// 🔍 Handle AJAX search
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $search = $_GET['search'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE Lname LIKE :s OR Fname LIKE :s OR Department LIKE :s OR Role LIKE :s OR Email LIKE :s ORDER BY UserID ASC");
    $stmt->execute([':s' => "%$search%"]);
    $users = $stmt->fetchAll();

    foreach ($users as $u) {
        echo "<tr>
            <td>" . strtoupper(htmlspecialchars($u['Lname'])) . "</td>
            <td>" . strtoupper(htmlspecialchars($u['Fname'])) . "</td>
            <td>" . strtoupper(htmlspecialchars($u['Department'])) . "</td>
            <td class='" . (strtolower($u['Role']) === 'instructor' ? 'instructor' : 'staff') . "'>" . strtoupper(htmlspecialchars($u['Role'])) . "</td>
            <td>" . htmlspecialchars($u['Email']) . "</td>
            <td class='actions'>
                <a href='view_user.php?id={$u['UserID']}' class='view' title='View'>&#128065;</a>
                <a href='edit_user.php?id={$u['UserID']}' class='edit' title='Edit'>&#9998;</a>
                <a href='#' class='delete' data-id='{$u['UserID']}' title='Delete'>&#128465;</a>
            </td>
        </tr>";
    }

    if (empty($users)) echo "<tr><td colspan='7'>No users found.</td></tr>";
    exit;
}

// 🗑 Handle delete action
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM `users` WHERE UserID = :id");
    $stmt->execute([':id' => $id]);
    header("Location: users.php?deleted=1");
    exit;
}

// 📋 Initial load
$stmt = $pdo->query("SELECT * FROM `users` ORDER BY UserID ASC");
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management</title>
<style>
:root {
    --bg: #f8f9fa;
    --text: #212529;
    --card-bg: #e9ecef;
    --btn-blue: #17a2b8;
    --btn-blue-dark: #138496;
    --btn-red: #dc3545;
    --table-bg: #ffffff;
    --instructor: #28a745;
    --staff: #ff9800;
}
body.dark {
    --bg: #2b2b2b;
    --text: #f8f9fa;
    --card-bg: #3a3a3a;
    --table-bg: #2f2f2f;
}
body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    margin: 0;
    padding: 40px;
    transition: 0.3s;
}
.container {
    max-width: 1200px;
    margin: auto;
    background-color: var(--card-bg);
    padding: 30px;
    border-radius: 8px;
}
h1 {
    font-size: 28px;
    margin-bottom: 20px;
}
.top-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}
.search-box input {
        width: 300px;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 16px;
    }
.buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
}
.btn-add, .btn-back { background-color: var(--btn-blue); }
.btn-add:hover, .btn-back:hover { background-color: var(--btn-blue-dark); }

table {
    width: 100%;
    border-collapse: collapse;
    background-color: var(--table-bg);
    border-radius: 8px;
    overflow: hidden;
}
th, td {
    text-align: center;
    padding: 12px;
    border-bottom: 1px solid #999;
}
th {
    background-color: var(--card-bg);
    font-weight: bold;
}
.actions a {
    text-decoration: none;
    border-radius: 4px;
    cursor: pointer;
    padding: 6px 8px;
    margin: 0 2px;
    display: inline-block;
}
.view { background-color: #28a745; color: white; }
.edit { background-color: #ffc107; color: white; }
.delete { background-color: var(--btn-red); color: white; }
.instructor { color: var(--instructor); font-weight: bold; }
.staff { color: var(--staff); font-weight: bold; }
.msg {
    padding: 10px;
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    border-radius: 4px;
    margin-bottom: 15px;
}


/* Table wrapper for mobile scroll */
.table-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-radius: 8px;
    background: var(--table-bg);
    margin-bottom: 20px;
}

/* Responsive styles */
@media screen and (max-width: 1024px) {
    .container { padding: 20px; }
    
    .top-controls {
        flex-direction: column;
        gap: 12px;
        align-items: stretch;
    }

    .search-box {
        width: 100%;
    }

    .search-box input {
        width: 100%;
        box-sizing: border-box;
    }

    .buttons {
        flex-direction: row;
        justify-content: space-between;
        gap: 10px;
    }

    .btn {
        flex: 1;
        text-align: center;
    }
}

@media screen and (max-width: 768px) {
    body { padding: 12px; }
    
    .container {
        padding: 16px;
        border-radius: 10px;
    }

    h1 {
        font-size: 20px;
        text-align: center;
        margin-bottom: 15px;
    }

    .search-box input {
        padding: 12px;
        font-size: 16px;
        height: 46px;
    }

    /* Table adjustments */
    table {
        min-width: 680px;
    }

    th {
        position: sticky;
        top: 0;
        z-index: 2;
        font-size: 13px;
        white-space: nowrap;
    }

    td {
        font-size: 14px;
        padding: 10px 8px;
        white-space: nowrap;
    }

    .actions a {
        padding: 8px 10px;
        margin: 0 4px;
        min-width: 32px;
        min-height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
}

@media screen and (max-width: 480px) {
    body { padding: 0; }
    
    .container {
        border-radius: 0;
        padding: 12px;
    }

    .buttons {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        padding: 12px;
        font-size: 15px;
    }

    th, td {
        font-size: 13px;
        padding: 8px 6px;
    }

    /* Scroll indicator */
    .table-wrapper::after {
        content: '← Scroll →';
        position: absolute;
        bottom: 8px;
        right: 8px;
        background: rgba(0,0,0,0.5);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        opacity: 0.8;
    }
}
</style>
</head>
<body>
<div class="container">
    <h1>KEY USERS MANAGEMENT</h1>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="msg">User deleted successfully.</div>
    <?php endif; ?>

    <div class="top-controls">
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search by Lname, Fname, Department, Role or Email">
        </div>
        <div class="buttons">
            <button class="btn btn-add" onclick="location.href='add_user.php'">+ ADD USER</button>
            <button class="btn btn-back" onclick="location.href='../dashboard.php'">BACK</button>
        </div>
    </div>
<div class="table-wrapper">
    <table>
        <thead>
            <tr>
                <th>LNAME</th>
                <th>FNAME</th>
                <th>DEPARTMENT</th>
                <th>ROLE</th>
                <th>EMAIL</th>
                <th>ACTIONS</th>
            </tr>
        </thead>
        <tbody id="tableBody">
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= strtoupper(htmlspecialchars($u['Lname'])) ?></td>
                <td><?= strtoupper(htmlspecialchars($u['Fname'])) ?></td>
                <td><?= strtoupper(htmlspecialchars($u['Department'])) ?></td>
                <td class="<?= strtolower($u['Role']) === 'instructor' ? 'instructor' : 'staff' ?>">
                    <?= strtoupper(htmlspecialchars($u['Role'])) ?>
                </td>
                <td><?= htmlspecialchars($u['Email']) ?></td>
                <td class="actions">
                    <a href="view_user.php?id=<?= $u['UserID'] ?>" class="view" title="View">&#128065;</a>
                    <a href="edit_user.php?id=<?= $u['UserID'] ?>" class="edit" title="Edit">&#9998;</a>
                    <a href="#" class="delete" data-id="<?= $u['UserID'] ?>" title="Delete">&#128465;</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Live search identical to keys
let typingTimer;
const searchInput = document.getElementById('searchInput');
const tableBody = document.getElementById('tableBody');

searchInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const search = searchInput.value;
        fetch(`users.php?ajax=1&search=${encodeURIComponent(search)}`)
            .then(res => res.text())
            .then(data => tableBody.innerHTML = data);
    }, 300);
});

// SweetAlert delete

document.addEventListener('click', function(e) {
    if (e.target.closest('.delete')) {
        e.preventDefault();
        const id = e.target.closest('.delete').dataset.id;

        Swal.fire({
            icon: 'error',
            title: 'Delete',
            text: 'Are you sure you want to delete this user?',
            showCancelButton: true,
            
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#e74c3c',
            cancelButtonColor: '#dcdcdc',
            background: '#fff',
            color: '#333',
            width: '320px',
            padding: '1em',
            borderRadius: '12px',
            customClass: {
                popup: 'modern-alert',
                icon: 'modern-icon',
                title: 'modern-title',
                cancelButton: 'modern-cancel',
                confirmButton: 'modern-confirm'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'users.php?delete=' + id;
            }
        });
    }
});
</script>

<style>
/* 🔹 Compact Modern SweetAlert Style */
.swal2-popup.modern-alert {
    border-radius: 12px !important;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    font-family: 'Inter', sans-serif;
    font-size: 14px !important;
    position: relative;
}

/* Smaller, modern close “X” */

.swal2-close.modern-close:hover {
    background: #ebebeb !important;
    color: #555 !important;
}

.swal2-icon.modern-icon {
    border: none !important;
    background-color: rgba(231,76,60,0.08) !important;
    color: #e74c3c !important;
    width: 60px !important;
    height: 60px !important;
}

.swal2-title.modern-title {
    font-size: 18px !important;
    font-weight: 600;
    margin-top: 8px !important;
}

.swal2-actions .modern-cancel {
    background: #f1f1f1 !important;
    color: #333 !important;
    font-weight: 500 !important;
    border-radius: 6px !important;
    padding: 6px 14px !important;
    font-size: 13px !important;
}
.swal2-actions .modern-cancel:hover {
    background: #e0e0e0 !important;
}

.swal2-actions .modern-confirm {
    background: #e74c3c !important;
    color: #fff !important;
    font-weight: 500 !important;
    border-radius: 6px !important;
    padding: 6px 14px !important;
    font-size: 13px !important;
}
.swal2-actions .modern-confirm:hover {
    background: #c0392b !important;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') document.body.classList.add('dark');
});
</script>
</body>
</html>
