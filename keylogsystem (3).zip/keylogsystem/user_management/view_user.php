<?php
require_once '../includes/functions.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: users.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE UserID = :id");
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();

if (!$user) {
    echo "<p>User not found.</p><a href='users.php'>Back</a>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View User</title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    padding: 40px;
    transition: background 0.3s, color 0.3s;
}
.card {
    background-color: var(--card-bg);
    padding: 30px;
    max-width: 450px;
    margin: auto;
    border-radius: 8px;
    text-align: left;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
h2 { text-align: center; }
p { margin: 10px 0; font-size: 16px; }
button {
    background-color: var(--btn-blue);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    display: inline-block;
}
button:hover { background-color: var(--btn-blue-dark); }
</style>
</head>
<body>
<div class="card">
    <h2>User Details</h2>
    <p><strong>User ID:</strong> <?= $user['UserID'] ?></p>
    <p><strong>Last Name:</strong> <?= htmlspecialchars($user['Lname']) ?></p>
    <p><strong>First Name:</strong> <?= htmlspecialchars($user['Fname']) ?></p>
    <p><strong>Department:</strong> <?= htmlspecialchars($user['Department']) ?></p>
    <p><strong>Role:</strong> <?= htmlspecialchars($user['Role']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['Email']) ?></p>
    <div style="text-align:center; margin-top:15px;">
        <button onclick="location.href='edit_user.php?id=<?= $user['UserID'] ?>'">Edit</button>
        <button onclick="location.href='users.php'">Back</button>
    </div>
</div>
<script src="../assets/theme.js"></script>
</body>
</html>
