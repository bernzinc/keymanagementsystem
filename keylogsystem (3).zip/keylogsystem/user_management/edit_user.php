<?php
require_once '../includes/functions.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: users.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE UserID = :id");
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();

if (!$user) {
    echo "<p>User not found.</p><a href='users.php'>Back</a>";
    exit;
}

$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lname = $_POST['Lname'];
    $fname = $_POST['Fname'];
    $dept = $_POST['Department'];
    $role = $_POST['Role'];
    $email = $_POST['Email'];

    $stmt = $pdo->prepare("UPDATE users 
                           SET Lname=:l, Fname=:f, Department=:d, Role=:r, Email=:e, updated_at=NOW() 
                           WHERE UserID=:id");
    $stmt->execute([
        ':l' => $lname,
        ':f' => $fname,
        ':d' => $dept,
        ':r' => $role,
        ':e' => $email,
        ':id' => $id
    ]);

    $msg = "✅ User updated successfully!";
    $stmt = $pdo->prepare("SELECT * FROM users WHERE UserID = :id");
    $stmt->execute([':id' => $id]);
    $user = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit User</title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    padding: 40px;
    transition: background 0.3s, color 0.3s;
}
.form-container {
    background-color: var(--card-bg);
    padding: 30px;
    max-width: 500px;
    margin: auto;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
input, select {
    width: 100%;
    padding: 12px 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 15px;
    background-color: var(--table-bg);
    color: var(--text);
    box-sizing: border-box;
    display: block;
    height: 45px; /* ensures consistent height */
}

select {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%23aaa' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 10px center;
    background-size: 10px 6px;
    padding-right: 30px;
}
button {
    background-color: var(--btn-blue);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}
button:hover {
    background-color: var(--btn-blue-dark);
}
.msg {
    background: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 10px;
    text-align: center;
}
</style>
</head>
<body>
<div class="form-container">
    <h2>Edit User</h2>
    <?php if ($msg): ?><div class="msg"><?= $msg ?></div><?php endif; ?>

    <form method="POST">
        <label>Last Name:</label>
        <input type="text" name="Lname" value="<?= htmlspecialchars($user['Lname']) ?>" required>

        <label>First Name:</label>
        <input type="text" name="Fname" value="<?= htmlspecialchars($user['Fname']) ?>" required>

        <label>Department:</label>
        <input type="text" name="Department" value="<?= htmlspecialchars($user['Department']) ?>" required>

        <label>Role:</label>
        <select name="Role">
            <option value="Instructor" <?= $user['Role'] == 'Instructor' ? 'selected' : '' ?>>Instructor</option>
            <option value="Staff" <?= $user['Role'] == 'Staff' ? 'selected' : '' ?>>Staff</option>
        </select>

        <label>Email:</label>
        <input type="email" name="Email" value="<?= htmlspecialchars($user['Email']) ?>" required>

        <button type="submit">Save Changes</button>
        <button type="button" onclick="location.href='users.php'">Back</button>
    </form>
</div>
<script src="../assets/theme.js"></script>
</body>
</html>
