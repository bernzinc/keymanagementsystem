<?php
require_once '../includes/functions.php';
requireAdmin();

$msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lname = $_POST['Lname'];
    $fname = $_POST['Fname'];
    $dept = $_POST['Department'];
    $role = $_POST['Role'];
    $email = $_POST['Email'];

    $stmt = $pdo->prepare("INSERT INTO users (Lname, Fname, Department, Role, Email, created_at, updated_at) 
                           VALUES (:l, :f, :d, :r, :e, NOW(), NOW())");
    $stmt->execute([
        ':l' => $lname,
        ':f' => $fname,
        ':d' => $dept,
        ':r' => $role,
        ':e' => $email
    ]);

    $msg = "✅ User added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add User</title>
<link rel="stylesheet" href="../assets/theme.css">
<style>
body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    padding: 40px;
    transition: background 0.3s, color 0.3s;
}
.form-container {
    background-color: var(--card-bg);
    padding: 30px;
    max-width: 500px;
    margin: auto;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
input, select {
            width: 100%;
            padding: 12px 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 15px;
            background-color: var(--table-bg);
            color: var(--text);
            box-sizing: border-box;
            display: block;
            height: 45px;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%23aaa' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 10px 6px;
            padding-right: 30px;
        }
button {
    background-color: var(--btn-blue);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}
button:hover {
    background-color: var(--btn-blue-dark);
}
.msg {
    background: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 10px;
    text-align: center;
}
#toggle-switch {
    width: 45px;
    height: 22px;
    border-radius: 15px;
    background: #ccc;
    position: fixed;
    top: 20px;
    right: 20px;
    cursor: pointer;
}
#toggle-switch div {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: white;
    position: absolute;
    top: 1px;
    left: 1px;
    transition: transform 0.3s;
}
#toggle-switch.active {
    background: #17a2b8;
}
#toggle-switch.active div {
    transform: translateX(23px);
}
</style>
</head>
<body>

<div class="form-container">
    <h2>Add User</h2>
    <?php if ($msg): ?><div class="msg"><?= $msg ?></div><?php endif; ?>
    <form method="POST">
        <label>Last Name:</label>
        <input type="text" name="Lname" required>

        <label>First Name:</label>
        <input type="text" name="Fname" required>

        <label>Department:</label>
        <input type="text" name="Department" required>

        <label>Role:</label>
        <select name="Role" required>
            <option value="Instructor">Instructor</option>
            <option value="Staff">Staff</option>
        </select>

        <label>Email:</label>
        <input type="email" name="Email" required>

        <button type="submit">Save User</button>
        <button type="button" onclick="location.href='users.php'">Back</button>
    </form>
</div>

<script src="../assets/theme.js"></script>
</body>
</html>
