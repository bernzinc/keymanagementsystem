<?php
require_once 'includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

// --- AUTO CHECK OVERDUE KEYS ---
$today = date('Y-m-d H:i:s');
$sql = "
    SELECT l.LogID, l.UserID, u.Email, u.Lname, u.Fname, k.Key_Code, k.Room_ID, l.DueDate
    FROM logs l
    JOIN users u ON l.UserID = u.UserID
    JOIN keys_m k ON l.KeyID = k.KeyID
    WHERE l.Status != 'Returned'
      AND l.DueDate IS NOT NULL
      AND l.DueDate < ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$today]);
$overdueLogs = $stmt->fetchAll();

foreach ($overdueLogs as $log) {
    $update = $pdo->prepare("UPDATE logs SET Status = 'Overdue' WHERE LogID = ?");
    $update->execute([$log['LogID']]);
}

// --- FETCH TOTALS ---
$total_keys = $pdo->query("SELECT COUNT(*) FROM keys_m")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_logs = $pdo->query("SELECT COUNT(*) FROM logs")->fetchColumn();
$total_overdue = $pdo->query("SELECT COUNT(*) FROM logs WHERE Status='Overdue'")->fetchColumn();
$total_lost = $pdo->query("SELECT COUNT(*) FROM lost_keys")->fetchColumn();

// --- FETCH RECENT LOGS ---
$logs = $pdo->query("
    SELECT k.Key_Code, CONCAT(u.Fname, ' ', u.Lname) AS FullName, l.Location,
           l.Date, l.TimeBorrowed, l.TimeReturned, l.Status
    FROM logs l
    JOIN users u ON l.UserID = u.UserID
    JOIN keys_m k ON l.KeyID = k.KeyID
    ORDER BY l.LogID DESC
    LIMIT 10
")->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Dashboard</title>
<style>
:root {
    --bg: #f8f9fa;
    --text: #212529;
    --card-bg: #A3A1A1;
    --sidebar-bg: #D9D9D9;
    --sidebar-btn: #17a2b8;
    --logout-btn: #dc3545;
    --table-bg: #fff;
}
body.dark {
    --bg: #2b2b2b;
    --text: #f8f9fa;
    --card-bg: #3a3a3a;
    --sidebar-bg: #1f1f1f;
    --sidebar-btn: #0dcaf0;
    --logout-btn: #ff4d4d;
    --table-bg: #2f2f2f;
}
* { box-sizing: border-box; font-family: Arial, sans-serif; }
body {
    margin: 0;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    height: 100vh;
}
.sidebar {
    width: 220px;
    background-color: var(--sidebar-bg);
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.sidebar .logo {
    width: 105px;
    height: 105px;
    margin: 10px auto 40px;
}
.sidebar .logo img {
    width: 100%;
    height: auto;
    border-radius: 50%;
}
.sidebar button {
    width: 100%;
    margin-bottom: 10px;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: var(--sidebar-btn);
    color: white;
    font-weight: bold;
    cursor: pointer;
}
.sidebar button:hover { background-color: #138496; }
.logout-btn { background-color: var(--logout-btn) !important; margin-top: auto; }
.content { flex-grow: 1; padding: 20px 40px; overflow-y: auto; }
.topbar { display: flex; justify-content: flex-end; align-items: center; margin-bottom: 20px; }
.toggle-container { display: flex; align-items: center; gap: 10px; }
.switch {
    position: relative;
    width: 50px; height: 24px;
    background-color: #ccc;
    border-radius: 24px;
    cursor: pointer;
}
.switch::after {
    content: ''; position: absolute;
    top: 2px; left: 2px;
    width: 20px; height: 20px;
    border-radius: 50%;
    background-color: white;
    transition: transform 0.3s;
}
.switch.active { background-color: #17a2b8; }
.switch.active::after { transform: translateX(26px); }
.admin-btn {
    background-color: var(--sidebar-btn);
    color: white;
    border: none;
    border-radius: 20px;
    padding: 6px 14px;
    font-weight: bold;
}
.cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}
.card {
    background-color: var(--card-bg);
    border-radius: 8px;
    text-align: center;
    padding: 30px 10px;
    font-weight: bold;
    font-size: 18px;
}
.card span { display: block; font-size: 28px; margin-top: 8px; }
.logs-table {
    background-color: var(--table-bg);
    margin-top: 30px;
    border-radius: 8px;
    overflow: hidden;
}
table { width: 100%; border-collapse: collapse; }
th, td { padding: 12px; text-align: center; border-bottom: 1px solid #999; }
th { background-color: var(--card-bg); font-size: 15px; }
td { font-size: 14px; }
.status-overdue { color: #dc3545; font-weight: bold; }
.status-success { color: #28a745; font-weight: bold; }

/* Mobile Responsive Styles */
@media screen and (max-width: 768px) {
    body {
        flex-direction: column;
        height: auto;
    }

    .sidebar {
        width: 100%;
        padding: 10px;
    }

    .sidebar .logo {
        width: 80px;
        height: 80px;
        margin: 5px auto 20px;
    }

    .content {
        padding: 10px;
    }

    .cards {
        grid-template-columns: 1fr;
        gap: 10px;
    }

    .card {
        padding: 15px 10px;
        font-size: 16px;
    }

    .card span {
        font-size: 24px;
    }

    .logs-table {
        overflow-x: auto;
    }

    table {
        font-size: 14px;
    }

    th, td {
        padding: 8px;
        min-width: 100px;
    }

    .topbar {
        flex-direction: column;
        gap: 10px;
        align-items: flex-end;
    }

    #qr-reader {
        width: 100% !important;
        max-width: 300px;
    }

    /* Improve button touch targets */
    .sidebar button {
        padding: 12px;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .admin-btn {
        padding: 8px 16px;
    }

    /* Adjust switch size */
    .switch {
        width: 44px;
        height: 22px;
    }

    .switch::after {
        width: 18px;
        height: 18px;
    }

    .switch.active::after {
        transform: translateX(22px);
    }
}

/* Small phones */
@media screen and (max-width: 480px) {
    .sidebar button {
        font-size: 12px;
        padding: 10px;
    }

    .card {
        font-size: 14px;
    }

    .card span {
        font-size: 20px;
    }

    th, td {
        padding: 6px;
        font-size: 12px;
        min-width: 80px;
    }
}

/* Add to your existing CSS */
.hamburger-menu {
    display: none;
    cursor: pointer;
    padding: 15px;
    position: fixed;
    top: 10px;
    left: 10px;
    z-index: 1000;
    background: var(--sidebar-bg);
    border-radius: 5px;
}

.bar {
    width: 25px;
    height: 3px;
    background: var(--text);
    margin: 5px 0;
    transition: 0.4s;
}

.close-menu {
    display: none;
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 30px;
    cursor: pointer;
    color: var(--text);
}

/* Update mobile styles */
@media screen and (max-width: 768px) {
    .hamburger-menu {
        display: block;
    }

    .sidebar {
        position: fixed;
        left: -100%;
        top: 0;
        height: 100%;
        z-index: 999;
        transition: 0.3s;
        box-shadow: 2px 0 5px rgba(0,0,0,0.2);
    }

    .sidebar.active {
        left: 0;
    }

    .close-menu {
        display: block;
    }

    .content {
        margin-left: 0;
        padding-top: 60px;
    }

    /* Animate hamburger to X */
    .hamburger-menu.active .bar:nth-child(1) {
        transform: rotate(-45deg) translate(-5px, 6px);
    }

    .hamburger-menu.active .bar:nth-child(2) {
        opacity: 0;
    }

    .hamburger-menu.active .bar:nth-child(3) {
        transform: rotate(45deg) translate(-5px, -6px);
    }
}

/* Add to your existing CSS */
.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 998;
}

.sidebar-overlay.active {
    display: block;
}

body.no-scroll {
    overflow: hidden;
}

</style>
</head>
<body>
<div class="hamburger-menu">
    <div class="bar"></div>
    <div class="bar"></div>
    <div class="bar"></div>
</div>
<div class="sidebar" id="sidebar">
    <div class="logo"><img src="images/logo.png" alt="Logo"></div>
    <button onclick="location.href='scanner/scanner.php'">MANUAL SCANNING</button>
    <button onclick="location.href='key_management/keys.php'">KEYS</button>
    <button onclick="location.href='user_management/users.php'">KEY USERS</button>
    <button onclick="location.href='keylogs_management/logs.php'">KEY LOGS</button>
    <button onclick="location.href='scanner/update_overdue.php'">OVERDUE LOGS</button>
    <button onclick="location.href='lost_key/lost_key.php'">LOST KEYS</button>
    <button onclick="location.href='report_generation/reports.php'">REPORTS</button>
    <button id="logoutBtn" class="btn logout-btn">LOGOUT</button>
</div>

<div class="content">
    <div class="topbar">
        <div class="toggle-container">
            <div class="switch" id="toggle-switch"></div>
            <button class="admin-btn">ADMIN</button>
        </div>
    </div>

    <div class="cards">
        <div class="card">TOTAL KEYS <span><?= $total_keys ?></span></div>
        <div class="card">TOTAL USERS <span><?= $total_users ?></span></div>
        <div class="card">TOTAL KEY LOGS <span><?= $total_logs ?></span></div>
        <div class="card">TOTAL OVERDUE KEYS <span><?= $total_overdue ?></span></div>
        <div class="card">
            <h3>QR KEY SCANNER</h3>
            <div id="qr-reader" style="width: 300px; margin: auto;"></div>
            <p id="scan-result" style="margin-top: 10px; font-size: 14px;"></p>
        </div>
        <div class="card">TOTAL LOST KEYS <span><?= $total_lost ?></span></div>
    </div>

    <div class="logs-table">
        <h2 style="text-align:center; padding-top:10px;">KEY LOGS</h2>
        <table>
            <thead>
                <tr>
                    <th>KEY_CODE</th>
                    <th>USER</th>
                    <th>LOCATION</th>
                    <th>DATE</th>
                    <th>TIMEBORROWED</th>
                    <th>TIMERETURNED</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars($log['Key_Code']) ?></td>
                    <td><?= strtoupper(htmlspecialchars($log['FullName'])) ?></td>
                    <td><?= htmlspecialchars($log['Location']) ?></td>
                    <td><?= htmlspecialchars($log['Date']) ?></td>
                    <td><?= htmlspecialchars($log['TimeBorrowed']) ?></td>
                    <td><?= htmlspecialchars($log['TimeReturned'] ?? '-') ?></td>
                    <td class="<?php
                        echo ($log['Status'] == 'Overdue') ? 'status-overdue' :
                            (($log['Status'] == 'Returned') ? 'status-success' : '');
                    ?>">
                        <?= htmlspecialchars($log['Status']) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>

    // Add this to your existing script section
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger-menu');
    const sidebar = document.getElementById('sidebar');
    const closeMenu = document.querySelector('.close-menu');
    const overlay = document.createElement('div');
    
    overlay.classList.add('sidebar-overlay');
    document.body.appendChild(overlay);

    function toggleMenu() {
        hamburger.classList.toggle('active');
        sidebar.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
        overlay.classList.toggle('active');
    }

    hamburger.addEventListener('click', toggleMenu);
    closeMenu.addEventListener('click', toggleMenu);
    overlay.addEventListener('click', toggleMenu);

    // Close menu when clicking a sidebar button
    sidebar.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                toggleMenu();
            }
        });
    });
});
// ---- THEME TOGGLE ----
const toggle = document.getElementById('toggle-switch');
const body = document.body;
if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark');
    toggle.classList.add('active');
}
toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
    body.classList.toggle('dark');
    localStorage.setItem('theme', body.classList.contains('dark') ? 'dark' : 'light');
});

// ---- QR SCANNER ----
const qrReader = new Html5Qrcode("qr-reader");

function startScanner() {
    qrReader.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: 250 },
        qrCodeMessage => {
            document.getElementById('scan-result').innerText = "Scanned: " + qrCodeMessage;
            qrReader.stop();

            // 🔹 Fetch user list dynamically
            fetch('fetch_usernames.php')
                .then(res => res.json())
                .then(usernames => {
                    const dataList = document.createElement('datalist');
                    dataList.id = 'usernamesList';
                    usernames.forEach(name => {
                        const option = document.createElement('option');
                        option.value = name;
                        dataList.appendChild(option);
                    });
                    document.body.appendChild(dataList);

                    Swal.fire({
                        title: "Scan Result",
                        text: "Key Code: " + qrCodeMessage,
                        html: `
                            <input list="usernamesList" id="fullnameInput" class="swal2-input" placeholder="Type or select full name">
                        `,
                        showCancelButton: true,
                        confirmButtonText: "Submit",
                        preConfirm: () => {
                            const fullname = document.getElementById('fullnameInput').value.trim();
                            if (!fullname) Swal.showValidationMessage("Please enter full name");
                            return fullname;
                        }
                    }).then(result => {
                        if (result.isConfirmed) processScan(qrCodeMessage, result.value);
                        else startScanner();
                    });
                });
        }
    ).catch(err => {
        document.getElementById('scan-result').innerText = "Turn on camera permission.";
    });
}

function processScan(keyCode, fullname) {
    fetch('scanner/borrow_return_key.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `key_code=${encodeURIComponent(keyCode)}&fullname=${encodeURIComponent(fullname)}`
    })
    .then(res => res.json())
    .then(data => {
        Swal.fire({
            icon: data.success ? "success" : "error",
            title: data.message
        }).then(() => {
            updateLogsTable();
            startScanner();
        });
    })
    .catch(() => {
        Swal.fire("Error", "Request failed.", "error");
        startScanner();
    });
}

// 🔹 Refresh logs dynamically
function updateLogsTable() {
    fetch('fetch_logs.php')
    .then(res => res.json())
    .then(logs => {
        const tbody = document.querySelector('.logs-table tbody');
        tbody.innerHTML = '';
        logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${log.Key_Code}</td>
                <td>${log.FullName.toUpperCase()}</td>
                <td>${log.Location}</td>
                <td>${log.Date}</td>
                <td>${log.TimeBorrowed}</td>
                <td>${log.TimeReturned ?? '-'}</td>
                <td class="${
                    log.Status === 'Overdue' ? 'status-overdue' :
                    log.Status === 'Returned' ? 'status-success' : ''
                }">${log.Status}</td>
            `;
            tbody.appendChild(tr);
        });
    });
}

startScanner();

// ---- LOGOUT ----
document.getElementById('logoutBtn').addEventListener('click', function () {
    Swal.fire({
        title: 'Are you sure you want to logout?',
        text: "You’ll be redirected to the login page.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#17a2b8',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Logout',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) window.location.href = 'logout.php';
    });
});
</script>
</body>
</html>
