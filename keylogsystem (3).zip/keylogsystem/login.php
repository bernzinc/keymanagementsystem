<?php
require_once __DIR__ . '../includes/functions.php';
if (isAdmin()) {
    header('Location: dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['username'] ?? '';   // using "username" field from form
    $password = $_POST['password'] ?? '';

    // You can log in by Email or Username if needed
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE Email = :e LIMIT 1");
    $stmt->execute([':e' => $email]);
    $admin = $stmt->fetch();

    if ($admin) {
        $valid = false;
        // Check hashed password
        if (password_verify($password, $admin['Password'])) {
            $valid = true;
        } elseif ($admin['Password'] === $password) {
            // if plain text, rehash it
            $valid = true;
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE admins SET Password = :p WHERE AdminID = :id")
                ->execute([':p' => $hash, ':id' => $admin['AdminID']]);
        }

        if ($valid) {
            $_SESSION['admin_id'] = $admin['AdminID'];
            $_SESSION['admin_name'] = $admin['Fname'] . ' ' . $admin['Lname'];
            header('Location: dashboard.php');
            exit;
        }
    }
    $error = "Invalid username or password.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #6c757d;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }

        .logo-container {
            margin-bottom: 20px;
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #007bff;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
            border: 2px solid #007bff;
            position: relative;
        }

        .logo img {
            width: 100px;
            height: 100px;
        }

        .logo::before {
            content: '';
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            border: 1px dashed #ced4da;
            border-radius: 50%;
        }

        h2 {
            margin-bottom: 30px;
            color: #343a40;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input {
            width: calc(100% - 20px);
            padding: 12px 10px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 16px;
        }

        .form-group input::placeholder {
            color: #6c757d;
        }

        .login-button {
            width: 100%;
            padding: 12px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-button:hover {
            background-color: #138496;
        }

        .error {
            color: #dc3545;
            background: #f8d7da;
            border: 1px solid #f5c2c7;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

    /* Responsive tweaks (keeps original design on desktop) */
    @media screen and (max-width: 768px) {
        body { padding: 12px; align-items: flex-start; }

        .login-container {
            padding: 28px;
            max-width: 460px;
            width: 100%;
            box-sizing: border-box;
        }

        .logo { width: 72px; height: 72px; border-width: 2px; }
        .logo img { width: 60%; height: 60%; object-fit: contain; }

        h2 { font-size: 20px; margin-bottom: 18px; }

        .form-group input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            box-sizing: border-box;
        }

        .login-button {
            padding: 12px;
            font-size: 16px;
        }
    }

    @media screen and (max-width: 420px) {
        body { padding-top: 30px; padding-bottom: 30px; align-items: flex-start; }

        .login-container {
            padding: 18px;
            max-width: 360px;
            border-radius: 8px;
        }

        .logo { width: 64px; height: 64px; }
        .logo img { width: 80px; height: 80px; }

        .logo::before {
            top: -6px; left: -6px; right: -6px; bottom: -6px;
        }

        h2 { font-size: 18px; margin-bottom: 12px; }

        .form-group input {
            padding: 11px;
            font-size: 15px;
            height: 44px; /* better touch target */
        }

        .login-button {
            padding: 12px;
            font-size: 15px;
            border-radius: 6px;
        }
    }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <div class="logo">
                <img src="images/logo.png" alt="QR Code Logo">
            </div>
        </div>
        <h2>QRCode-based Key Log System</h2>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username (Email)" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="login-button">LOGIN</button>
        </form>
    </div>
</body>
</html>
