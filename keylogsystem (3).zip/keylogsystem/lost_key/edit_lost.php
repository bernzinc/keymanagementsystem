<?php
require_once '../includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

$id = (int) $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM lost_keys WHERE LostID = :id");
$stmt->execute([':id' => $id]);
$lost = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$lost) {
    die("Record not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE lost_keys 
                           SET Fname = :fname, Lname = :lname, Email = :email,
                               Key_Code = :key_code, Location = :location, Remarks = :remarks, 
                               Status = :status, updated_at = NOW()
                           WHERE LostID = :id");
    $stmt->execute([
        ':fname' => $_POST['fname'],
        ':lname' => $_POST['lname'],
        ':email' => $_POST['email'],
        ':key_code' => $_POST['key_code'],
        ':location' => $_POST['location'],
        ':remarks' => $_POST['remarks'],
        ':status' => $_POST['status'],
        ':id' => $id
    ]);
    header("Location: lost_key.php?edited=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light"> <!-- JS toggles this -->

<head>
    <meta charset="UTF-8">
    <title>Edit Lost Key</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/theme.css">

    <style>
        body {
            background-color: var(--bg);
            color: var(--text);
            font-family: Arial, sans-serif;
            transition: background-color 0.3s, color 0.3s;
            padding: 40px;
        }

        .container {
            background-color: var(--card-bg);
            color: var(--text);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            max-width: 800px;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
        }

        input,
        select {
            width: 100%;
            padding: 12px 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 15px;
            background-color: var(--table-bg);
            color: var(--text);
            box-sizing: border-box;
            display: block;
            height: 45px;
            /* ensures consistent height */
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%23aaa' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 10px 6px;
            padding-right: 30px;
        }

        .btn-primary {
            background-color: var(--btn-blue);
            border: none;
            padding: 10px 20px;
            font-weight: bold;
            border-radius: 6px;
        }

        .btn-primary:hover {
            background-color: var(--btn-blue-dark);
        }

        .btn-secondary {
            background-color: #6c757d;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
        }

        h3 {
            color: var(--text);
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    

    <div class="container">
        <h3>Edit Lost Key</h3>
        <form method="POST" class="mt-3">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>First Name</label>
                    <input type="text" name="fname" value="<?= htmlspecialchars($lost['Fname']) ?>" required>
                </div>
                <div class="col-md-6">
                    <label>Last Name</label>
                    <input type="text" name="lname" value="<?= htmlspecialchars($lost['Lname']) ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($lost['Email']) ?>" required>
            </div>

            <div class="mb-3">
                <label>Key Code</label>
                <input type="text" name="key_code" value="<?= htmlspecialchars($lost['Key_Code']) ?>" required>
            </div>

            <div class="mb-3">
                <label>Location</label>
                <input type="text" name="location" value="<?= htmlspecialchars($lost['Location']) ?>" required>
            </div>

            <div class="mb-3">
                <label>Remarks</label>
                <textarea name="remarks" rows="3"><?= htmlspecialchars($lost['Remarks']) ?></textarea>
            </div>

            <div class="mb-3">
                <label>Status</label>
                <select name="status">
                    <option <?= $lost['Status'] == 'REPORTED' ? 'selected' : '' ?>>REPORTED</option>
                    <option <?= $lost['Status'] == 'FOUND' ? 'selected' : '' ?>>FOUND</option>
                    <option <?= $lost['Status'] == 'REPLACED' ? 'selected' : '' ?>>REPLACED</option>
                </select>
            </div>

            <button class="btn btn-primary">Update</button>
            <a href="lost_key.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <script src="../assets/theme.js"></script>
    <script>
        document.getElementById('themeToggle').addEventListener('click', () => {
            document.body.dataset.theme = document.body.dataset.theme === 'dark' ? 'light' : 'dark';
            localStorage.setItem('theme', document.body.dataset.theme);
        });
    </script>

</body>

</html>