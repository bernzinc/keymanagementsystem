<?php
require_once '../includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

// ✅ Delete lost key record
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM lost_keys WHERE LostID = :id");
    $stmt->execute([':id' => $id]);
    header("Location: lost_key.php?deleted=1");
    exit;
}

// ✅ Update status
if (isset($_GET['update']) && isset($_GET['status'])) {
    $id = (int)$_GET['update'];
    $status = $_GET['status'];
    $stmt = $pdo->prepare("UPDATE lost_keys SET Status = :status, updated_at = NOW() WHERE LostID = :id");
    $stmt->execute([':status' => $status, ':id' => $id]);
    header("Location: lost_key.php?updated=1");
    exit;
}

// ✅ AJAX live search
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
    $search = $_GET['search'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM lost_keys 
                           WHERE Fname LIKE :s OR Lname LIKE :s OR Email LIKE :s OR Key_Code LIKE :s OR Status LIKE :s
                           ORDER BY LostID DESC");
    $stmt->execute([':s' => "%$search%"]);
    $lostKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($lostKeys as $row) {
        echo "<tr>
            <td>" . htmlspecialchars($row['Fname'] . ' ' . $row['Lname']) . "</td>
            <td>" . htmlspecialchars($row['Email']) . "</td>
            <td>" . htmlspecialchars($row['Key_Code']) . "</td>
            <td>" . htmlspecialchars($row['Location']) . "</td>
            <td>" . htmlspecialchars($row['Remarks']) . "</td>
            <td class='status " . strtolower($row['Status']) . "'>" . strtoupper($row['Status']) . "</td>
            <td>" . date('m-d-Y', strtotime($row['Date_Reported'])) . "</td>
            <td class='actions'>
                <a href='edit_lost_key.php?id={$row['LostID']}' class='edit' title='Edit'>&#9998;</a>
                <a href='lost_key.php?update={$row['LostID']}&status=FOUND' class='view' title='Mark Found'>&#10004;</a>
                <a href='lost_key.php?update={$row['LostID']}&status=REPLACED' class='replace' title='Mark Replaced'>&#9851;</a>
                <a href='#' class='delete' data-id='{$row['LostID']}' title='Delete'>&#128465;</a>
            </td>
        </tr>";
    }

    if (empty($lostKeys)) echo "<tr><td colspan='9'>No lost key records found.</td></tr>";
    exit;
}

// ✅ Fetch all records for page load
$stmt = $pdo->query("SELECT * FROM lost_keys ORDER BY LostID DESC");
$lostKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lost Key Management</title>
<style>
    :root {
        --bg: #f8f9fa;
        --text: #212529;
        --card-bg: #e9ecef;
        --btn-blue: #17a2b8;
        --btn-blue-dark: #138496;
        --btn-red: #dc3545;
        --table-bg: #ffffff;
        --available: #28a745;
        --warning: #ffc107;
        --danger: #dc3545;
    }
    body.dark {
        --bg: #2b2b2b;
        --text: #f8f9fa;
        --card-bg: #3a3a3a;
        --table-bg: #2f2f2f;
    }
    body {
        font-family: Arial, sans-serif;
        background-color: var(--bg);
        color: var(--text);
        margin: 0;
        padding: 40px;
    }
    .container {
        max-width: 1200px;
        margin: auto;
        background-color: var(--card-bg);
        padding: 30px;
        border-radius: 8px;
    }
    h1 {
        font-size: 28px;
        margin-bottom: 20px;
        color: var(--text);
    }
    .top-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    .search-box input {
        width: 300px;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 16px;
    }
    .buttons {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        color: #fff;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .btn-add { background-color: var(--btn-blue); }
    .btn-add:hover { background-color: var(--btn-blue-dark); }
    .btn-back { background-color: var(--btn-blue); }
    .btn-back:hover { background-color: var(--btn-blue-dark); }

    table {
        width: 100%;
        border-collapse: collapse;
        background-color: var(--table-bg);
        border-radius: 8px;
        overflow: hidden;
    }
    th, td {
        text-align: center;
        padding: 12px;
        border-bottom: 1px solid #999;
    }
    th {
        background-color: var(--card-bg);
        font-weight: bold;
    }
    .status {
        font-weight: bold;
        text-transform: uppercase;
    }
    .status.reported { color: var(--danger); }
    .status.found { color: var(--available); }
    .status.replaced { color: var(--warning); }

    .actions a {
        text-decoration: none;
        border-radius: 4px;
        cursor: pointer;
        padding: 6px 8px;
        margin: 0 2px;
        display: inline-block;
    }
    .view { background-color: #28a745; color: white; }
    .edit { background-color: #ffc107; color: white; }
    .replace { background-color: #17a2b8; color: white; }
    .delete { background-color: var(--btn-red); color: white; }

    .msg {
        padding: 10px;
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 15px;
    }
   
.table-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-radius: 8px;
    background: var(--table-bg);
    margin-bottom: 20px;
    position: relative;
}

/* Responsive styles */
@media screen and (max-width: 1024px) {
    .container { 
        padding: 20px;
        margin: 10px;
    }
    
    .top-controls {
        flex-direction: column;
        gap: 12px;
        align-items: stretch;
    }

    .search-box {
        width: 100%;
    }

    .search-box input {
        width: 100%;
        box-sizing: border-box;
    }

    .buttons {
        flex-direction: row;
        justify-content: space-between;
        gap: 10px;
    }

    .btn {
        flex: 1;
        text-align: center;
    }
}

@media screen and (max-width: 768px) {
    body { padding: 12px; }
    
    .container {
        padding: 16px;
        border-radius: 10px;
    }

    h1 {
        font-size: 20px;
        text-align: center;
        margin-bottom: 15px;
    }

    /* Table adjustments */
    table {
        min-width: 720px;
    }

    th {
        position: sticky;
        top: 0;
        z-index: 2;
        font-size: 13px;
        white-space: nowrap;
        padding: 10px 8px;
    }

    td {
        font-size: 14px;
        padding: 10px 8px;
        white-space: nowrap;
    }

@media screen and (max-width: 480px) {
    body { padding: 0; }
    
    .container {
        border-radius: 0;
        padding: 12px;
    }

    .buttons {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        padding: 12px;
        font-size: 15px;
    }

    th, td {
        font-size: 13px;
        padding: 8px 6px;
    }

    .msg {
        margin: 10px;
        font-size: 14px;
    }
}
</style>
</head>
<body>
<div class="container">
    <h1>LOST KEYS MANAGEMENT</h1>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="msg">Record deleted successfully.</div>
    <?php elseif (isset($_GET['updated'])): ?>
        <div class="msg">Status updated successfully.</div>
    <?php elseif (isset($_GET['added'])): ?>
        <div class="msg">Lost key added successfully.</div>
    <?php elseif (isset($_GET['edited'])): ?>
        <div class="msg">Record updated successfully.</div>
    <?php endif; ?>

    <div class="top-controls">
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search lost key...">
        </div>
        <div class="buttons">
            <button class="btn btn-add" onclick="location.href='add_lost.php'">+ ADD LOST KEY</button>
            <button class="btn btn-back" onclick="location.href='../dashboard.php'">BACK</button>
        </div>
    </div>

    <div class="table-wrapper">
    <table>
        <thead>
            <tr>
                <th>USER</th>
                <th>EMAIL</th>
                <th>KEY CODE</th>
                <th>LOCATION</th>
                <th>REMARKS</th>
                <th>STATUS</th>
                <th>DATE REPORTED</th>
                <th>ACTIONS</th>
            </tr>
        </thead>
        <tbody id="tableBody">
            <?php foreach ($lostKeys as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['Fname'] . ' ' . $row['Lname']) ?></td>
                <td><?= htmlspecialchars($row['Email']) ?></td>
                <td><?= htmlspecialchars($row['Key_Code']) ?></td>
                <td><?= htmlspecialchars($row['Location']) ?></td>
                <td><?= htmlspecialchars($row['Remarks']) ?></td>
                <td class="status <?= strtolower($row['Status']) ?>"><?= strtoupper($row['Status']) ?></td>
                <td><?= date('m-d-Y', strtotime($row['Date_Reported'])) ?></td>
                <td class="actions">
                    
                    <a href="edit_lost.php?id=<?= $row['LostID'] ?>" class="edit" title="Edit">&#9998;</a>
                    <a href="lost_key.php?update=<?= $row['LostID'] ?>&status=FOUND" class="view" title="Mark Found">&#10004;</a>
                    <a href="lost_key.php?update=<?= $row['LostID'] ?>&status=REPLACED" class="replace" title="Mark Replaced">&#9851;</a>
                    <a href="#" class="delete" data-id="<?= $row['LostID'] ?>" title="Delete">&#128465;</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// ✅ Live search
let typingTimer;
document.getElementById('searchInput').addEventListener('keyup', () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const search = document.getElementById('searchInput').value;
        fetch(`lost_key.php?ajax=1&search=${encodeURIComponent(search)}`)
            .then(res => res.text())
            .then(data => document.getElementById('tableBody').innerHTML = data);
    }, 300);
});

// SweetAlert delete confirmation
document.addEventListener('click', function(e) {
    if (e.target.closest('.delete')) {
        e.preventDefault();
        const id = e.target.closest('.delete').dataset.id;

        Swal.fire({
            icon: 'error',
            title: 'Delete',
            text: 'Are you sure you want to delete this record?',
            showCancelButton: true,
            
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#e74c3c',
            cancelButtonColor: '#dcdcdc',
            background: '#fff',
            color: '#333',
            width: '320px',
            padding: '1em',
            borderRadius: '12px',
            customClass: {
                popup: 'modern-alert',
                icon: 'modern-icon',
                title: 'modern-title',
                cancelButton: 'modern-cancel',
                confirmButton: 'modern-confirm'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'lost_key.php?delete=' + id;
            }
        });
    }
});
</script>

<style>
/* 🔹 Compact Modern SweetAlert Style */
.swal2-popup.modern-alert {
    border-radius: 12px !important;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    font-family: 'Inter', sans-serif;
    font-size: 14px !important;
    position: relative;
}

/* Smaller, modern close “X” */

.swal2-close.modern-close:hover {
    background: #ebebeb !important;
    color: #555 !important;
}

.swal2-icon.modern-icon {
    border: none !important;
    background-color: rgba(231,76,60,0.08) !important;
    color: #e74c3c !important;
    width: 60px !important;
    height: 60px !important;
}

.swal2-title.modern-title {
    font-size: 18px !important;
    font-weight: 600;
    margin-top: 8px !important;
}

.swal2-actions .modern-cancel {
    background: #f1f1f1 !important;
    color: #333 !important;
    font-weight: 500 !important;
    border-radius: 6px !important;
    padding: 6px 14px !important;
    font-size: 13px !important;
}
.swal2-actions .modern-cancel:hover {
    background: #e0e0e0 !important;
}

.swal2-actions .modern-confirm {
    background: #e74c3c !important;
    color: #fff !important;
    font-weight: 500 !important;
    border-radius: 6px !important;
    padding: 6px 14px !important;
    font-size: 13px !important;
}
.swal2-actions .modern-confirm:hover {
    background: #c0392b !important;
}
</style>
<script>

document.addEventListener('DOMContentLoaded', () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') document.body.classList.add('dark');
});
</script>
</body>
</html>
