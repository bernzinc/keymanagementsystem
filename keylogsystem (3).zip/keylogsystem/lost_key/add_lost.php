<?php
require_once '../includes/functions.php';
requireAdmin();

date_default_timezone_set('Asia/Manila');

$msg = null;

// Fetch keys and users
$keys = $pdo->query("SELECT KeyID, Key_Code FROM keys_m ORDER BY Key_Code ASC")->fetchAll(PDO::FETCH_ASSOC);
$users = $pdo->query("SELECT UserID, CONCAT(Fname, ' ', Lname) AS FullName FROM users ORDER BY Lname ASC")->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keyID   = $_POST['KeyID'] ?? '';
    $userID  = $_POST['UserID'] ?? '';
    $location = trim($_POST['Location'] ?? '');
    $remarks  = trim($_POST['Remarks'] ?? '');
    $date     = date('Y-m-d');

    if ($keyID !== '' && $userID !== '' && $location !== '') {
        // fetch selected user details
        $u = $pdo->prepare("SELECT Fname, Lname, Email FROM users WHERE UserID = :uid LIMIT 1");
        $u->execute([':uid' => $userID]);
        $user = $u->fetch(PDO::FETCH_ASSOC);

        // fetch selected key code
        $k = $pdo->prepare("SELECT Key_Code FROM keys_m WHERE KeyID = :kid LIMIT 1");
        $k->execute([':kid' => $keyID]);
        $key = $k->fetch(PDO::FETCH_ASSOC);

        if (!$user || !$key) {
            $msg = "Selected user or key not found.";
        } else {
            // Insert into lost_keys using the actual DB columns you listed
            $stmt = $pdo->prepare("
                INSERT INTO lost_keys (
                    UserID, Fname, Lname, Email, Key_Code, Location,
                    Date_Reported, Remarks, Status, updated_at
                ) VALUES (
                    :userID, :fname, :lname, :email, :keycode, :location,
                    :date_reported, :remarks, 'LOST', NOW()
                )
            ");
            $stmt->execute([
                ':userID'      => $userID,
                ':fname'       => $user['Fname'],
                ':lname'       => $user['Lname'],
                ':email'       => $user['Email'],
                ':keycode'     => $key['Key_Code'],
                ':location'    => $location,
                ':date_reported'=> $date,
                ':remarks'     => $remarks
            ]);

            // Optional: mark the key as Lost in keys_m
            $upd = $pdo->prepare("UPDATE keys_m SET Status = 'Lost', updated_at = NOW() WHERE KeyID = :kid");
            $upd->execute([':kid' => $keyID]);

            $msg = "Lost key record added successfully!";
        }
    } else {
        $msg = "Please fill in all required fields.";
    }
}
// ...existing code...
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Lost Key</title>
    <link rel="stylesheet" href="../assets/theme.css">
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 40px;
        }

        .form-container {
            background: var(--card-bg);
            color: var(--text);
            padding: 30px;
            max-width: 450px;
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: background 0.3s, color 0.3s;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 15px;
            background-color: var(--table-bg);
            color: var(--text);
            box-sizing: border-box;
            display: block;
        }

        textarea {
            resize: none;
            height: 80px;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%23aaa' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 10px 6px;
            padding-right: 30px;
        }

        button {
            background-color: var(--btn-blue);
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        button:hover {
            background-color: var(--btn-blue-dark);
        }

        .msg {
            background: #d1ecf1;
            color: #0c5460;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            text-align: center;
        }

        /* Toggle switch */
        #toggle-switch {
            width: 45px;
            height: 22px;
            border-radius: 15px;
            background: #ccc;
            position: fixed;
            top: 20px;
            right: 20px;
            cursor: pointer;
            transition: background 0.3s;
            z-index: 999;
        }

        #toggle-switch div {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: white;
            position: absolute;
            top: 1px;
            left: 1px;
            transition: transform 0.3s;
        }

        #toggle-switch.active {
            background: #17a2b8;
        }

        #toggle-switch.active div {
            transform: translateX(23px);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <h2>Add Lost Key</h2>

        <?php if ($msg): ?>
            <div class="msg"><?= $msg ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Key Code:</label>
            <select name="KeyID" required>
                <option value="">Select Key</option>
                <?php foreach ($keys as $key): ?>
                    <option value="<?= htmlspecialchars($key['KeyID']) ?>"><?= htmlspecialchars($key['Key_Code']) ?></option>
                <?php endforeach; ?>
            </select>

            <label>User:</label>
            <select name="UserID" required>
                <option value="">Select User</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= htmlspecialchars($user['UserID']) ?>"><?= htmlspecialchars($user['FullName']) ?></option>
                <?php endforeach; ?>
            </select>

            <label>Location:</label>
            <input type="text" name="Location" placeholder="Enter key location" required>

            <label>Remarks:</label>
            <textarea name="Remarks" placeholder="Optional notes about the lost key..."></textarea>

            <div style="text-align:center;">
                <button type="submit">Save Lost Key</button>
                <button type="button" onclick="location.href='lost_key.php'">Back</button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/theme.js"></script>
</body>
</html>
