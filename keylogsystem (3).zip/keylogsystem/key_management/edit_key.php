<?php
require_once '../includes/functions.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: keys.php');
    exit;
}

// Fetch key data
$stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE KeyID = :id");
$stmt->execute([':id' => $id]);
$key = $stmt->fetch();

if (!$key) {
    echo "<p>Key not found.</p><a href='keys.php'>Back</a>";
    exit;
}

$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room = $_POST['Room_ID'];
    $code = $_POST['Key_Code'];
    $location = $_POST['Location'];
    $status = $_POST['Status'];

    // Update record with Location
    $stmt = $pdo->prepare("UPDATE `keys_m` 
                           SET Room_ID=:r, Location=:l, Key_Code=:k, QRCode=:q, Status=:s 
                           WHERE KeyID=:id");
    $stmt->execute([
        ':r' => $room,
        ':k' => $code,
        ':q' => $code,
        ':l' => $location,
        ':s' => $status,
        ':id' => $id
    ]);

    $msg = "Key updated successfully!";

    // Reload updated record
    $stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE KeyID = :id");
    $stmt->execute([':id' => $id]);
    $key = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Key</title>
<link rel="stylesheet" href="../assets/theme.css">

<style>
.container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 40px;
}

.form-container {
    background: var(--card-bg);
    color: var(--text);
    padding: 30px;
    max-width: 450px;
    width: 100%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: background 0.3s, color 0.3s;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

input, select {
    width: 100%;
    padding: 12px 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 15px;
    background-color: var(--table-bg);
    color: var(--text);
    box-sizing: border-box;
    display: block;
    height: 45px;
}

select {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath fill='%23aaa' d='M0 0l5 6 5-6z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 10px center;
    background-size: 10px 6px;
    padding-right: 30px;
}

button {
    background-color: var(--btn-blue);
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s;
    margin-right: 10px;
}

button:hover {
    background-color: var(--btn-blue-dark);
}

.msg {
    background: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 10px;
    text-align: center;
}

.qr {
    display: block;
    margin: auto;
    width: 120px;
    height: 120px;
    border-radius: 6px;
}

#toggle-switch {
    width: 45px;
    height: 22px;
    border-radius: 15px;
    background: #ccc;
    position: fixed;
    top: 20px;
    right: 20px;
    cursor: pointer;
    transition: background 0.3s;
    z-index: 999;
}
#toggle-switch div {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: white;
    position: absolute;
    top: 1px;
    left: 1px;
    transition: transform 0.3s;
}
#toggle-switch.active { background: #17a2b8; }
#toggle-switch.active div { transform: translateX(23px); }
</style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <h2>Edit Key</h2>

        <?php if ($msg): ?>
            <div class="msg"><?= $msg ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Room ID:</label>
            <input type="text" name="Room_ID" value="<?= htmlspecialchars($key['Room_ID']) ?>" required>

            <label>Key Code:</label>
            <input type="text" name="Key_Code" id="keyCode" value="<?= htmlspecialchars($key['Key_Code']) ?>" required oninput="updateQR()">

            <label>Location:</label>
            <input type="text" name="Location" value="<?= htmlspecialchars($key['Location']) ?>" required placeholder="Enter location (e.g., Laboratory 1)">

            <label>Status:</label>
            <select name="Status">
                <option value="Available" <?= $key['Status']=='Available'?'selected':'' ?>>Available</option>
                <option value="Borrowed" <?= $key['Status']=='Borrowed'?'selected':'' ?>>Borrowed</option>
                <option value="Lost" <?= $key['Status']=='Lost'?'selected':'' ?>>Lost</option>
            </select>

            <div id="qrPreview" style="text-align:center; margin-bottom:15px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($key['Key_Code']) ?>&size=120x120" class="qr" alt="QR Code">
            </div>

            <div style="text-align:center;">
                <button type="submit">Save Changes</button>
                <button type="button" onclick="location.href='keys.php'">Back</button>
            </div>
        </form>
    </div>
</div>

<script src="../assets/theme.js"></script>
<script>
function updateQR() {
    const code = document.getElementById('keyCode').value;
    const qrDiv = document.getElementById('qrPreview');
    qrDiv.innerHTML = code
        ? `<img src="https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(code)}&size=120x120" class='qr'>`
        : '';
}
</script>
</body>
</html>
