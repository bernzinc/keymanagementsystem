<?php
require_once '../includes/functions.php';
requireAdmin();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: keys.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM `keys_m` WHERE KeyID = :id");
$stmt->execute([':id' => $id]);
$key = $stmt->fetch();

if (!$key) {
    echo "<p>Key not found.</p><a href='keys.php'>Back</a>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Key</title>
    <link rel="stylesheet" href="../assets/theme.css">
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 40px;
        }

        .card {
            background: var(--card-bg);
            color: var(--text);
            padding: 30px;
            max-width: 500px;
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            transition: background 0.3s, color 0.3s;
        }

        h2 {
            margin-bottom: 20px;
        }

        .qr {
            width: 150px;
            height: 150px;
            margin: 10px 0;
            border-radius: 6px;
        }

        .info {
            text-align: left;
            margin-top: 20px;
        }

        .info p {
            font-size: 16px;
            margin: 6px 0;
        }

        button {
            background-color: var(--btn-blue);
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin: 10px 5px 0 5px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: var(--btn-blue-dark);
        }

        /* Toggle switch styling */
        #toggle-switch {
            width: 45px;
            height: 22px;
            border-radius: 15px;
            background: #ccc;
            position: fixed;
            top: 20px;
            right: 20px;
            cursor: pointer;
            transition: background 0.3s;
            z-index: 999;
        }

        #toggle-switch div {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: white;
            position: absolute;
            top: 1px;
            left: 1px;
            transition: transform 0.3s;
        }

        #toggle-switch.active {
            background: #17a2b8;
        }

        #toggle-switch.active div {
            transform: translateX(23px);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>View Key Details</h2>

        <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?= urlencode($key['Key_Code']) ?>&size=150x150"
             class="qr" alt="QR Code">

        <div class="info">
            <p><strong>Key ID:</strong> <?= $key['KeyID'] ?></p>
            <p><strong>Room ID:</strong> <?= htmlspecialchars($key['Room_ID']) ?></p>
            <p><strong>Key Code:</strong> <?= htmlspecialchars($key['Key_Code']) ?></p>
            <p><strong>Location:</strong> <?= htmlspecialchars($key['Location']) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($key['Status']) ?></p>
            <p><strong>Date Added:</strong> <?= htmlspecialchars($key['Date_Added']) ?></p>
        </div>

        <button onclick="location.href='edit_key.php?id=<?= $key['KeyID'] ?>'">Edit</button>
        <button onclick="location.href='keys.php'">Back</button>
    </div>
</div>

<script src="../assets/theme.js"></script>
</body>
</html>
