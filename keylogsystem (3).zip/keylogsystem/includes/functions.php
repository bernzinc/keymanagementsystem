<?php
// functions.php
require_once __DIR__ . '/../config.php';

function flash($msg) {
    $_SESSION['flash'] = $msg;
}
function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $m = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $m;
    }
    return null;
}

// Read ENUM values for a column so dropdowns match DB enum
function getEnumValues(PDO $pdo, $table, $column) {
    $stmt = $pdo->prepare("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=:t AND COLUMN_NAME=:c");
    $stmt->execute([':t'=>$table, ':c'=>$column]);
    $row = $stmt->fetch();
    if (!$row) return [];
    $type = $row['COLUMN_TYPE']; // e.g. enum('A','B')
    if (preg_match("/^enum\((.*)\)$/", $type, $m)) {
        $vals = str_getcsv($m[1], ',', "'");
        $vals = array_map(function($v){ return trim($v, "'"); }, $vals);
        return $vals;
    }
    return [];
}

// simple escape for HTML
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES); }
